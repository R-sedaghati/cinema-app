import { AppDataSource } from '../config/database.js';
import { Admin } from '../entities/Admin.js';
import { Permission } from '../entities/Permission.js';
import { RolePermission } from '../entities/RolePermission.js';
import { User } from '../entities/User.js';
import { ArtistRequest, ArtistRequestRejectedReason } from '../entities/ArtistRequest.js';
import { ArtistPortfolio } from '../entities/ArtistPortfolio.js';
import { Category } from '../entities/Category.js';
import { Payment } from '../entities/Payment.js';
import { GatewayReceipt } from '../entities/GatewayReceipt.js';
import { Support } from '../entities/Support.js';
import { FAQ } from '../entities/FAQ.js';
import { AboutUs } from '../entities/AboutUs.js';
import { Banner } from '../entities/Banner.js';
import { Tutorial } from '../entities/Tutorial.js';
import { SiteContent } from '../entities/SiteContent.js';
import { FormStep } from '../entities/FormStep.js';
import { FormField } from '../entities/FormField.js';
import { ContactRequest } from '../entities/ContactRequest.js';
import { PaymentSetting } from '../entities/PaymentSetting.js';
import { NotificationSetting } from '../entities/NotificationSetting.js';
import { WalletTransaction } from '../entities/WalletTransaction.js';

const userRepository = () => AppDataSource.getRepository(User);
const adminRepository = () => AppDataSource.getRepository(Admin);
const permissionRepository = () => AppDataSource.getRepository(Permission);
const rolePermissionRepository = () => AppDataSource.getRepository(RolePermission);
const artistRequestRepository = () => AppDataSource.getRepository(ArtistRequest);
const artistPortfolioRepository = () => AppDataSource.getRepository(ArtistPortfolio);
const categoryRepository = () => AppDataSource.getRepository(Category);
const paymentRepository = () => AppDataSource.getRepository(Payment);
const gatewayReceiptRepository = () => AppDataSource.getRepository(GatewayReceipt);
const supportRepository = () => AppDataSource.getRepository(Support);
const faqRepository = () => AppDataSource.getRepository(FAQ);
const aboutUsRepository = () => AppDataSource.getRepository(AboutUs);
const artistRequestRejectedReasonRepository = () => AppDataSource.getRepository(ArtistRequestRejectedReason);
const bannerRepository = () => AppDataSource.getRepository(Banner);
const tutorialRepository = () => AppDataSource.getRepository(Tutorial);
const siteContentRepository = () => AppDataSource.getRepository(SiteContent);
const formStepRepository = () => AppDataSource.getRepository(FormStep);
const formFieldRepository = () => AppDataSource.getRepository(FormField);
const contactRequestRepository = () => AppDataSource.getRepository(ContactRequest);
const paymentSettingRepository = () => AppDataSource.getRepository(PaymentSetting);
const notificationSettingRepository = () => AppDataSource.getRepository(NotificationSetting);
const walletTransactionRepository = () => AppDataSource.getRepository(WalletTransaction);

export {
    userRepository,
    adminRepository,
    permissionRepository,
    rolePermissionRepository,
    artistRequestRepository,
    artistPortfolioRepository,
    categoryRepository,
    paymentRepository,
    gatewayReceiptRepository,
    supportRepository,
    faqRepository,
    aboutUsRepository,
    artistRequestRejectedReasonRepository,
    bannerRepository,
    tutorialRepository,
    siteContentRepository,
    formStepRepository,
    formFieldRepository,
    contactRequestRepository,
    paymentSettingRepository,
    notificationSettingRepository,
    walletTransactionRepository
};

