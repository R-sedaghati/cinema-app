/**
 * Prices (Toman) that an admin sets per category.
 *
 * Two distinct "no charge" states have to stay distinguishable:
 *   0    — free. The gateway is skipped entirely.
 *   null — not set here. Inherit the top-level category, then the config fallback.
 *
 * Truthiness collapses those two, so every read goes through `isAmountSet` and
 * every write through `normalizeAmount`.
 */

/** Admin form input -> column value. Keeps 0; blank or nonsense becomes null. */
export const normalizeAmount = (value: unknown): number | null => {
  if (value === null || value === undefined || value === "") return null;

  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < 0) return null;

  return Math.round(parsed);
};

/** True when a column actually carries a price — including a free one. */
export const isAmountSet = (value: number | null | undefined): value is number =>
  value !== null && value !== undefined;
