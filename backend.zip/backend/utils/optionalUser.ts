/**
 * Public endpoints that answer differently for a signed-in caller.
 *
 * The route stays open to anonymous callers, so a missing or bad token is not an error
 * here — it just means "no user". Anything auth-gated keeps using the userAuth middleware.
 */

import jwt from "jsonwebtoken";
import { Request } from "express";
import { configs } from "../config/configs.js";

/** The caller's user id when they sent a valid user token, otherwise undefined. */
export const optionalUserId = (req: Request): number | undefined => {
  const token = req.headers.authorization;
  if (!token) return undefined;

  try {
    jwt.verify(token, configs.userJwtSecret);
  } catch {
    return undefined;
  }

  const decoded = jwt.decode(token, { json: true });
  return typeof decoded?.id === "number" ? decoded.id : undefined;
};
