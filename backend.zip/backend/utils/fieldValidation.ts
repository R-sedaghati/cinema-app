import type { FormField } from "../entities/FormField.js";
import { FormFieldType } from "./enum.js";

/**
 * Named validations an admin attaches to a form field in the form-builder.
 * Mirrors `lib/utils/fieldValidationPresets.ts` on the client — keep the ids in sync.
 * The client copy is UX; this copy is the one that decides what gets stored.
 */

export type FieldValidationPreset =
  | "MOBILE"
  | "LANDLINE"
  | "NATIONAL_CODE"
  | "POSTAL_CODE"
  | "EMAIL"
  | "IBAN"
  | "URL";

export interface FieldValidation {
  preset?: FieldValidationPreset;
  min?: number;
  max?: number;
  minLength?: number;
  maxLength?: number;
  pattern?: string;
}

export const toEnglishDigits = (value: string) =>
  value
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 0x06f0))
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x0660));

/** Iranian national code: 10 digits, last one a mod-11 checksum. */
const isValidNationalCode = (value: string) => {
  if (!/^\d{10}$/.test(value) || /^(\d)\1{9}$/.test(value)) return false;

  const digits = value.split("").map(Number);
  const sum = digits.slice(0, 9).reduce((acc, d, i) => acc + d * (10 - i), 0);
  const remainder = sum % 11;
  const check = digits[9];

  return remainder < 2 ? check === remainder : check === 11 - remainder;
};

const PRESETS: Record<FieldValidationPreset, { message: string; test: (v: string) => boolean }> = {
  MOBILE: { message: "شماره موبایل معتبر نیست", test: (v) => /^09\d{9}$/.test(v) },
  LANDLINE: { message: "تلفن ثابت معتبر نیست", test: (v) => /^0\d{2,3}\d{8}$/.test(v) },
  NATIONAL_CODE: { message: "کد ملی معتبر نیست", test: isValidNationalCode },
  POSTAL_CODE: { message: "کد پستی معتبر نیست", test: (v) => /^\d{10}$/.test(v) },
  EMAIL: { message: "ایمیل معتبر نیست", test: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) },
  IBAN: {
    message: "شماره شبا معتبر نیست",
    test: (v) => /^IR\d{24}$/.test(v.replace(/\s/g, "").toUpperCase()),
  },
  URL: { message: "آدرس اینترنتی معتبر نیست", test: (v) => /^https?:\/\/\S+\.\S+$/.test(v) },
};

export const isKnownPreset = (preset: unknown): preset is FieldValidationPreset =>
  typeof preset === "string" && preset in PRESETS;

/** null when the answer passes; otherwise the reason it does not. */
export const validateAnswer = (field: FormField, value: unknown): string | null => {
  const rules = (field.validation ?? {}) as FieldValidation;
  const isEmpty = value === undefined || value === null || value === "";

  // an empty optional answer has nothing to validate; `required` is checked by the caller
  if (isEmpty) return null;

  if (field.type === FormFieldType.NUMBER) {
    const numeric = typeof value === "number" ? value : Number(toEnglishDigits(String(value)));
    if (Number.isNaN(numeric)) return `${field.label} باید عدد باشد`;
    if (rules.min !== undefined && numeric < rules.min) return `${field.label} باید حداقل ${rules.min} باشد`;
    if (rules.max !== undefined && numeric > rules.max) return `${field.label} باید حداکثر ${rules.max} باشد`;
    return null;
  }

  if (typeof value !== "string") return null;

  if (rules.minLength !== undefined && value.length < rules.minLength) {
    return `${field.label} باید حداقل ${rules.minLength} کاراکتر باشد`;
  }

  if (rules.maxLength !== undefined && value.length > rules.maxLength) {
    return `${field.label} باید حداکثر ${rules.maxLength} کاراکتر باشد`;
  }

  if (isKnownPreset(rules.preset) && !PRESETS[rules.preset].test(toEnglishDigits(value).trim())) {
    return `${field.label}: ${PRESETS[rules.preset].message}`;
  }

  if (rules.pattern) {
    try {
      if (!new RegExp(rules.pattern).test(value)) return `${field.label} نامعتبر است`;
    } catch {
      // admin-authored regex: an invalid one validates nothing rather than rejecting every answer
    }
  }

  return null;
};

/** Every validation error across the answers the artist submitted. */
export const validateAnswers = (
  fields: FormField[],
  answers: Record<string, unknown>
): string[] =>
  fields
    .map((field) => validateAnswer(field, answers[field.key]))
    .filter((error): error is string => error !== null);
