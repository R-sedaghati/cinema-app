import { categoryRepository, formStepRepository } from "../models/index.js";
import { Category } from "../entities/Category.js";
import { FormStep } from "../entities/FormStep.js";
import { FormField } from "../entities/FormField.js";

/**
 * Resolves any category id (top-level or child) to the top-level category
 * that owns the form schema — children share their parent's schema.
 */
export const resolveTopLevelCategory = async (
  categoryId: number
): Promise<Category | null> => {
  const category = await categoryRepository().findOne({
    where: { id: categoryId },
    relations: { parent: true },
  });

  if (!category) return null;

  return category.parent ? category.parent : category;
};

export const getFormStepsForCategory = async (
  topLevelCategoryId: number
): Promise<FormStep[]> => {
  return formStepRepository().find({
    where: { category: { id: topLevelCategoryId } },
    relations: { fields: true },
    order: { order: "ASC", fields: { order: "ASC" } },
  });
};

export const getAllFieldsForCategory = async (
  topLevelCategoryId: number
): Promise<FormField[]> => {
  const steps = await getFormStepsForCategory(topLevelCategoryId);
  return steps.flatMap((step) => step.fields ?? []);
};
