import { formFieldRepository } from "../models/index.js";
import { Not, IsNull } from "typeorm";
import { FormFieldType } from "./enum.js";

/**
 * Artist identity and contact details are the paid product: they stay out of every public
 * response until a viewer has bought a contact request.
 *
 * `answers` is a free-form jsonb blob filled from admin-authored form fields, so hiding
 * `user.firstName` is not enough — the seeded default form also stores the artist's name,
 * email and postal code as ordinary answers (see scripts/seedDefaultFormSteps.ts).
 */

/** Conventional keys the form-builder uses for identity/contact data. */
const CONVENTIONAL_PRIVATE_KEYS = [
  "fullName",
  "firstName",
  "lastName",
  "name",
  "email",
  "phone",
  "phoneNumber",
  "mobile",
  "tel",
  "address",
  "postalCode",
  "nationalCode",
];

/** User fields the public serializer must always drop. */
export const PUBLIC_EXCLUDED_USER_FIELDS = [
  "firstName",
  "lastName",
  "phoneNumber",
  "email",
] as const;

/**
 * Answer keys to strip from public responses: the conventional ones above plus every key
 * an admin wired to a user identity field (`syncToUserField`), whatever they named it.
 */
export const publicExcludedAnswerKeys = async (): Promise<string[]> => {
  const syncedFields = await formFieldRepository().find({
    where: { syncToUserField: Not(IsNull()) },
    select: { key: true },
  });

  return [
    ...new Set([...CONVENTIONAL_PRIVATE_KEYS, ...syncedFields.map((f) => f.key)]),
  ];
};

/** Same list, without the DB round-trip — for callers that only need the static rules. */
export const isConventionallyPrivateKey = (key: string): boolean =>
  CONVENTIONAL_PRIVATE_KEYS.includes(key);

/**
 * Answer field types whose values read as prose a person would search for. IMAGE/VIDEO
 * hold storage paths, DATE and NUMBER hold digits — matching those turns a query like
 * "png" or a stray digit into a hit on every artist.
 */
const SEARCHABLE_ANSWER_TYPES: FormFieldType[] = [
  FormFieldType.TEXT,
  FormFieldType.TEXTAREA,
  FormFieldType.SELECT,
  FormFieldType.SELECT_PROVINCE,
  FormFieldType.SELECT_CITY,
  FormFieldType.RADIO,
  FormFieldType.CHECKBOX,
];

/**
 * Free-text search target: the *values* of public, prose-like answers.
 *
 * Searching `answers::text` instead would match the jsonb key names and the raw file
 * paths too, so "aboutMe" or "png" hit every artist who filled the form.
 *
 * Keys are interpolated as SQL literals, so they must come from FormField rows (never
 * from the request) and anything that is not a bare identifier is discarded.
 */
export const publicAnswersSearchExpression = async (
  alias = "artists"
): Promise<string> => {
  const excluded = new Set(await publicExcludedAnswerKeys());

  const fields = await formFieldRepository().find({
    select: { key: true, type: true },
  });

  const keys = [
    ...new Set(
      fields
        .filter(
          (field) =>
            SEARCHABLE_ANSWER_TYPES.includes(field.type) &&
            !excluded.has(field.key) &&
            /^[A-Za-z0-9_]+$/.test(field.key)
        )
        .map((field) => field.key)
    ),
  ];

  // No searchable field at all: a constant the ILIKE can never match.
  if (keys.length === 0) return `''`;

  const literals = keys.map((key) => `'${key}'`).join(", ");

  return `(SELECT string_agg(entry.value, ' ')
             FROM jsonb_each_text(${alias}.answers) AS entry
            WHERE entry.key IN (${literals}))`;
};

/**
 * Every column/expression public artist search runs against.
 *
 * The category name is reached through a correlated subquery rather than the joined
 * `categories` alias on purpose: a WHERE on a joined to-many relation makes TypeORM load
 * only the matching rows, so a search for "بازیگری" would return the artist carrying just
 * that one category and the card would show the wrong chip.
 */
export const publicSearchableExpressions = async (
  alias = "artists"
): Promise<string[]> => [
  `(SELECT string_agg(category.fa_name, ' ')
      FROM artist_request_categories link
      JOIN categories category ON category.id = link.category_id
     WHERE link.artist_request_id = ${alias}.id)`,
  "user.code",
  await publicAnswersSearchExpression(alias),
];
