import { formFieldRepository } from "../models/index.js";
import { Not, IsNull } from "typeorm";

/**
 * Artist identity and contact details are the paid product: they stay out of every public
 * response until a viewer has bought a contact request.
 *
 * `answers` is a free-form jsonb blob filled from admin-authored form fields, so hiding
 * `user.firstName` is not enough — the seeded default form also stores the artist's name,
 * email and postal code as ordinary answers (see scripts/seedDefaultFormSteps.ts).
 */

/** Conventional keys the form-builder uses for identity/contact data. */
const CONVENTIONAL_PRIVATE_KEYS = [
  "fullName",
  "firstName",
  "lastName",
  "name",
  "email",
  "phone",
  "phoneNumber",
  "mobile",
  "tel",
  "address",
  "postalCode",
  "nationalCode",
];

/** User fields the public serializer must always drop. */
export const PUBLIC_EXCLUDED_USER_FIELDS = [
  "firstName",
  "lastName",
  "phoneNumber",
  "email",
] as const;

/**
 * Answer keys to strip from public responses: the conventional ones above plus every key
 * an admin wired to a user identity field (`syncToUserField`), whatever they named it.
 */
export const publicExcludedAnswerKeys = async (): Promise<string[]> => {
  const syncedFields = await formFieldRepository().find({
    where: { syncToUserField: Not(IsNull()) },
    select: { key: true },
  });

  return [
    ...new Set([...CONVENTIONAL_PRIVATE_KEYS, ...syncedFields.map((f) => f.key)]),
  ];
};

/** Same list, without the DB round-trip — for callers that only need the static rules. */
export const isConventionallyPrivateKey = (key: string): boolean =>
  CONVENTIONAL_PRIVATE_KEYS.includes(key);

/**
 * Free-text search target that excludes private answers — otherwise a searcher could
 * confirm an artist's name or email by probing, which is exactly what they must pay for.
 *
 * jsonb `-` takes a text[] of keys to drop. Keys are interpolated as SQL literals, so
 * anything that is not a bare identifier is discarded rather than escaped.
 */
export const publicAnswersSearchExpression = async (
  alias = "artists"
): Promise<string> => {
  const keys = (await publicExcludedAnswerKeys()).filter((key) =>
    /^[A-Za-z0-9_]+$/.test(key)
  );

  if (keys.length === 0) return `${alias}.answers::text`;

  const literals = keys.map((key) => `'${key}'`).join(", ");
  return `(${alias}.answers - ARRAY[${literals}]::text[])::text`;
};
