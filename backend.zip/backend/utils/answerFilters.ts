import type { FormField } from "../entities/FormField.js";
import { FormFieldType, SyncToUserField } from "./enum.js";
import { isConventionallyPrivateKey } from "./privacy.js";

/**
 * Artist attributes live in the `artist_requests.answers` jsonb blob and are defined
 * at runtime by admins in the form-builder, so the set of filterable columns has to be
 * derived from a category's FormFields instead of hardcoded.
 *
 * SECURITY: a field key is interpolated into raw SQL as an identifier. It must therefore
 * come from FormField rows (never from the request) *and* match KEY_PATTERN. Both gates
 * are applied here; a request param naming an unknown key simply finds no column in the
 * map and is dropped by SearchAndFilterService.
 */
const KEY_PATTERN = /^[A-Za-z0-9_]+$/;

/** Fields that identify a person rather than describe them — never facets. */
const IDENTITY_SYNC_FIELDS: (SyncToUserField | null | undefined)[] = [
  SyncToUserField.firstName,
  SyncToUserField.lastName,
  SyncToUserField.email,
  SyncToUserField.avatar,
];

/** Free-text, media and date fields make poor facets. */
const FILTERABLE_TYPES: FormFieldType[] = [
  FormFieldType.TEXT,
  FormFieldType.NUMBER,
  FormFieldType.SELECT,
  FormFieldType.SELECT_PROVINCE,
  FormFieldType.SELECT_CITY,
  FormFieldType.RADIO,
  FormFieldType.CHECKBOX,
  FormFieldType.BOOLEAN,
];

export const ANSWER_PARAM_PREFIX = "answers.";

/** Max distinct values before a TEXT field is treated as free text rather than a facet. */
export const MAX_FACET_OPTIONS = 30;

export const isFilterableField = (field: FormField): boolean =>
  KEY_PATTERN.test(field.key) &&
  FILTERABLE_TYPES.includes(field.type) &&
  !IDENTITY_SYNC_FIELDS.includes(field.syncToUserField) &&
  // Contact details are paid content; they must not leak as facet options either.
  !isConventionallyPrivateKey(field.key);

/** CheckboxField always writes a string[]; every other field type writes a scalar. */
export const isMultiValueField = (field: FormField): boolean =>
  field.type === FormFieldType.CHECKBOX;

/**
 * SQL expression a field's answers are filtered through.
 *
 * `->>` returns text, so NUMBER fields need a numeric cast or `gte`/`lte` compare
 * lexicographically and "9" > "10". Array answers keep the jsonb (`->`) form because
 * only the `hasany` operator can match inside them.
 */
export const answerColumn = (field: FormField, alias = "artists"): string => {
  if (isMultiValueField(field)) {
    return `${alias}.answers -> '${field.key}'`;
  }
  if (field.type === FormFieldType.NUMBER) {
    return `(${alias}.answers ->> '${field.key}')::numeric`;
  }
  return `${alias}.answers ->> '${field.key}'`;
};

/** Query param the client sends for a field, e.g. `answers.city__in`. */
export const answerParam = (field: FormField): string => {
  if (isMultiValueField(field)) return `${ANSWER_PARAM_PREFIX}${field.key}__hasany`;
  if (field.type === FormFieldType.NUMBER) return `${ANSWER_PARAM_PREFIX}${field.key}`;
  return `${ANSWER_PARAM_PREFIX}${field.key}__in`;
};

/**
 * Builds the `filterable` map SearchAndFilterService consumes, keyed by the param name
 * without its `__operator` suffix (the service splits on `__` before lookup).
 */
export const buildAnswerFilterMap = (
  fields: FormField[],
  alias = "artists"
): Record<string, string> => {
  const map: Record<string, string> = {};

  for (const field of fields) {
    if (!isFilterableField(field)) continue;
    map[`${ANSWER_PARAM_PREFIX}${field.key}`] = answerColumn(field, alias);
  }

  return map;
};
