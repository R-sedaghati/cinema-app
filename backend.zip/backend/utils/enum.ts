export enum AdminRole {
    SUPER_ADMIN = 'SUPER_ADMIN',
    ADMIN = 'ADMIN',
}

export enum PortfolioType {
  IMAGE = "IMAGE",
  VIDEO = "VIDEO",
}

export enum ArtistRequestStatus {
  PENDING = "PENDING",
  PENDING_PAYMENT = "PENDING_PAYMENT",
  APPROVED = "APPROVED",
  REJECTED = "REJECTED",
  NEED_TO_REVISION = "NEED_TO_REVISION"
}

export enum PaymentStatus {
  PENDING = "PENDING",
  COMPLETED = "COMPLETED",
  FAILED = "FAILED",
  CANCELED = "CANCELED",
}

/**
 * Why money moved in or out of a wallet. Credits are positive, debits negative — the
 * type says what happened, the sign says which direction.
 */
export enum WalletTransactionType {
  /** Registration fee returned because the request was rejected. */
  REFUND_REJECTED = "REFUND_REJECTED",
  /** Registration fee held back while the artist fixes their request. */
  REFUND_REVISION = "REFUND_REVISION",
  /** A reservation returned because the gateway leg never settled. */
  REFUND_FAILED_PAYMENT = "REFUND_FAILED_PAYMENT",
  /** An admin added or removed balance by hand. */
  ADMIN_ADJUST = "ADMIN_ADJUST",
  /** Spent on an artist registration fee. */
  SPEND_REGISTRATION = "SPEND_REGISTRATION",
  /** Spent on unlocking an artist's contact details. */
  SPEND_CONTACT = "SPEND_CONTACT",
}

export const WalletTransactionTypeFa: Record<WalletTransactionType, string> = {
  [WalletTransactionType.REFUND_REJECTED]: "بازگشت وجه — رد درخواست",
  [WalletTransactionType.REFUND_REVISION]: "بازگشت وجه — نیاز به اصلاح",
  [WalletTransactionType.REFUND_FAILED_PAYMENT]: "بازگشت وجه — پرداخت ناموفق",
  [WalletTransactionType.ADMIN_ADJUST]: "تغییر دستی توسط ادمین",
  [WalletTransactionType.SPEND_REGISTRATION]: "پرداخت هزینه ثبت‌نام",
  [WalletTransactionType.SPEND_CONTACT]: "پرداخت مشاهده اطلاعات تماس",
};

export const ArtistRequestStatusFa: Record<ArtistRequestStatus, string> = {
  [ArtistRequestStatus.PENDING]: "در حال بررسی",
  [ArtistRequestStatus.PENDING_PAYMENT]: "در انتظار پرداخت",
  [ArtistRequestStatus.APPROVED]: "تایید شده",
  [ArtistRequestStatus.REJECTED]: "رد شده",
  [ArtistRequestStatus.NEED_TO_REVISION]: "نیاز به اصلاح"
};


export enum SupportStatus {
  PENDING = "PENDING",
  ACCEPTED = "ACCEPTED",
  REJECTED = "REJECTED"
}

export enum FormFieldType {
  TEXT = 'TEXT',
  TEXTAREA = 'TEXTAREA',
  NUMBER = 'NUMBER',
  SELECT = 'SELECT',
  SELECT_PROVINCE = 'SELECT_PROVINCE',
  SELECT_CITY = 'SELECT_CITY',
  RADIO = 'RADIO',
  CHECKBOX = 'CHECKBOX',
  BOOLEAN = 'BOOLEAN',
  DATE = 'DATE',
  IMAGE = 'IMAGE',
  VIDEO = 'VIDEO',
}

export enum SyncToUserField {
  firstName = 'firstName',
  lastName = 'lastName',
  avatar = 'avatar',
  email = 'email',
}
/** What an admin can be texted about. Global — every stored number gets every enabled event. */
export enum NotificationEvent {
  /** A new artist request was submitted, or its registration payment completed. */
  REGISTRATION = "REGISTRATION",
  /** A contact-detail purchase or a registration payment reached COMPLETED. */
  TRANSACTION = "TRANSACTION",
  /** A user opened a support ticket. */
  SUPPORT_TICKET = "SUPPORT_TICKET",
}
