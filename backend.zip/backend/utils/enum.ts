export enum AdminRole {
    SUPER_ADMIN = 'SUPER_ADMIN',
    ADMIN = 'ADMIN',
}

export enum PortfolioType {
  IMAGE = "IMAGE",
  VIDEO = "VIDEO",
}

export enum ArtistRequestStatus {
  PENDING = "PENDING",
  PENDING_PAYMENT = "PENDING_PAYMENT",
  APPROVED = "APPROVED",
  REJECTED = "REJECTED",
  NEED_TO_REVISION = "NEED_TO_REVISION"
}

export enum PaymentStatus {
  PENDING = "PENDING",
  COMPLETED = "COMPLETED",
  FAILED = "FAILED",
  CANCELED = "CANCELED",
}

export const ArtistRequestStatusFa: Record<ArtistRequestStatus, string> = {
  [ArtistRequestStatus.PENDING]: "در حال بررسی",
  [ArtistRequestStatus.PENDING_PAYMENT]: "در انتظار پرداخت",
  [ArtistRequestStatus.APPROVED]: "تایید شده",
  [ArtistRequestStatus.REJECTED]: "رد شده",
  [ArtistRequestStatus.NEED_TO_REVISION]: "نیاز به اصلاح"
};


export enum SupportStatus {
  PENDING = "PENDING",
  ACCEPTED = "ACCEPTED",
  REJECTED = "REJECTED"
}

export enum FormFieldType {
  TEXT = 'TEXT',
  TEXTAREA = 'TEXTAREA',
  NUMBER = 'NUMBER',
  SELECT = 'SELECT',
  RADIO = 'RADIO',
  CHECKBOX = 'CHECKBOX',
  DATE = 'DATE',
  IMAGE = 'IMAGE',
  VIDEO = 'VIDEO',
}

export enum SyncToUserField {
  firstName = 'firstName',
  lastName = 'lastName',
  avatar = 'avatar',
  email = 'email',
}