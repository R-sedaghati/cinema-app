import { Router } from 'express';
import userAuth from '../middleware/userAuthentication.js';
import { upload } from '../middleware/upload.js';
import { createContactRequestController, getArtistContactController, getMyContactRequestsController, callbackController, createArtistRequest, getArtistRequests, getUserSupportListController, purchaseController, supportCreateController, updateArtistRequestController, UserController, UserMinioController, userProfileUpdateController } from '../controllers/init.js';


const router = Router();

router.get('/', UserController.getUsers);
router.get('/profile/', [userAuth], UserController.getUserProfile);
router.post('/login/', UserController.userLogin);
router.post(
  "/avatar",
  [userAuth, upload.single("file")],
  UserMinioController.uploadAvatar,
);
router.post(
  "/upload/video",
  [userAuth, upload.single("file")],
  UserMinioController.uploadVideo,
);
router.post(
  "/upload/image",
  [userAuth, upload.single("file")],
  UserMinioController.uploadImage,
);
router.post(
  "/artist-requests",
  [userAuth, upload.array("portfolios")],
  createArtistRequest,
)

router.get(
  '/artist-requests',
  [userAuth],
  getArtistRequests
)
router.patch(
  '/artist-requests/:id/',
  [userAuth],
  updateArtistRequestController
)

router.post(
  '/supports/',
  supportCreateController
)
router.get(
  '/supports/',
  [userAuth],
  getUserSupportListController
)

router.get(
  '/purchase/',
  [userAuth],
  purchaseController
)
router.patch(
  '/profile/',
  [userAuth],
  userProfileUpdateController
)

// Buying an artist's contact details. The unlocked payload lives behind `/contact`.
router.post(
  '/artists-requests/:id/contact-requests/',
  [userAuth],
  createContactRequestController
)
router.get(
  '/artists-requests/:id/contact/',
  [userAuth],
  getArtistContactController
)
router.get(
  '/contact-requests/',
  [userAuth],
  getMyContactRequestsController
)

router.all('/purchase/callback/', callbackController)

export default router;

