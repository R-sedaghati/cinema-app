import { Router } from 'express';
import { aboutUsController, categoryController, faqListCommonController, getAllArtistsRequests, getRetrieveArtistsRequests, bannerListCommonController, tutorialListCommonController, siteContentController, getPublicFormSchemaController, getArtistFiltersController, getContactRequestPriceController, contactRequestCallbackController } from '../controllers/init.js';
import { getProvincesController, getProvinceCitiesController, searchCitiesController, getCityByIdController } from '../controllers/common/citiesAndProvincesController.js';


const router = Router();

router.get('/categories/', categoryController);
router.get('/categories/:id/form-schema/', getPublicFormSchemaController);
router.get('/categories/:id/filters/', getArtistFiltersController);
router.get('/artists-requests/', getAllArtistsRequests);
router.get('/artists-requests/:id/', getRetrieveArtistsRequests);
router.get("/provinces", getProvincesController);
router.get("/provinces/:id/cities", getProvinceCitiesController);
router.get("/cities/search", searchCitiesController);
router.get("/cities/:id", getCityByIdController);
router.get('/faqs/', faqListCommonController)
router.get('/about-us/', aboutUsController)
router.get('/banners/', bannerListCommonController)
router.get('/tutorials/', tutorialListCommonController)
router.get('/site-content/', siteContentController)
router.get('/artists-requests/:id/contact-price/', getContactRequestPriceController)
// Gateway return URL: the buyer's browser lands here, so it carries no auth header.
router.all('/contact-requests/callback/', contactRequestCallbackController)

export default router;

