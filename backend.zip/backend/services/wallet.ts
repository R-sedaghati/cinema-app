import { EntityManager } from "typeorm";
import { AppDataSource } from "../config/database.js";
import { WalletTransaction } from "../entities/WalletTransaction.js";
import { User } from "../entities/User.js";
import { WalletTransactionType } from "../utils/enum.js";

/**
 * The wallet ledger.
 *
 * Balance is always `SUM(amount)` over a user's rows — never a stored column, so it
 * cannot drift from its own history.
 *
 * Every spend goes through `spend`, which takes a row lock on the user for the whole
 * check-then-debit. Reading the balance and inserting the debit in two separate
 * statements would let two concurrent purchases both see the same balance and both
 * succeed, spending the money twice.
 */

/**
 * How a purchase splits between wallet and gateway.
 *
 * Pure and exported so it can be checked without a database — see
 * `scripts/checkWallet.ts`. A negative balance (an admin clawback that outran what was
 * there) must read as zero, never as credit.
 */
export const applyWallet = (balance: number, price: number) => {
  const applied = Math.max(0, Math.min(balance, price));
  return { applied, dueAtGateway: price - applied };
};

export const getBalance = async (
  userId: number,
  manager: EntityManager = AppDataSource.manager,
): Promise<number> => {
  const { sum } = await manager
    .getRepository(WalletTransaction)
    .createQueryBuilder("wallet_transaction")
    .select("COALESCE(SUM(wallet_transaction.amount), 0)", "sum")
    .where("wallet_transaction.user_id = :userId", { userId })
    .getRawOne<{ sum: string }>() ?? { sum: "0" };

  return Number(sum);
};

interface CreditParams {
  userId: number;
  amount: number;
  type: WalletTransactionType;
  description?: string | null;
  paymentId?: number | null;
  artistRequestId?: number | null;
  contactRequestId?: number | null;
  adminId?: number | null;
}

/** Adds money. `amount` must be positive. */
export const credit = async (
  { userId, amount, type, description, paymentId, artistRequestId, contactRequestId, adminId }: CreditParams,
  manager: EntityManager = AppDataSource.manager,
): Promise<WalletTransaction> => {
  if (amount <= 0) {
    throw new Error(`credit needs a positive amount, got ${amount}`);
  }

  const repository = manager.getRepository(WalletTransaction);

  return repository.save(
    repository.create({
      user: { id: userId },
      amount,
      type,
      description: description ?? null,
      payment: paymentId ? { id: paymentId } : null,
      artistRequest: artistRequestId ? { id: artistRequestId } : null,
      contactRequest: contactRequestId ? { id: contactRequestId } : null,
      admin: adminId ? { id: adminId } : null,
    }),
  );
};

/** Removes money without the "must not go negative" guard. Admin adjustments only. */
export const debitUnchecked = async (
  params: Omit<CreditParams, "amount"> & { amount: number },
  manager: EntityManager = AppDataSource.manager,
): Promise<WalletTransaction> => {
  if (params.amount >= 0) {
    throw new Error(`debit needs a negative amount, got ${params.amount}`);
  }

  const repository = manager.getRepository(WalletTransaction);

  return repository.save(
    repository.create({
      user: { id: params.userId },
      amount: params.amount,
      type: params.type,
      description: params.description ?? null,
      admin: params.adminId ? { id: params.adminId } : null,
    }),
  );
};

/**
 * Spends up to `requested` from the wallet and reports what it actually took.
 *
 * Returns the applied amount so the caller can charge the gateway for the remainder.
 * Locks the user row, so two concurrent purchases serialise instead of both spending
 * the same balance.
 */
export const spend = async (params: {
  userId: number;
  requested: number;
  type: WalletTransactionType;
  description?: string | null;
  artistRequestId?: number | null;
  contactRequestId?: number | null;
}): Promise<number> => {
  if (params.requested <= 0) return 0;

  return AppDataSource.transaction(async (manager) => {
    // The lock is on the user, not the ledger: it is what serialises two purchases by
    // the same person. Other users are unaffected.
    await manager.getRepository(User).findOne({
      where: { id: params.userId },
      lock: { mode: "pessimistic_write" },
    });

    const balance = await getBalance(params.userId, manager);
    const { applied } = applyWallet(balance, params.requested);

    if (applied <= 0) return 0;

    const repository = manager.getRepository(WalletTransaction);
    await repository.save(
      repository.create({
        user: { id: params.userId },
        amount: -applied,
        type: params.type,
        description: params.description ?? null,
        artistRequest: params.artistRequestId ? { id: params.artistRequestId } : null,
        contactRequest: params.contactRequestId ? { id: params.contactRequestId } : null,
      }),
    );

    return applied;
  });
};

/**
 * Credits a registration fee back, once per payment.
 *
 * Flipping a request's status back and forth re-runs the refund path, so the payment
 * link is checked first — otherwise every flip would mint the fee again.
 */
export const refundPaymentOnce = async (
  params: {
    userId: number;
    paymentId: number;
    amount: number;
    type: WalletTransactionType;
    description?: string | null;
    artistRequestId?: number | null;
  },
  manager: EntityManager = AppDataSource.manager,
): Promise<WalletTransaction | null> => {
  if (params.amount <= 0) return null;

  const repository = manager.getRepository(WalletTransaction);

  const existing = await repository.findOne({
    where: { payment: { id: params.paymentId } },
  });

  if (existing) return null;

  return credit(
    {
      userId: params.userId,
      amount: params.amount,
      type: params.type,
      description: params.description,
      paymentId: params.paymentId,
      artistRequestId: params.artistRequestId,
    },
    manager,
  );
};
