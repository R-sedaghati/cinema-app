import { Payment } from "../entities/Payment.js";
import { ContactRequest } from "../entities/ContactRequest.js";
import { artistRequestRepository, contactRequestRepository, paymentRepository } from "../models/index.js";
import {
  ArtistRequestStatus,
  NotificationEvent,
  PaymentStatus,
  WalletTransactionType,
} from "../utils/enum.js";
import { credit } from "./wallet.js";
import { claimRefNum, verifySepTransaction } from "./gateway.js";
import { notifyAdmins } from "./adminNotify.js";

/**
 * Settling a gateway leg, shared by the callback controllers and the sweeper that picks
 * up whatever the callback never finished.
 *
 * Order matters and is the same in both flows:
 *   1. claim the receipt — a RefNum that already paid for something else stops here;
 *   2. persist it on the purchase, so an interrupted verify can be resumed;
 *   3. verify with SEP, which is what actually moves the money;
 *   4. mark the purchase paid.
 *
 * A `SepTransportError` escaping any of this leaves the row PENDING on purpose: SEP has
 * not answered, so the transaction's fate is still open and the sweeper must retry.
 */

/** A settled registration fee is both a new registration and money moving, so it fires both. */
const notifyRegistrationPaid = (requestId: unknown, amount: number) => {
  notifyAdmins(
    NotificationEvent.REGISTRATION,
    `ثبت‌نام هنرمند (#${requestId}) پرداخت شد و در انتظار بررسی است.`,
  );
  notifyAdmins(
    NotificationEvent.TRANSACTION,
    `پرداخت ثبت‌نام (#${requestId}) به مبلغ ${amount.toLocaleString("fa-IR")} تومان تکمیل شد.`,
  );
};

/** Puts a wallet reservation back when the gateway leg does not settle. */
export const returnReservedWallet = async ({
  userId,
  amount,
  artistRequestId,
  contactRequestId,
}: {
  userId?: number;
  amount: number;
  artistRequestId?: number | null;
  contactRequestId?: number | null;
}) => {
  if (!userId || amount <= 0) return;

  await credit({
    userId,
    amount,
    type: WalletTransactionType.REFUND_FAILED_PAYMENT,
    description: "بازگشت مبلغ رزروشده کیف پول به دلیل ناموفق بودن پرداخت",
    artistRequestId: artistRequestId ?? null,
    contactRequestId: contactRequestId ?? null,
  });
};

export const settleRegistrationPayment = async (payment: Payment, refNum: string) => {
  await claimRefNum({ refNum, owner: `payment:${payment.id}`, amount: payment.amount });

  payment.refNum = refNum;
  await paymentRepository().save(payment);

  await verifySepTransaction({ refNum, expectedAmount: payment.amount });

  payment.status = PaymentStatus.COMPLETED;
  await paymentRepository().save(payment);

  if (payment.artistRequest) {
    payment.artistRequest.status = ArtistRequestStatus.PENDING;
    await artistRequestRepository().save(payment.artistRequest);
  }

  notifyRegistrationPaid(payment.artistRequest?.id, payment.amount);
};

/** Gives up on a registration leg and hands the wallet reservation back, once. */
export const failRegistrationPayment = async (payment: Payment) => {
  if (payment.status !== PaymentStatus.PENDING) return;

  payment.status = PaymentStatus.FAILED;
  await paymentRepository().save(payment);

  await returnReservedWallet({
    userId: payment.artistRequest?.user?.id,
    amount: payment.walletAmount,
    artistRequestId: payment.artistRequest?.id ?? null,
  });

  // Returned, so it cannot be handed back a second time by another pass.
  payment.walletAmount = 0;
  await paymentRepository().save(payment);
};

export const settleContactRequest = async (contactRequest: ContactRequest, refNum: string) => {
  await claimRefNum({
    refNum,
    owner: `contact:${contactRequest.id}`,
    amount: contactRequest.amount,
  });

  contactRequest.refNum = refNum;
  await contactRequestRepository().save(contactRequest);

  await verifySepTransaction({ refNum, expectedAmount: contactRequest.amount });

  contactRequest.status = PaymentStatus.COMPLETED;
  await contactRequestRepository().save(contactRequest);

  notifyAdmins(
    NotificationEvent.TRANSACTION,
    `خرید اطلاعات تماس هنرمند (#${contactRequest.artistRequest?.id}) به مبلغ ${contactRequest.amount.toLocaleString("fa-IR")} تومان تکمیل شد.`,
  );
};

/** Gives up on a contact leg and hands the wallet reservation back, once. */
export const failContactRequest = async (
  contactRequest: ContactRequest,
  status: PaymentStatus = PaymentStatus.FAILED,
) => {
  if (contactRequest.status !== PaymentStatus.PENDING) return;

  contactRequest.status = status;
  await contactRequestRepository().save(contactRequest);

  await returnReservedWallet({
    userId: contactRequest.buyer?.id,
    amount: contactRequest.walletAmount ?? 0,
    contactRequestId: contactRequest.id,
  });

  contactRequest.walletAmount = 0;
  await contactRequestRepository().save(contactRequest);
};
