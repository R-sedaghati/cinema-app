import { test } from "node:test";
import assert from "node:assert/strict";
import {
  toRial,
  buildStartPayUrl,
  assertSettled,
  isSepCallbackSuccessful,
  readVerifyResult,
  reverseUrlFrom,
  usableVerifyUrl,
  toSepCellNumber,
  SepDeclinedError,
  SEP_DEFAULTS,
} from "./gateway.js";

const verifyAnswer = (overrides: Record<string, unknown> = {}) => ({
  ResultCode: 0,
  ResultDescription: "عملیات با موفقیت انجام شد",
  Success: true,
  TransactionDetail: {
    RRN: "14226761817",
    RefNum: "abc",
    TerminalNumber: 2001,
    OrginalAmount: 2_000_000,
    AffectiveAmount: 2_000_000,
    ...(overrides.TransactionDetail as object ?? {}),
  },
  ...overrides,
});

const asked = { refNum: "abc", terminal: "2001" };

test("amounts are converted from Toman to Rial", () => {
  assert.equal(toRial(200_000), 2_000_000);
});

test("the pay URL asks SEP for a GET landing", () => {
  assert.equal(
    buildStartPayUrl(SEP_DEFAULTS.paymentUrl, "abc/123"),
    "https://sep.shaparak.ir/OnlinePG/OnlinePG?Token=abc%2F123&GetMethod=true",
  );
});

test("a settled amount matching the charge passes", () => {
  assert.equal(assertSettled(2_000_000, 200_000), 2_000_000);
});

test("a negative code is a gateway failure", () => {
  assert.throws(() => assertSettled(-1, 200_000), /code -1/);
});

test("a settled amount that does not match the charge is rejected", () => {
  // The one that must not regress: without it, a callback naming a cheaper transaction
  // would settle an expensive purchase.
  assert.throws(() => assertSettled(10_000, 200_000), /mismatch/);
});

test("the callback settles only on State OK with a RefNum", () => {
  assert.equal(isSepCallbackSuccessful({ State: "OK", RefNum: "123" }), true);
  assert.equal(isSepCallbackSuccessful({ State: "OK" }), false);
  assert.equal(isSepCallbackSuccessful({ State: "CanceledByUser", RefNum: "123" }), false);
});

test("a verify answer for our own receipt reports what SEP settled", () => {
  assert.equal(readVerifyResult(verifyAnswer(), asked), 2_000_000);
});

test("a repeated verify still counts as settled", () => {
  // SEP answers code 2 the second time a receipt is verified — which is what a retry
  // after a lost answer looks like, and must not read as a failure.
  assert.equal(readVerifyResult(verifyAnswer({ ResultCode: 2 }), asked), 2_000_000);
});

test("a negative result code is a refusal", () => {
  assert.throws(
    () => readVerifyResult(verifyAnswer({ ResultCode: -6, Success: false }), asked),
    SepDeclinedError,
  );
});

test("a verify answer describing another transaction is refused", () => {
  // The one that must not regress: an answer about someone else's RefNum, or another
  // merchant's terminal, is not evidence that ours was paid.
  assert.throws(
    () => readVerifyResult(verifyAnswer({ TransactionDetail: { RefNum: "other" } }), asked),
    SepDeclinedError,
  );
  assert.throws(
    () => readVerifyResult(verifyAnswer({ TransactionDetail: { TerminalNumber: 9999 } }), asked),
    SepDeclinedError,
  );
});

test("reverse lives beside verify on the same service", () => {
  assert.equal(
    reverseUrlFrom(SEP_DEFAULTS.verifyUrl),
    "https://sep.shaparak.ir/verifyTxnRandomSessionkey/ipg/ReverseTransaction",
  );
});

test("a verify URL left pointing at the retired SOAP service is ignored", () => {
  assert.equal(
    usableVerifyUrl("https://sep.shaparak.ir/payments/referencepayment.asmx?WSDL"),
    SEP_DEFAULTS.verifyUrl,
  );
  assert.equal(usableVerifyUrl("https://uat.example/ipg/VerifyTransaction"), "https://uat.example/ipg/VerifyTransaction");
});

test("the buyer's mobile is sent the way SEP wants it", () => {
  assert.equal(toSepCellNumber("09120000000"), "9120000000");
  assert.equal(toSepCellNumber(null), "");
});

test("amounts stay whole rials", () => {
  assert.equal(toRial(12_000.5), 120_005);
});
