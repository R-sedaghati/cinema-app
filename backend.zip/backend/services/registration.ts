/**
 * Per-user rules around artist registration: what it costs, and how often it is allowed.
 */

import { EntityManager } from "typeorm";
import { artistRequestRepository, paymentRepository } from "../models/index.js";
import { ArtistRequest } from "../entities/ArtistRequest.js";
import { PaymentStatus } from "../utils/enum.js";

/**
 * True when the user already has a settled registration payment they actually paid for.
 * The registration fee is charged once per user, so this makes every later registration
 * form free for them.
 *
 * A free category records a COMPLETED payment of 0 with no wallet share — that one does
 * not unlock anything, or the first free form would make every later paid form free.
 *
 * ponytail: a fee refunded later (rejection / revision) still counts as paid — the user
 * keeps the refund and keeps the unlock. Tighten to "holds a PENDING/APPROVED paid
 * request" if that is ever abused.
 */
export const hasPaidRegistration = async (userId?: number): Promise<boolean> => {
  if (!userId) return false;

  const count = await paymentRepository()
    .createQueryBuilder("payment")
    .innerJoin("payment.artistRequest", "artistRequest")
    .where("artistRequest.user_id = :userId", { userId })
    .andWhere("payment.status = :status", { status: PaymentStatus.COMPLETED })
    .andWhere("(payment.amount > 0 OR payment.wallet_amount > 0)")
    .getCount();

  return count > 0;
};

/**
 * Each account (one phone number, one account) fills a given form once. The form belongs
 * to the top-level category, so a request filed under any child of it counts too.
 *
 * Every status blocks, rejected ones included: a request that needs changes is edited
 * through the update endpoint, never re-submitted as a new one.
 *
 * Pass the transaction's manager when checking before an insert — the caller holds the
 * write lock on the user row there, which is what keeps two parallel submissions from
 * both passing this check.
 */
export const hasRequestInTopLevelCategory = async (
  userId: number | undefined,
  topLevelCategoryId: number,
  manager?: EntityManager,
): Promise<boolean> => {
  if (!userId) return false;

  const repository = manager
    ? manager.getRepository(ArtistRequest)
    : artistRequestRepository();

  const count = await repository
    .createQueryBuilder("artistRequest")
    .innerJoin("artistRequest.categories", "category")
    .leftJoin("category.parent", "parent")
    .where("artistRequest.user_id = :userId", { userId })
    .andWhere("(category.id = :topLevelCategoryId OR parent.id = :topLevelCategoryId)", {
      topLevelCategoryId,
    })
    .getCount();

  return count > 0;
};
