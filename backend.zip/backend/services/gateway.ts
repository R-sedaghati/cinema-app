import { getPaymentDriver } from "monopay";
import { configs } from "../config/configs.js";
import { paymentSettingRepository } from "../models/index.js";
import { PaymentSetting } from "../entities/PaymentSetting.js";

/**
 * One place that knows how the Zarinpal driver is configured, so the merchant key can
 * come from the admin panel instead of the environment.
 *
 * The DB row wins; an unset key falls back to `ZARINPAL_MERCHANT_ID` so an existing
 * deployment keeps working before an admin ever opens the settings page.
 */

// ponytail: process-local cache, invalidated on write. Two nodes would each hold their
// own copy until the next restart — move to a per-request read if that ever matters.
let cached: PaymentSetting | null = null;

/** The settings row, created on first use so the admin page always has something to edit. */
export const getPaymentSetting = async (): Promise<PaymentSetting> => {
  if (cached) return cached;

  const repository = paymentSettingRepository();
  let setting = await repository.findOne({ where: { id: 1 } });

  if (!setting) {
    setting = await repository.save(
      repository.create({
        id: 1,
        gateway: "zarinpal",
        merchantId: null,
        sandbox: configs.gatewayConfiguration.sandbox,
      }),
    );
  }

  cached = setting;
  return setting;
};

export const clearPaymentSettingCache = () => {
  cached = null;
};

export const zarinpalDriver = async () => {
  const setting = await getPaymentSetting();

  return getPaymentDriver("zarinpal")({
    merchantId: setting.merchantId || configs.gatewayConfiguration.merchantId,
    sandbox: setting.sandbox,
  });
};

/** Whether to send the buyer to the sandbox StartPay host. */
export const isSandbox = async () => (await getPaymentSetting()).sandbox;
