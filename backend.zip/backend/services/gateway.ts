import { configs } from "../config/configs.js";
import { gatewayReceiptRepository, paymentSettingRepository } from "../models/index.js";
import { PaymentSetting } from "../entities/PaymentSetting.js";

/**
 * SEP (Saman Electronic Payment) — the one place that knows how the gateway is reached,
 * so the terminal ID can come from the admin panel instead of the environment.
 *
 * Follows "راهنمای استفاده از درگاه پرداخت اینترنتی" نگارش ۳.۶ (دی ۱۴۰۴): token over
 * REST, redirect, then the REST VerifyTransaction/ReverseTransaction pair. The older
 * SOAP `referencepayment.asmx` verify is gone — the current document does not list it.
 *
 * The DB row wins; an unset terminal falls back to `SEP_TERMINAL_ID` so an existing
 * deployment keeps working before an admin ever opens the settings page.
 *
 * Called directly rather than through monopay: its saman driver validates the request
 * options against a zod schema that omits `amount` and `callbackUrl`, so zod strips both
 * and the gateway receives `undefined` for each. It also cannot set `ResNum` and never
 * checks the settled amount on verify.
 */

/** Shipped defaults. An admin only overrides these to point at a UAT host. */
export const SEP_DEFAULTS = {
  tokenUrl: "https://sep.shaparak.ir/onlinepg/onlinepg",
  verifyUrl: "https://sep.shaparak.ir/verifyTxnRandomSessionkey/ipg/VerifyTransaction",
  paymentUrl: "https://sep.shaparak.ir/OnlinePG/OnlinePG",
};

export type SepEndpoints = typeof SEP_DEFAULTS;

/**
 * SEP answered "no". The purchase is decided: never retry, never settle.
 */
export class SepDeclinedError extends Error {}

/**
 * SEP did not answer at all (timeout, socket error, HTML from a proxy, 5xx). The
 * transaction's fate is unknown, so the caller must retry rather than fail the purchase
 * — SEP's نکته ب is explicit that only a missing answer may be retried, and that an
 * unverified transaction is reversed by SEP after 30 minutes.
 */
export class SepTransportError extends Error {}

/** SEP takes Rial; every amount in this codebase is Toman. */
export const toRial = (toman: number) => Math.round(toman * 10);

/** A receipt has 30 minutes to be verified before SEP reverses it on its own. */
export const VERIFY_WINDOW_MS = 30 * 60 * 1000;

// ponytail: process-local cache, invalidated on write. Two nodes would each hold their
// own copy until the next restart — move to a per-request read if that ever matters.
let cached: PaymentSetting | null = null;

/** The settings row, created on first use so the admin page always has something to edit. */
export const getPaymentSetting = async (): Promise<PaymentSetting> => {
  if (cached) return cached;

  const repository = paymentSettingRepository();
  let setting = await repository.findOne({ where: { id: 1 } });

  if (!setting) {
    setting = await repository.save(
      repository.create({
        id: 1,
        gateway: "saman",
        terminalId: null,
      }),
    );
  }

  cached = setting;
  return setting;
};

export const clearPaymentSettingCache = () => {
  cached = null;
};

const terminalId = async () =>
  (await getPaymentSetting()).terminalId || configs.gatewayConfiguration.terminalId;

/**
 * A stored verify URL pointing at the retired SOAP service is treated as unset: it was
 * saved by an older build, and honouring it would break every settlement.
 */
export const usableVerifyUrl = (stored?: string | null) =>
  !stored || /referencepayment|asmx/i.test(stored) ? SEP_DEFAULTS.verifyUrl : stored;

/**
 * Reverse lives beside verify on the same service, so it is derived rather than being a
 * fourth thing for an admin to keep in sync.
 */
export const reverseUrlFrom = (verifyUrl: string) =>
  verifyUrl.replace(/VerifyTransaction\/?$/i, "ReverseTransaction");

/** Stored overrides win; anything the admin left blank falls back to the shipped default. */
export const endpoints = async (): Promise<SepEndpoints> => {
  const setting = await getPaymentSetting();

  return {
    tokenUrl: setting.tokenUrl || SEP_DEFAULTS.tokenUrl,
    verifyUrl: usableVerifyUrl(setting.verifyUrl),
    paymentUrl: setting.paymentUrl || SEP_DEFAULTS.paymentUrl,
  };
};

/**
 * Where to send the buyer's browser. `GetMethod=true` is what lets SEP accept a plain GET
 * landing — without it the token has to be delivered by an auto-submitting form POST.
 *
 * The buyer must arrive from a link on our own site so the browser sends a `Referer`;
 * SEP rejects a token that arrives without one (نگارش ۳.۶, هدایت کاربر به درگاه).
 */
export const buildStartPayUrl = (paymentUrl: string, token: string) =>
  `${paymentUrl}?Token=${encodeURIComponent(token)}&GetMethod=true`;

export const startPayUrl = async (token: string) =>
  buildStartPayUrl((await endpoints()).paymentUrl, token);

/** SEP wants a bare 10-digit mobile (`9120000000`), not the `0912…` we store. */
export const toSepCellNumber = (phone?: string | null) => {
  const digits = String(phone ?? "").replace(/\D/g, "");
  return digits.length === 11 && digits.startsWith("0") ? digits.slice(1) : digits;
};

/** POSTs JSON and insists on a JSON answer; anything else is "no answer", not "no". */
const postJson = async (url: string, body: Record<string, unknown>): Promise<unknown> => {
  let response: Response;

  try {
    response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
  } catch (error) {
    throw new SepTransportError(
      `SEP did not answer ${url}: ${error instanceof Error ? error.message : "network error"}`,
    );
  }

  if (!response.ok) {
    throw new SepTransportError(`SEP answered HTTP ${response.status} from ${url}`);
  }

  // A wrong URL (a proxy error page, the retired SOAP endpoint) answers 200 with HTML,
  // and a raw parse error tells an admin nothing about which setting is wrong.
  const text = await response.text();

  try {
    return JSON.parse(text);
  } catch {
    throw new SepTransportError(`SEP endpoint ${url} did not answer JSON`);
  }
};

/**
 * Retries only a missing answer, never a refusal — repeating a declined verify would
 * turn one "no" into several without ever changing the outcome.
 */
const withRetries = async <T>(attempt: () => Promise<T>, tries = 3): Promise<T> => {
  let lastError: unknown;

  for (let index = 0; index < tries; index += 1) {
    try {
      return await attempt();
    } catch (error) {
      if (!(error instanceof SepTransportError)) throw error;
      lastError = error;
      await new Promise((resolve) => setTimeout(resolve, 700 * (index + 1)));
    }
  }

  throw lastError;
};

/**
 * Ask SEP for a payment token. `resNum` is our own id for the purchase, echoed back on
 * the callback.
 */
export const requestSepToken = async ({
  amount,
  callbackUrl,
  resNum,
  cellNumber,
}: {
  amount: number;
  callbackUrl: string;
  resNum: number;
  cellNumber?: string | null;
}): Promise<string> => {
  const sepCellNumber = toSepCellNumber(cellNumber);

  const parsed = await postJson((await endpoints()).tokenUrl, {
    Action: "token",
    TerminalId: await terminalId(),
    Amount: toRial(amount),
    RedirectURL: callbackUrl,
    ResNum: String(resNum),
    // Optional: lets the buyer pick a card SEP already holds for this number.
    ...(sepCellNumber ? { CellNumber: sepCellNumber } : {}),
  });

  const data = parsed as {
    status?: number;
    errorCode?: number | string;
    errorDesc?: string;
    token?: string;
  };

  if (data.status !== 1 || !data.token) {
    throw new SepDeclinedError(
      `SEP token request failed: ${data.errorDesc ?? data.errorCode ?? "unknown error"}`,
    );
  }

  return data.token;
};

/** The `TransactionDetail` block of a verify/reverse answer. */
export interface SepTransactionDetail {
  RRN?: string;
  RefNum?: string;
  MaskedPan?: string;
  HashedPan?: string;
  TerminalNumber?: number | string;
  OrginalAmount?: number | string;
  AffectiveAmount?: number | string;
  StraceDate?: string;
  StraceNo?: string;
}

export interface SepVerifyResponse {
  TransactionDetail?: SepTransactionDetail;
  ResultCode?: number | string;
  ResultDescription?: string;
  Success?: boolean;
}

/**
 * Reads a verify answer and returns the amount SEP settled, in Rial.
 *
 * `0` is success and `2` is "you already asked" — SEP re-answers a receipt it has
 * already settled, which is exactly what a retried verify looks like, so both count as
 * settled. Everything else is a refusal.
 *
 * The echoed RefNum and terminal are checked too (بند د): a verify answer that describes
 * a different transaction than the one asked about is not evidence about ours.
 */
export const readVerifyResult = (
  payload: SepVerifyResponse,
  { refNum, terminal }: { refNum: string; terminal: string },
): number => {
  const code = Number(payload?.ResultCode);

  if (code !== 0 && code !== 2) {
    throw new SepDeclinedError(
      `SEP verify failed with code ${payload?.ResultCode ?? "unknown"}${
        payload?.ResultDescription ? `: ${payload.ResultDescription}` : ""
      }`,
    );
  }

  const detail = payload?.TransactionDetail;

  if (!detail) {
    throw new SepDeclinedError("SEP verify answered success without a transaction detail");
  }

  if (String(detail.RefNum) !== String(refNum)) {
    throw new SepDeclinedError(
      `SEP verify answered for RefNum ${detail.RefNum}, asked about ${refNum}`,
    );
  }

  if (String(detail.TerminalNumber) !== String(terminal)) {
    throw new SepDeclinedError(
      `SEP verify answered for terminal ${detail.TerminalNumber}, ours is ${terminal}`,
    );
  }

  return Number(detail.OrginalAmount);
};

/**
 * The money rule, kept pure so it is testable without reaching the gateway: the settled
 * amount must be the amount we sent, or the purchase is not paid for.
 */
export const assertSettled = (settled: number, expectedAmount: number) => {
  if (!Number.isFinite(settled) || settled < 0) {
    throw new SepDeclinedError(`SEP verify failed with code ${settled}`);
  }

  if (settled !== toRial(expectedAmount)) {
    throw new SepDeclinedError(
      `SEP verify amount mismatch: settled ${settled} rial, expected ${toRial(expectedAmount)}`,
    );
  }

  return settled;
};

/**
 * Hand the money back. SEP accepts a reversal for 50 minutes after the transaction, and
 * its documentation requires one whenever the settled amount is not the amount charged
 * (بند ب of the verify comparison) — the buyer must not be left paying for a purchase we
 * are refusing to deliver.
 */
export const reverseSepTransaction = async (refNum: string): Promise<void> => {
  const verifyUrl = (await endpoints()).verifyUrl;
  const terminal = await terminalId();

  await withRetries(() =>
    postJson(reverseUrlFrom(verifyUrl), {
      RefNum: refNum,
      TerminalNumber: Number(terminal),
    }),
  );
};

/**
 * Settle the transaction with SEP.
 *
 * The amount is compared rather than trusted: without it a callback naming someone
 * else's cheaper RefNum would settle an expensive purchase. A mismatch is reversed
 * before the caller is told, because by then SEP has already taken the money.
 *
 * Throws `SepTransportError` when SEP never answered — the caller must keep the purchase
 * pending and try again inside the 30-minute window, not fail it.
 */
export const verifySepTransaction = async ({
  refNum,
  expectedAmount,
}: {
  refNum: string;
  expectedAmount: number;
}): Promise<number> => {
  const terminal = await terminalId();
  const verifyUrl = (await endpoints()).verifyUrl;

  const payload = (await withRetries(() =>
    postJson(verifyUrl, { RefNum: refNum, TerminalNumber: Number(terminal) }),
  )) as SepVerifyResponse;

  const settled = readVerifyResult(payload, { refNum, terminal });

  try {
    return assertSettled(settled, expectedAmount);
  } catch (error) {
    // Money has moved and we are not delivering: give it back before reporting the
    // failure. A reversal that itself fails must not hide the original mismatch.
    await reverseSepTransaction(refNum).catch(() => undefined);
    throw error;
  }
};

/**
 * Claims a receipt for one purchase, refusing a receipt another purchase already used.
 *
 * SEP does not track spent receipts (§7, نکته الف): the same RefNum verifies over and
 * over, and `GetMethod=true` puts it in the buyer's own address bar. Without this, a
 * buyer could replay one paid receipt into a second, unpaid purchase of the same price.
 *
 * Re-claiming for the *same* owner is allowed, so a settlement retried after a network
 * failure still goes through.
 */
export const claimRefNum = async ({
  refNum,
  owner,
  amount,
}: {
  refNum: string;
  owner: string;
  amount: number;
}): Promise<void> => {
  const repository = gatewayReceiptRepository();
  const existing = await repository.findOne({ where: { refNum } });

  if (existing) {
    if (existing.owner === owner) return;
    throw new SepDeclinedError(`RefNum ${refNum} has already been used by ${existing.owner}`);
  }

  try {
    await repository.insert({ refNum, owner, amount });
  } catch (error) {
    // The unique index is the real guard; the read above only produces a better message.
    if ((error as { code?: string })?.code !== "23505") throw error;

    const winner = await repository.findOne({ where: { refNum } });
    if (winner?.owner === owner) return;

    throw new SepDeclinedError(`RefNum ${refNum} has already been used by ${winner?.owner}`);
  }
};

/**
 * Whether the gateway leg settled, read from SEP's callback. SEP posts these as a form
 * body, so callers merge query and body before asking.
 */
export const isSepCallbackSuccessful = (params: Record<string, unknown>) =>
  params.State === "OK" && Boolean(params.RefNum);

/**
 * Ask SEP for a throwaway token using the stored settings, so an admin can tell a bad
 * terminal from a good one without waiting for a real buyer to fail.
 *
 * No money moves: an unused token simply expires. The callback URL is our own, and is
 * never reached because nobody is sent to the payment page.
 */
export const testSepConnection = async (): Promise<{ ok: boolean; message: string }> => {
  try {
    await requestSepToken({
      amount: 1_000,
      callbackUrl: `${configs.apiUrl}/api/user/purchase/callback/?requestId=0`,
      // Negative so it can never collide with a real purchase id if it somehow surfaces.
      resNum: -1,
    });

    return { ok: true, message: "اتصال به درگاه سامان برقرار است." };
  } catch (error) {
    return {
      ok: false,
      message: error instanceof Error ? error.message : "اتصال به درگاه سامان برقرار نشد.",
    };
  }
};
