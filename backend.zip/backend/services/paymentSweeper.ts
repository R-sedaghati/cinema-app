import { LessThan } from "typeorm";
import { contactRequestRepository, paymentRepository } from "../models/index.js";
import { PaymentStatus } from "../utils/enum.js";
import { SepTransportError, VERIFY_WINDOW_MS } from "./gateway.js";
import {
  failContactRequest,
  failRegistrationPayment,
  settleContactRequest,
  settleRegistrationPayment,
} from "./settlement.js";

/**
 * Finishes what the callback did not.
 *
 * Two things leave a purchase stuck PENDING: the buyer closes the tab before SEP
 * redirects them back, and SEP failing to answer our verify. Both are ordinary, and
 * both used to strand the wallet balance the purchase had reserved.
 *
 * SEP verifies a receipt for 30 minutes and reverses it after that (نکته ت), so this
 * pass has exactly the same deadline: inside the window, retry the verify with the
 * RefNum the callback managed to store; past it, the money is back with the cardholder
 * and the purchase is simply failed — which is what releases the wallet reservation.
 */

const SWEEP_INTERVAL_MS = 5 * 60 * 1000;

/** One pass. Exported so it can be run by hand, and so the interval stays trivial. */
export const sweepStalePayments = async () => {
  const staleBefore = new Date(Date.now() - VERIFY_WINDOW_MS);

  const payments = await paymentRepository().find({
    where: { status: PaymentStatus.PENDING },
    relations: { artistRequest: { user: true } },
  });

  for (const payment of payments) {
    try {
      if (payment.refNum && payment.createdAt > staleBefore) {
        await settleRegistrationPayment(payment, payment.refNum);
        continue;
      }

      if (payment.createdAt <= staleBefore) {
        await failRegistrationPayment(payment);
      }
    } catch (error) {
      // No answer from SEP — leave it pending and try again next pass, while the window
      // is still open. Anything else is a real refusal.
      if (error instanceof SepTransportError) continue;
      await failRegistrationPayment(payment).catch(() => undefined);
    }
  }

  const contactRequests = await contactRequestRepository().find({
    where: { status: PaymentStatus.PENDING },
    relations: { artistRequest: true, buyer: true },
  });

  for (const contactRequest of contactRequests) {
    try {
      if (contactRequest.refNum && contactRequest.createdAt > staleBefore) {
        await settleContactRequest(contactRequest, contactRequest.refNum);
        continue;
      }

      if (contactRequest.createdAt <= staleBefore) {
        await failContactRequest(contactRequest);
      }
    } catch (error) {
      if (error instanceof SepTransportError) continue;
      await failContactRequest(contactRequest).catch(() => undefined);
    }
  }
};

/**
 * Runs the pass every five minutes. `unref` so it never holds the process open, and a
 * flag rather than a queue: a pass that overruns simply skips the next tick.
 */
export const startPaymentSweeper = () => {
  let running = false;

  const timer = setInterval(async () => {
    if (running) return;
    running = true;

    try {
      await sweepStalePayments();
    } catch (error) {
      console.error("payment sweep failed:", error);
    } finally {
      running = false;
    }
  }, SWEEP_INTERVAL_MS);

  timer.unref();
  return timer;
};
