import { test } from "node:test";
import assert from "node:assert/strict";
import { sanitizePhones } from "./adminNotify.js";

test("Persian digits and separators are normalized, duplicates dropped", () => {
  assert.deepEqual(
    sanitizePhones(["\u06f0\u06f9\u06f1\u06f2\u06f3\u06f4\u06f5\u06f6\u06f7\u06f8\u06f9", "0912-345 6789", ""]),
    ["09123456789"],
  );
});

test("a non-mobile number rejects the whole list", () => {
  assert.equal(sanitizePhones(["09123456789", "12345"]), null);
});

test("an empty list is valid — it disables admin SMS", () => {
  assert.deepEqual(sanitizePhones([]), []);
});
