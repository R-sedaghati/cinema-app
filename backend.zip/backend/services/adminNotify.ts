import { notificationSettingRepository } from "../models/index.js";
import { NotificationSetting } from "../entities/NotificationSetting.js";
import { NotificationEvent } from "../utils/enum.js";
import { sendMelliSms } from "./melliPayamak.js";
import { toEnglishDigits } from "../utils/fieldValidation.js";
import { configs } from "../config/configs.js";

/**
 * Admin SMS fan-out. The settings row is read on nearly every notifiable action, so it
 * is cached the same way the gateway settings are; the admin controller drops the cache
 * on save.
 */
let cached: NotificationSetting | null = null;

export const getNotificationSetting = async (): Promise<NotificationSetting> => {
  if (cached) return cached;

  const repository = notificationSettingRepository();
  let setting = await repository.findOne({ where: { id: 1 } });

  if (!setting) {
    setting = await repository.save(
      repository.create({ id: 1, phones: [], events: [] }),
    );
  }

  cached = setting;
  return setting;
};

export const clearNotificationSettingCache = () => {
  cached = null;
};

/**
 * Text every admin who has opted into `event`. Fire-and-forget by design: the caller has
 * already committed the thing being announced, so a dead SMS panel must not turn a saved
 * request or a settled payment into a 500. Failures are logged, never thrown.
 */
export const notifyAdmins = (event: NotificationEvent, message: string) => {
  void (async () => {
    try {
      const { phones, events } = await getNotificationSetting();

      if (!events.includes(event) || phones.length === 0) return;

      await Promise.all(
        phones.map((phone) =>
          sendMelliSms(phone, configs.melliPayamakSender, message),
        ),
      );
    } catch (e) {
      console.error(`admin notify (${event}) failed:`, e);
    }
  })();
};

/**
 * Clean a submitted recipient list, or `null` if any entry is not a mobile number.
 * Persian digits are what a phone keyboard actually produces, so they are accepted and
 * stored as ASCII; duplicates are dropped because a number listed twice is texted twice.
 */
export const sanitizePhones = (phones: unknown[]): string[] | null => {
  const normalized = phones
    .map((p) => toEnglishDigits(String(p ?? "")).trim().replace(/[\s-]/g, ""))
    .filter(Boolean);

  if (!normalized.every((p) => /^09\d{9}$/.test(p))) return null;

  return [...new Set(normalized)];
};
