import assert from "node:assert/strict";
import { applyWallet as split } from "../services/wallet.js";

/**
 * The wallet split: how much a purchase takes from the balance and how much is left for
 * the gateway. Getting this wrong either double-charges the user or gives away listings,
 * so the arithmetic is pinned here.
 *
 * The DB-bound parts (row locking, ledger writes) are not covered — this is the pure
 * split that `spend` and the two purchase controllers rely on.
 * Run:
 *   node --loader ts-node/esm ./scripts/checkWallet.ts
 */


// Empty wallet: the gateway charges the whole price.
assert.deepEqual(split(0, 200_000), { applied: 0, dueAtGateway: 200_000 });

// Partial balance tops up the difference — the case the feature exists for.
assert.deepEqual(split(50_000, 200_000), { applied: 50_000, dueAtGateway: 150_000 });

// Exactly covered: nothing reaches the gateway. This is the post-revision path, where
// the refund equals the fee.
assert.deepEqual(split(200_000, 200_000), { applied: 200_000, dueAtGateway: 0 });

// Surplus balance is not overspent — only the price is taken.
assert.deepEqual(split(500_000, 200_000), { applied: 200_000, dueAtGateway: 0 });

// A free category costs nothing even with a balance sitting there.
assert.deepEqual(split(500_000, 0), { applied: 0, dueAtGateway: 0 });

// A negative balance (an admin clawback that outran the balance) must never be treated
// as credit, and must never make the gateway charge more than the price.
assert.deepEqual(split(-50_000, 200_000), { applied: 0, dueAtGateway: 200_000 });

// The split always reconstructs the price — no money invented or lost.
for (const balance of [-10, 0, 1, 49_999, 200_000, 10 ** 9]) {
  for (const price of [0, 1, 200_000, 2_000_000]) {
    const { applied, dueAtGateway } = split(balance, price);
    assert.equal(applied + dueAtGateway, price, `${balance}/${price}`);
    assert.ok(applied >= 0 && dueAtGateway >= 0, `${balance}/${price}`);
  }
}

console.log("wallet checks passed");
