import assert from "node:assert/strict";
import type { FormField } from "../entities/FormField.js";
import { FormFieldType, SyncToUserField } from "../utils/enum.js";
import {
  answerParam,
  buildAnswerFilterMap,
  isFilterableField,
} from "../utils/answerFilters.js";

/**
 * Answer filter keys are interpolated into raw SQL as identifiers, so this guards the
 * injection boundary and the numeric-cast rule. Run:
 *   node --loader ts-node/esm ./scripts/checkAnswerFilters.ts
 */

const field = (partial: Partial<FormField>): FormField =>
  ({
    key: "city",
    label: "شهر",
    type: FormFieldType.TEXT,
    required: false,
    order: 0,
    multiple: false,
    ...partial,
  }) as FormField;

// A key that is not a bare identifier never reaches SQL.
assert.equal(isFilterableField(field({ key: "x'; DROP TABLE artist_requests; --" })), false);
assert.equal(isFilterableField(field({ key: "city name" })), false);
assert.equal(isFilterableField(field({ key: "city" })), true);

// Only keys present in the category's schema produce a column; anything else is absent
// from the map, and SearchAndFilterService drops params it cannot resolve to a column.
const map = buildAnswerFilterMap([
  field({ key: "city", type: FormFieldType.TEXT }),
  field({ key: "height", type: FormFieldType.NUMBER }),
  field({ key: "styles", type: FormFieldType.CHECKBOX }),
  field({ key: "aboutMe", type: FormFieldType.TEXTAREA }),
  field({ key: "fullName", type: FormFieldType.TEXT, syncToUserField: SyncToUserField.firstName }),
  field({ key: "bad key", type: FormFieldType.TEXT }),
]);

assert.deepEqual(Object.keys(map).sort(), [
  "answers.city",
  "answers.height",
  "answers.styles",
]);
assert.equal(map["answers.aboutMe"], undefined, "free-text fields are not facets");
assert.equal(map["answers.fullName"], undefined, "identity fields are not facets");

// NUMBER must be cast, or "9" > "10" lexicographically.
assert.equal(map["answers.height"], "(artists.answers ->> 'height')::numeric");
assert.equal(map["answers.city"], "artists.answers ->> 'city'");
// Array answers stay jsonb so `hasany` can unnest them.
assert.equal(map["answers.styles"], "artists.answers -> 'styles'");

assert.equal(answerParam(field({ key: "city", type: FormFieldType.TEXT })), "answers.city__in");
assert.equal(answerParam(field({ key: "height", type: FormFieldType.NUMBER })), "answers.height");
assert.equal(
  answerParam(field({ key: "styles", type: FormFieldType.CHECKBOX })),
  "answers.styles__hasany"
);

console.log("answer filter checks passed");
