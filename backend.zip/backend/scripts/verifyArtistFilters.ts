import assert from "node:assert/strict";
import { AppDataSource } from "../config/database.js";
import { Category } from "../entities/Category.js";
import { FormStep } from "../entities/FormStep.js";
import { FormField } from "../entities/FormField.js";
import { ArtistRequest } from "../entities/ArtistRequest.js";
import { User } from "../entities/User.js";
import { ArtistRequestStatus, FormFieldType, PaymentStatus, SyncToUserField } from "../utils/enum.js";
import { SearchAndFilterService } from "../services/searchAndFilter.js";
import { buildAnswerFilterMap } from "../utils/answerFilters.js";
import { getAllFieldsForCategory } from "../utils/formSchema.js";
import { getArtistFiltersController } from "../controllers/common/artistFiltersController.js";
import { getRetrieveArtistsRequests } from "../controllers/user/artistRequestController.js";
import { getArtistContactController, getContactRequestPriceController } from "../controllers/user/contactRequestController.js";
import { configs } from "../config/configs.js";
import { ContactRequest } from "../entities/ContactRequest.js";
import {
  publicAnswersSearchExpression,
  publicExcludedAnswerKeys,
} from "../utils/privacy.js";

/**
 * Exercises the answer-filter SQL against a real Postgres, which the pure-unit
 * checkAnswerFilters.ts cannot do (jsonb operators, numeric casts, array unnesting).
 *
 * DATABASE_URL=postgres://... node --loader ts-node/esm ./scripts/verifyArtistFilters.ts
 */

const fakeRes = () => {
  const captured: { status: number; body: any } = { status: 0, body: null };
  return {
    captured,
    res: {
      status(code: number) {
        captured.status = code;
        return this;
      },
      json(body: any) {
        captured.body = body;
        return this;
      },
    } as any,
  };
};

async function run() {
  await AppDataSource.initialize();

  // --- fixtures -----------------------------------------------------------
  const categoryRepo = AppDataSource.getRepository(Category);
  const stepRepo = AppDataSource.getRepository(FormStep);
  const fieldRepo = AppDataSource.getRepository(FormField);
  const artistRepo = AppDataSource.getRepository(ArtistRequest);
  const userRepo = AppDataSource.getRepository(User);

  const acting = await categoryRepo.save(
    categoryRepo.create({ faName: "بازیگری", enName: "acting" }),
  );
  const voice = await categoryRepo.save(
    categoryRepo.create({ faName: "صداپیشگی", enName: "voice", parent: acting }),
  );

  const step = await stepRepo.save(
    stepRepo.create({ category: acting, title: "اطلاعات", order: 0 }),
  );

  await fieldRepo.save([
    fieldRepo.create({ step, key: "city", label: "شهر", type: FormFieldType.TEXT, order: 0 }),
    fieldRepo.create({ step, key: "height", label: "قد", type: FormFieldType.NUMBER, order: 1 }),
    fieldRepo.create({
      step,
      key: "styles",
      label: "سبک",
      type: FormFieldType.CHECKBOX,
      order: 2,
      options: [
        { label: "کمدی", value: "comedy" },
        { label: "درام", value: "drama" },
      ],
    }),
    fieldRepo.create({ step, key: "aboutMe", label: "درباره من", type: FormFieldType.TEXTAREA, order: 3 }),
  ]);

  const makeArtist = async (
    code: string,
    categories: Category[],
    answers: Record<string, unknown>,
  ) => {
    const user = await userRepo.save(
      userRepo.create({ phone_number: `0912${code}`, code } as Partial<User>),
    );
    // ArtistRequest.generateTrackingCode() slices a 13-digit timestamp to 12 chars,
    // discarding its random suffix — inserts inside the same 10ms window collide on
    // the unique tracking_code. Spacing the fixtures works around that.
    await new Promise((resolve) => setTimeout(resolve, 15));
    return artistRepo.save(
      artistRepo.create({
        user,
        categories,
        answers,
        status: ArtistRequestStatus.APPROVED,
      }),
    );
  };

  await makeArtist("1001", [acting], {
    city: "تهران",
    height: "180",
    styles: ["comedy"],
    aboutMe: "بازیگر تئاتر",
  });
  await makeArtist("1002", [acting], {
    city: "کرج",
    height: "9",
    styles: ["drama", "comedy"],
    aboutMe: "بازیگر سینما",
  });
  // Tagged only with the child category — must still match a parent selection.
  await makeArtist("1003", [voice], { city: "تهران", height: "170", styles: ["drama"] });

  // --- filters endpoint ---------------------------------------------------
  const { res, captured } = fakeRes();
  await getArtistFiltersController({ params: { id: String(acting.id) } } as any, res);

  const descriptors: any[] = captured.body.result;
  const byKey = Object.fromEntries(descriptors.map((d) => [d.key, d]));

  assert.equal(byKey.aboutMe, undefined, "TEXTAREA is not a facet");

  // TEXT options come from what artists actually answered, across parent + children.
  assert.equal(byKey.city.kind, "select");
  assert.equal(byKey.city.param, "answers.city__in");
  assert.deepEqual(
    byKey.city.options.map((o: any) => [o.value, o.count]).sort(),
    [["تهران", 2], ["کرج", 1]].sort(),
  );

  // CHECKBOX options are admin-authored, and its param uses the array-aware operator.
  assert.equal(byKey.styles.param, "answers.styles__hasany");
  assert.deepEqual(
    byKey.styles.options.map((o: any) => o.value),
    ["comedy", "drama"],
  );

  // NUMBER bounds are numeric, not lexicographic: min is 9, not "170".
  assert.equal(byKey.height.kind, "range");
  assert.equal(byKey.height.min, 9);
  assert.equal(byKey.height.max, 180);
  assert.equal(byKey.height.paramMin, "answers.height__gte");

  // --- filtered list query -------------------------------------------------
  const answerFilterable = buildAnswerFilterMap(await getAllFieldsForCategory(acting.id));

  const listCodes = async (params: Record<string, unknown>) => {
    const qb = artistRepo
      .createQueryBuilder("artists")
      .leftJoinAndSelect("artists.categories", "categories")
      .distinct(true)
      .leftJoinAndSelect("artists.user", "user")
      .where("status=:status", { status: ArtistRequestStatus.APPROVED });

    qb.andWhere(
      "artists.id IN " +
        qb
          .subQuery()
          .select("tagged.id")
          .from(ArtistRequest, "tagged")
          .innerJoin("tagged.categories", "tagged_category")
          .where("tagged_category.id IN (:...categoryIds)")
          .getQuery(),
      { categoryIds: [acting.id, voice.id] },
    );

    const service = new SearchAndFilterService<ArtistRequest>(qb, {
      filterable: { category: "categories.id", ...answerFilterable },
      searchable: ["categories.faName", "user.code", "artists.answers::text"],
      sortable: { category: "categories.faName" },
    });

    const [rows] = await service.apply(params).getManyAndCount();
    return rows.map((row) => row.user.code).sort();
  };

  // Parent selection reaches the child-only artist.
  assert.deepEqual(await listCodes({}), ["1001", "1002", "1003"]);

  assert.deepEqual(await listCodes({ "answers.city__in": "تهران" }), ["1001", "1003"]);
  assert.deepEqual(await listCodes({ "answers.city__in": "تهران,کرج" }), [
    "1001",
    "1002",
    "1003",
  ]);

  // Numeric comparison, not string: "9" must NOT be >= 170.
  assert.deepEqual(await listCodes({ "answers.height__gte": "170" }), ["1001", "1003"]);
  assert.deepEqual(
    await listCodes({ "answers.height__gte": "170", "answers.height__lte": "175" }),
    ["1003"],
  );

  // Array answers.
  assert.deepEqual(await listCodes({ "answers.styles__hasany": "drama" }), ["1002", "1003"]);
  assert.deepEqual(await listCodes({ "answers.styles__hasany": "comedy,drama" }), [
    "1001",
    "1002",
    "1003",
  ]);

  // Free text now reaches answers, not just category names.
  assert.deepEqual(await listCodes({ search: "سینما" }), ["1002"]);
  assert.deepEqual(await listCodes({ search: "کرج" }), ["1002"]);

  // Unknown / hostile keys resolve to no column and are dropped, not executed.
  assert.deepEqual(await listCodes({ "answers.nope__in": "x" }), ["1001", "1002", "1003"]);
  assert.deepEqual(
    await listCodes({ "answers.x'; DROP TABLE artist_requests; --__in": "x" }),
    ["1001", "1002", "1003"],
  );
  assert.equal(
    await artistRepo.count(),
    3,
    "table still exists after injection attempt",
  );

  // Empty list values must not emit `IN ()`.
  assert.deepEqual(await listCodes({ "answers.city__in": "" }), ["1001", "1002", "1003"]);

  // --- privacy: contact details are paid content --------------------------
  const nameField = await fieldRepo.save(
    fieldRepo.create({
      step,
      key: "fullName",
      label: "نام و نام خانوادگی",
      type: FormFieldType.TEXT,
      order: 4,
      syncToUserField: SyncToUserField.firstName,
    }),
  );
  await fieldRepo.save(
    fieldRepo.create({
      step,
      key: "email",
      label: "ایمیل",
      type: FormFieldType.TEXT,
      order: 5,
    }),
  );

  const priv = await artistRepo.findOneOrFail({
    where: { user: { code: "1001" } },
    relations: { user: true },
  });
  priv.answers = {
    ...priv.answers,
    fullName: "مهسا رضایی",
    email: "mahsa@example.com",
    postalCode: "1234567890",
    address: "تهران، خیابان ولیعصر",
  };
  await artistRepo.save(priv);

  const excluded = await publicExcludedAnswerKeys();
  assert.ok(excluded.includes("fullName"), "conventional key");
  assert.ok(excluded.includes("email"));
  assert.ok(excluded.includes("postalCode"));
  assert.ok(excluded.includes("address"));
  assert.ok(excluded.includes(nameField.key), "syncToUserField-derived key");

  // The public detail endpoint must not carry name or contact in its payload.
  const detail = fakeRes();
  await getRetrieveArtistsRequests({ params: { id: String(priv.id) } } as any, detail.res);
  const body = JSON.stringify(detail.captured.body);

  assert.equal(detail.captured.body.result.user.firstName, undefined);
  assert.equal(detail.captured.body.result.user.phoneNumber, undefined);
  assert.equal(detail.captured.body.result.answers.fullName, undefined);
  assert.equal(detail.captured.body.result.answers.email, undefined);
  assert.equal(detail.captured.body.result.answers.postalCode, undefined);
  assert.ok(!body.includes("مهسا رضایی"), "name absent from public payload");
  assert.ok(!body.includes("mahsa@example.com"), "email absent from public payload");
  assert.ok(!body.includes("1234567890"), "postal code absent from public payload");
  // Non-private answers still come through.
  assert.equal(detail.captured.body.result.answers.city, "تهران");

  // Private answers must not be reachable through free-text search either.
  const searchable = await publicAnswersSearchExpression();
  const searchCodes = async (term: string) => {
    const qb = artistRepo
      .createQueryBuilder("artists")
      .leftJoinAndSelect("artists.user", "user")
      .leftJoin("artists.categories", "categories")
      .where("status=:status", { status: ArtistRequestStatus.APPROVED });

    const service = new SearchAndFilterService<ArtistRequest>(qb, {
      filterable: {},
      searchable: ["categories.faName", "user.code", searchable],
      sortable: {},
    });
    const [rows] = await service.apply({ search: term }).getManyAndCount();
    return rows.map((row) => row.user.code);
  };

  assert.deepEqual(await searchCodes("مهسا"), [], "name is not searchable");
  assert.deepEqual(await searchCodes("mahsa@example.com"), [], "email is not searchable");
  assert.deepEqual(await searchCodes("تهران"), ["1001", "1003"], "public answers still search");

  // Nor may they surface as filter facet options.
  const filters = fakeRes();
  await getArtistFiltersController({ params: { id: String(acting.id) } } as any, filters.res);
  const facetKeys = filters.captured.body.result.map((d: any) => d.key);
  assert.ok(!facetKeys.includes("fullName"), "identity field is not a facet");
  assert.ok(!facetKeys.includes("email"), "contact field is not a facet");

  // --- the paywall --------------------------------------------------------
  const contactRepo = AppDataSource.getRepository(ContactRequest);

  // The artist whose details are for sale, with a real name and phone on the User row.
  priv.user.firstName = "مهسا";
  priv.user.lastName = "رضایی";
  await userRepo.save(priv.user);

  const buyer = await userRepo.save(
    userRepo.create({ phone_number: "09120000001", code: "BUYER" } as Partial<User>),
  );

  const callContact = async (asUser: User) => {
    const captured = fakeRes();
    await getArtistContactController(
      { params: { id: String(priv.id) }, payload: { user: asUser } } as any,
      captured.res,
    );
    return captured.captured;
  };

  // No purchase at all.
  let attempt = await callContact(buyer);
  assert.equal(attempt.status, 403, "unpaid buyer is refused");
  assert.equal(attempt.body.result, undefined, "no contact payload leaks on refusal");

  // A started-but-unpaid request must not unlock anything.
  const pending = await contactRepo.save(
    contactRepo.create({
      buyer: { id: buyer.id },
      artistRequest: { id: priv.id },
      requesterName: "خریدار",
      amount: 20_000_000,
      status: PaymentStatus.PENDING,
    }),
  );
  attempt = await callContact(buyer);
  assert.equal(attempt.status, 403, "PENDING payment does not unlock");

  // Settled purchase.
  pending.status = PaymentStatus.COMPLETED;
  await contactRepo.save(pending);
  attempt = await callContact(buyer);
  assert.equal(attempt.body.result.firstName, "مهسا");
  assert.equal(attempt.body.result.phoneNumber, priv.user.phone_number);
  assert.equal(attempt.body.result.email, "mahsa@example.com");
  assert.equal(attempt.body.result.address, "تهران، خیابان ولیعصر");
  assert.equal(attempt.body.result.postalCode, "1234567890");

  // A purchase is per-artist: it must not unlock a different one.
  const other = await artistRepo.findOneOrFail({
    where: { user: { code: "1002" } },
    relations: { user: true },
  });
  const otherAttempt = fakeRes();
  await getArtistContactController(
    { params: { id: String(other.id) }, payload: { user: buyer } } as any,
    otherAttempt.res,
  );
  assert.equal(otherAttempt.captured.status, 403, "purchase does not carry to other artists");

  // The artist sees their own details without paying.
  attempt = await callContact(priv.user);
  assert.equal(attempt.body.result.phoneNumber, priv.user.phone_number);

  // --- pricing ------------------------------------------------------------
  const price = async (artistRequestId: number) => {
    const captured = fakeRes();
    await getContactRequestPriceController(
      { params: { id: String(artistRequestId) } } as any,
      captured.res,
    );
    return captured.captured;
  };

  // Unset on the category → config fallback.
  assert.equal(
    (await price(priv.id)).body.result.amount,
    configs.contactRequestFallbackAmount,
  );

  // Admin sets it on the category.
  acting.contactAmount = 3_500_000;
  await categoryRepo.save(acting);
  assert.equal((await price(priv.id)).body.result.amount, 3_500_000);

  // A child category with no price of its own inherits the parent's.
  const childOnly = await artistRepo.findOneOrFail({
    where: { user: { code: "1003" } },
    relations: { user: true, categories: true },
  });
  assert.equal((await price(childOnly.id)).body.result.amount, 3_500_000);

  // Its own price wins over the parent's.
  voice.contactAmount = 900_000;
  await categoryRepo.save(voice);
  assert.equal((await price(childOnly.id)).body.result.amount, 900_000);

  assert.equal((await price(999_999)).status, 404, "unknown artist has no price");

  console.log("artist filter + privacy + paywall + pricing integration checks passed");
  await AppDataSource.destroy();
}

run().catch((error) => {
  console.error(error);
  process.exit(1);
});
