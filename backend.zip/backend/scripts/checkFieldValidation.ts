import assert from "node:assert/strict";
import type { FormField } from "../entities/FormField.js";
import { FormFieldType } from "../utils/enum.js";
import { validateAnswer, validateAnswers } from "../utils/fieldValidation.js";

/**
 * The national-code checksum and the digit normalisation are the parts worth guarding.
 * Run:
 *   node --loader ts-node/esm ./scripts/checkFieldValidation.ts
 */

const field = (partial: Partial<FormField>): FormField =>
  ({
    key: "nationalCode",
    label: "کد ملی",
    type: FormFieldType.TEXT,
    required: false,
    order: 0,
    validation: null,
    ...partial,
  }) as FormField;

const nationalCode = field({ validation: { preset: "NATIONAL_CODE" } });

// 0084575948 is a valid code; flipping the check digit is not.
assert.equal(validateAnswer(nationalCode, "0084575948"), null);
assert.notEqual(validateAnswer(nationalCode, "0084575949"), null);
assert.notEqual(validateAnswer(nationalCode, "1111111111"), null);
assert.notEqual(validateAnswer(nationalCode, "123"), null);

// Persian digits are normalised before the check.
assert.equal(validateAnswer(nationalCode, "۰۰۸۴۵۷۵۹۴۸"), null);

// An empty optional answer is not a validation failure — `required` is a separate gate.
assert.equal(validateAnswer(nationalCode, ""), null);
assert.equal(validateAnswer(nationalCode, undefined), null);

const mobile = field({ key: "phone", label: "موبایل", validation: { preset: "MOBILE" } });
assert.equal(validateAnswer(mobile, "09121234567"), null);
assert.notEqual(validateAnswer(mobile, "9121234567"), null);

// Length rules apply to the raw string.
const bio = field({ key: "bio", label: "درباره من", validation: { minLength: 5, maxLength: 8 } });
assert.notEqual(validateAnswer(bio, "abc"), null);
assert.equal(validateAnswer(bio, "abcdef"), null);
assert.notEqual(validateAnswer(bio, "abcdefghi"), null);

// NUMBER fields compare numerically, so "9" is not above a max of 10.
const height = field({
  key: "height",
  label: "قد",
  type: FormFieldType.NUMBER,
  validation: { min: 5, max: 10 },
});
assert.equal(validateAnswer(height, "9"), null);
assert.notEqual(validateAnswer(height, "11"), null);
assert.notEqual(validateAnswer(height, "abc"), null);

// An unparsable admin regex rejects nothing rather than every answer.
const weird = field({ key: "weird", label: "عجیب", validation: { pattern: "([" } });
assert.equal(validateAnswer(weird, "anything"), null);

assert.deepEqual(validateAnswers([nationalCode, mobile], { nationalCode: "0084575948", phone: "09121234567" }), []);
assert.equal(validateAnswers([nationalCode, mobile], { nationalCode: "1", phone: "1" }).length, 2);

console.log("field validation checks passed");
