import assert from "node:assert/strict";
import { isAmountSet, normalizeAmount } from "../utils/amount.js";

/**
 * 0 (free) and null (unset) mean different things on the money path, and the
 * obvious truthiness check silently turns the first into the second.
 * Run:
 *   node --loader ts-node/esm ./scripts/checkAmount.ts
 */

// A free price survives the round trip. This is the whole point of the helper.
assert.equal(normalizeAmount(0), 0);
assert.equal(normalizeAmount("0"), 0);
assert.equal(isAmountSet(normalizeAmount(0)), true);

// "Not set" stays null so the category can inherit its parent's price.
assert.equal(normalizeAmount(null), null);
assert.equal(normalizeAmount(undefined), null);
assert.equal(normalizeAmount(""), null);
assert.equal(isAmountSet(null), false);
assert.equal(isAmountSet(undefined), false);

// Junk and negatives are "unset", never a charge.
assert.equal(normalizeAmount("abc"), null);
assert.equal(normalizeAmount(Number.NaN), null);
assert.equal(normalizeAmount(Number.POSITIVE_INFINITY), null);
assert.equal(normalizeAmount(-1), null);

// Real prices are stored as whole Toman.
assert.equal(normalizeAmount(5000), 5000);
assert.equal(normalizeAmount("5000"), 5000);
assert.equal(normalizeAmount(4999.6), 5000);

console.log("amount checks passed");
