import { IsNull } from "typeorm";
import { AppDataSource } from "../config/database.js";
import { Category } from "../entities/Category.js";
import { FormStep } from "../entities/FormStep.js";
import { FormField } from "../entities/FormField.js";
import { FormFieldType, SyncToUserField } from "../utils/enum.js";

// ponytail: legacy Category.config (12 boolean flags) is gone from the schema;
// this backfills the equivalent FormStep/FormField rows so pre-existing
// top-level categories still get a registration form. One-time, idempotent.
const DEFAULT_FIELDS: {
  key: string;
  label: string;
  type: FormFieldType;
  syncToUserField?: SyncToUserField;
}[] = [
  { key: "fullName", label: "نام و نام خانوادگی", type: FormFieldType.TEXT, syncToUserField: SyncToUserField.firstName },
  { key: "profileImage", label: "بارگذاری تصویر پروفایل", type: FormFieldType.IMAGE, syncToUserField: SyncToUserField.avatar },
  { key: "email", label: "ایمیل", type: FormFieldType.TEXT, syncToUserField: SyncToUserField.email },
  { key: "province", label: "استان", type: FormFieldType.TEXT },
  { key: "city", label: "شهر", type: FormFieldType.TEXT },
  { key: "address", label: "آدرس", type: FormFieldType.TEXTAREA },
  { key: "postalCode", label: "کد پستی", type: FormFieldType.TEXT },
  { key: "education", label: "تحصیلات", type: FormFieldType.TEXT },
  { key: "educationField", label: "رشته تحصیلی", type: FormFieldType.TEXT },
  { key: "aboutMe", label: "درباره من", type: FormFieldType.TEXTAREA },
  { key: "portfolioImage", label: "بارگذاری نمونه کار (عکس)", type: FormFieldType.IMAGE },
  { key: "portfolioVideo", label: "بارگذاری نمونه کار (ویدئو)", type: FormFieldType.VIDEO },
];

async function run() {
  try {
    if (!AppDataSource.isInitialized) {
      await AppDataSource.initialize();
    }

    const categoryRepo = AppDataSource.getRepository(Category);
    const stepRepo = AppDataSource.getRepository(FormStep);
    const fieldRepo = AppDataSource.getRepository(FormField);

    const topLevelCategories = await categoryRepo.find({ where: { parent: IsNull() } });

    let seededCategories = 0;

    for (const category of topLevelCategories) {
      const existingStep = await stepRepo.findOne({ where: { category: { id: category.id } } });
      if (existingStep) {
        continue;
      }

      const step = await stepRepo.save(
        stepRepo.create({ category, title: "اطلاعات ثبت‌نام", order: 0 }),
      );

      await fieldRepo.save(
        DEFAULT_FIELDS.map((field, index) =>
          fieldRepo.create({
            step,
            key: field.key,
            label: field.label,
            type: field.type,
            required: true,
            order: index,
            syncToUserField: field.syncToUserField ?? null,
          }),
        ),
      );

      seededCategories += 1;
      console.log(`Seeded default form for category ${category.id} (${category.faName})`);
    }

    console.log(
      `Done. Seeded ${seededCategories} of ${topLevelCategories.length} top-level categories (rest already had a form).`,
    );
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

run();
