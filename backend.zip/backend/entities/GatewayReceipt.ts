import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn } from "typeorm";

/**
 * Every digital receipt (RefNum) SEP has ever settled for us, one row each.
 *
 * SEP's own documentation (§7, نکته الف) is explicit that it does *not* track whether a
 * receipt has been spent: verifying the same RefNum twice succeeds twice. Preventing a
 * receipt from paying for two different purchases is the merchant's job, and this table
 * is how it is done — the unique index is the guard, not the read before it.
 *
 * `owner` is the purchase that claimed the receipt (`payment:12`, `contact:5`), so a
 * retry of *our own* settlement is allowed through while someone else's replay is not.
 */
@Entity({ name: "gateway_receipts" })
export class GatewayReceipt {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column({ type: "varchar", name: "ref_num", unique: true })
  refNum!: string;

  @Column({ type: "varchar" })
  owner!: string;

  @Column({ type: "float" })
  amount!: number;

  @CreateDateColumn({ name: "created_at" })
  createdAt!: Date;
}
