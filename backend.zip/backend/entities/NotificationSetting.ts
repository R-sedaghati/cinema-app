import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";
import { Base } from "./base/base.js";
import { NotificationEvent } from "../utils/enum.js";

/**
 * Who gets an admin SMS, and for what. Single row (id 1), created on first read —
 * same shape as PaymentSetting, so switching the on-call number needs no redeploy.
 *
 * Both lists are stored whole rather than as rows: the admin form always submits the
 * full list, so there is nothing to merge and no id for the page to track.
 */
@Entity({ name: "notification_settings" })
export class NotificationSetting extends Base {
  @PrimaryGeneratedColumn()
  id!: number;

  /** Normalized `09xxxxxxxxx`. Empty disables admin SMS entirely. */
  @Column({ type: "simple-array", name: "phones", default: "" })
  phones!: string[];

  /** Which events send a message. Empty means "store the numbers but stay quiet". */
  @Column({ type: "simple-array", name: "events", default: "" })
  events!: NotificationEvent[];
}
