import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from "typeorm";
import { Base } from "./base/base.js";
import { WalletTransactionType } from "../utils/enum.js";

/**
 * One movement of money in a user's wallet.
 *
 * There is no stored balance anywhere — the balance IS the sum of these rows. That costs
 * a SUM per read and buys the guarantee that a balance can never drift out of step with
 * its own history, which a cached column eventually does.
 *
 * `amount` is signed: positive credits the user, negative debits them.
 */
@Entity({ name: "wallet_transactions" })
export class WalletTransaction extends Base {
  @PrimaryGeneratedColumn()
  id!: number;

  @ManyToOne("User", { onDelete: "CASCADE", nullable: false })
  @JoinColumn({ name: "user_id" })
  user!: any;

  /** Toman. Positive = credit, negative = debit. Never zero. */
  @Column({ type: "int" })
  amount!: number;

  @Column({ type: "enum", enum: WalletTransactionType })
  type!: WalletTransactionType;

  /** Shown to the user, so it is written in Persian at the call site. */
  @Column({ type: "varchar", nullable: true })
  description?: string | null;

  /**
   * The registration payment this row refunds. Also the idempotency key: a payment can
   * only be refunded once, so a re-run of the same status change cannot pay twice.
   */
  @ManyToOne("Payment", { onDelete: "SET NULL", nullable: true })
  @JoinColumn({ name: "payment_id" })
  payment?: any;

  @ManyToOne("ArtistRequest", { onDelete: "SET NULL", nullable: true })
  @JoinColumn({ name: "artist_request_id" })
  artistRequest?: any;

  @ManyToOne("ContactRequest", { onDelete: "SET NULL", nullable: true })
  @JoinColumn({ name: "contact_request_id" })
  contactRequest?: any;

  /** The admin who made a manual adjustment. Null for automatic movements. */
  @ManyToOne("Admin", { onDelete: "SET NULL", nullable: true })
  @JoinColumn({ name: "admin_id" })
  admin?: any;
}
