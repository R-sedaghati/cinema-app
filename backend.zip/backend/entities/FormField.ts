import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, Relation } from "typeorm";
import { Base } from "./base/base.js";
import type { FormStep } from "./FormStep.js";
import { FormFieldType, SyncToUserField } from "../utils/enum.js";

@Entity({ name: "form_fields" })
export class FormField extends Base {
  @PrimaryGeneratedColumn()
  id!: number;

  @ManyToOne("FormStep", "fields", { onDelete: "CASCADE", nullable: false })
  @JoinColumn({ name: "step_id" })
  step!: Relation<FormStep>;

  @Column()
  key!: string;

  @Column()
  label!: string;

  @Column({ type: "enum", enum: FormFieldType })
  type!: FormFieldType;

  @Column({ nullable: true })
  placeholder?: string;

  @Column({ default: false })
  required!: boolean;

  @Column({ default: 0 })
  order!: number;

  @Column({ type: "jsonb", nullable: true })
  options?: { label: string; value: string }[] | null;

  @Column({ type: "jsonb", nullable: true })
  validation?: Record<string, unknown> | null;

  @Column({ type: "enum", enum: SyncToUserField, nullable: true })
  syncToUserField?: SyncToUserField | null;

  @Column({ default: false })
  multiple!: boolean;
}
