import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  BeforeInsert,
  Unique,
} from "typeorm";
import { Base } from "./base/base.js";
import { ArtistRequest } from "./ArtistRequest.js";
import { PaymentStatus } from "../utils/enum.js";
import { randomUUID } from "node:crypto";

/**
 * A viewer's paid request to see one artist's contact details.
 *
 * Distinct from `Payment`, which is the artist's own listing fee: this is the buyer side.
 * A COMPLETED row for (buyer, artistRequest) is the only thing that unlocks contact data.
 */
@Entity({ name: "contact_requests" })
@Unique("UQ_contact_request_payment_id", ["paymentId"])
@Unique("UQ_contact_request_ref_num", ["refNum"])
export class ContactRequest extends Base {
  @PrimaryGeneratedColumn()
  id!: number;

  @ManyToOne("User", { onDelete: "CASCADE", nullable: false })
  @JoinColumn({ name: "buyer_id" })
  buyer!: any;

  @ManyToOne(() => ArtistRequest, { onDelete: "CASCADE", nullable: false })
  @JoinColumn({ name: "artist_request_id" })
  artistRequest!: ArtistRequest;

  /** Name the buyer entered on the request form. */
  @Column({ type: "varchar", name: "requester_name" })
  requesterName!: string;

  /** What the gateway charged. The wallet's share is `walletAmount`. */
  @Column({ type: "float" })
  amount!: number;

  /** Reserved from the user's wallet. Returned if the gateway payment does not settle. */
  @Column({ type: "int", name: "wallet_amount", default: 0 })
  walletAmount!: number;

  @Column({ type: "varchar", name: "payment_gateway", default: "saman" })
  paymentGateway!: string;

  /** Gateway authority/reference, null until the gateway has issued one. */
  @Column({ type: "varchar", name: "payment_id", nullable: true })
  paymentId?: string | null;

  /**
   * SEP's digital receipt for the settled leg. Stored so the receipt can never pay for a
   * second purchase, and so a settlement interrupted mid-verify can be resumed.
   */
  @Column({ type: "varchar", name: "ref_num", nullable: true })
  refNum?: string | null;

  @Column({ type: "enum", enum: PaymentStatus, default: PaymentStatus.PENDING })
  status!: PaymentStatus;

  @Column({ type: "varchar", name: "tracking_code", unique: true })
  trackingCode!: string;

  @BeforeInsert()
  generateTrackingCode() {
    // Random, not time-derived: ArtistRequest's timestamp-slicing scheme collides for
    // rows created in the same millisecond.
    if (!this.trackingCode) {
      this.trackingCode = randomUUID().split("-").join("").slice(0, 12).toUpperCase();
    }
  }
}
