import { Entity, PrimaryGeneratedColumn, Column, OneToMany, BeforeInsert } from "typeorm";
import { Base } from "./base/base.js";
import { MinioService } from "../services/minio.js";
import { AppDataSource } from "../config/database.js";

@Entity({ name: "users" })
export class User extends Base {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column({ unique: true })
  phone_number!: string;

  @Column({ nullable: true, name: "first_name" })
  firstName?: string;

  @Column({ nullable: true, name: "last_name" })
  lastName?: string;

  @Column({ nullable: true, name: "last_login" })
  lastLogin?: Date;

  @OneToMany("ArtistRequest", "user")
  artistRequests!: any[];

  @Column({ nullable: true, name: "avatar_path" })
  avatar?: string;

  @Column({nullable: true, name: "email"})
  email?: string;

  @Column({
    name: 'code',
    unique: true,
    nullable: true,
    default: () => "nextval('user_code_seq')",
  })
  code?: string;

  async getAvatarUrl(): Promise<string | null> {
    if (!this.avatar) {
      return null;
    }
    const url = await MinioService.getPublicUrls([this.avatar])
    return url[0];
  }
}
