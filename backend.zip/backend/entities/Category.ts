import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  OneToMany,
  ManyToMany,
} from "typeorm";
import { Base } from "./base/base.js";
import { ArtistRequest } from "./ArtistRequest.js";
import type { Support } from "./Support.js";
import { MinioService } from "../services/minio.js";

@Entity({ name: "categories" })
export class Category extends Base {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column({ name: "fa_name" })
  faName!: string;

  @Column({ name: "en_name" })
  enName!: string;

  @Column({ name: "description", type: "text", nullable: true })
  description?: string | null;

  @ManyToOne(() => Category, (category) => category.children, {
    nullable: true,
    onDelete: "SET NULL",
  })
  @JoinColumn({ name: "parent_id" })
  parent?: Category | null;

  @OneToMany(() => Category, (category) => category.parent)
  children!: Category[];

  @ManyToMany("ArtistRequest", "categories")
  artistRequests!: ArtistRequest[];

  @OneToMany("Support", "category")
  supports!: Support[];

  @Column(
    {name: "priority", nullable: true}
  )
  priority?: number

  @Column({ name: "image_path", type: "varchar", nullable: true })
  image?: string | null;

  /**
   * Price, in Toman, a viewer pays to unlock one artist's contact details in this
   * category. Null falls back to configs.contactRequestFallbackAmount.
   */
  @Column({ name: "contact_amount", type: "int", nullable: true })
  contactAmount?: number | null;

  async getImageUrl(): Promise<string | null> {
    if (!this.image) {
      return null;
    }
    const url = await MinioService.getPublicUrls([this.image]);
    return url[this.image];
  }
}
