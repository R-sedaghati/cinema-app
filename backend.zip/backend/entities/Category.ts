import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  JoinColumn,
  OneToMany,
  ManyToMany,
} from "typeorm";
import { Base } from "./base/base.js";
import { ArtistRequest } from "./ArtistRequest.js";
import type { Support } from "./Support.js";
import { MinioService } from "../services/minio.js";

@Entity({ name: "categories" })
export class Category extends Base {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column({ name: "fa_name" })
  faName!: string;

  @Column({ name: "en_name" })
  enName!: string;

  @Column({ name: "description", type: "text", nullable: true })
  description?: string | null;

  @ManyToOne(() => Category, (category) => category.children, {
    nullable: true,
    onDelete: "SET NULL",
  })
  @JoinColumn({ name: "parent_id" })
  parent?: Category | null;

  @OneToMany(() => Category, (category) => category.parent)
  children!: Category[];

  @ManyToMany("ArtistRequest", "categories")
  artistRequests!: ArtistRequest[];

  @OneToMany("Support", "category")
  supports!: Support[];

  @Column(
    {name: "priority", nullable: true}
  )
  priority?: number

  @Column({ name: "image_path", type: "varchar", nullable: true })
  image?: string | null;

  /**
   * Price, in Toman, a viewer pays to unlock one artist's contact details in this
   * category. Null falls back to configs.contactRequestFallbackAmount; zero means free.
   */
  @Column({ name: "contact_amount", type: "int", nullable: true })
  contactAmount?: number | null;

  /**
   * One-off fee, in Toman, an artist pays to register under this category. Null
   * falls back to configs.registrationAmount. Zero means the category is free and
   * the payment gateway is skipped entirely.
   */
  @Column({ name: "registration_amount", type: "int", nullable: true })
  registrationAmount?: number | null;

  /** Copy shown on the post-payment result pages of this category's registration form. */
  @Column({ name: "success_title", type: "varchar", nullable: true })
  successTitle?: string | null;

  @Column({ name: "success_description", type: "text", nullable: true })
  successDescription?: string | null;

  @Column({ name: "fail_title", type: "varchar", nullable: true })
  failTitle?: string | null;

  @Column({ name: "fail_description", type: "text", nullable: true })
  failDescription?: string | null;

  /**
   * Overrides for the fixed copy of this category's registration form (button
   * labels, step counter, payment block, ...), keyed by the keys in the
   * frontend's FORM_COPY registry. Missing keys fall back to the defaults.
   */
  @Column({ name: "form_copy", type: "jsonb", nullable: true })
  formCopy?: Record<string, string> | null;

  async getImageUrl(): Promise<string | null> {
    if (!this.image) {
      return null;
    }
    const url = await MinioService.getPublicUrls([this.image]);
    return url[this.image];
  }
}
