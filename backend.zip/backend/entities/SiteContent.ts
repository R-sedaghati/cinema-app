import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
} from "typeorm";
import { Base } from "./base/base.js";

export interface ISiteContentBenefitItem {
  title: string;
  desc: string;
}

export interface ISiteContentSupportItem {
  title: string;
  detail: string;
  footerText: string;
  buttonValue: string;
}

export interface ISiteContentBenefits {
  items: ISiteContentBenefitItem[];
  fontSize?: number | null;
}

export interface ISiteContentSupport {
  title: string;
  description: string;
  items: ISiteContentSupportItem[];
  fontSize?: number | null;
}

export interface ISiteContentFooter {
  phone: string;
  instagramUrl: string;
  copyright: string;
}

/** One field of the admin-editable support contact form (see the frontend
 *  `lib/constants/contactForm.ts` for the built-in keys and the defaults). */
export interface ISiteContentContactField {
  key: string;
  label: string;
  type: string;
  placeholder?: string | null;
  helpText?: string | null;
  required: boolean;
  options?: { label: string; value: string }[] | null;
  validation?: Record<string, unknown> | null;
}

export interface ISiteContentContactForm {
  title: string;
  submitLabel: string;
  fields: ISiteContentContactField[];
}

export interface ISiteContentTerms {
  title: string;
  content: string;
  fontSize?: number | null;
}

const defaultBenefits: ISiteContentBenefits = {
  items: [
    { title: "", desc: "" },
    { title: "", desc: "" },
    { title: "", desc: "" },
  ],
};

const defaultSupport: ISiteContentSupport = {
  title: "",
  description: "",
  items: [
    { title: "", detail: "", footerText: "", buttonValue: "" },
    { title: "", detail: "", footerText: "", buttonValue: "" },
    { title: "", detail: "", footerText: "", buttonValue: "" },
  ],
};

const defaultTerms: ISiteContentTerms = {
  title: "",
  content: "",
};

// Empty on purpose: the frontend falls back to its own defaults for every
// missing key, so "not set here" means "use the shipped copy".
const defaultFooter: ISiteContentFooter = {
  phone: "",
  instagramUrl: "",
  copyright: "",
};

const defaultContactForm: ISiteContentContactForm = {
  title: "",
  submitLabel: "",
  fields: [],
};

@Entity({ name: "site_content" })
export class SiteContent extends Base {
    @PrimaryGeneratedColumn()
    id!: number;

    @Column({
        type: "jsonb",
        name: "benefits",
        default: () => `'${JSON.stringify(defaultBenefits)}'`,
    })
    benefits!: ISiteContentBenefits;

    @Column({
        type: "jsonb",
        name: "support",
        default: () => `'${JSON.stringify(defaultSupport)}'`,
    })
    support!: ISiteContentSupport;

    @Column({
        type: "jsonb",
        name: "terms",
        default: () => `'${JSON.stringify(defaultTerms)}'`,
    })
    terms!: ISiteContentTerms;

    @Column({
        type: "jsonb",
        name: "footer",
        default: () => `'${JSON.stringify(defaultFooter)}'`,
    })
    footer!: ISiteContentFooter;

    /** Overrides for the public-site copy, keyed by the frontend LANDING_COPY registry. */
    @Column({
        type: "jsonb",
        name: "landing",
        default: () => `'{}'`,
    })
    landing!: Record<string, string>;

    @Column({
        type: "jsonb",
        name: "contact_form",
        default: () => `'${JSON.stringify(defaultContactForm)}'`,
    })
    contactForm!: ISiteContentContactForm;
}
