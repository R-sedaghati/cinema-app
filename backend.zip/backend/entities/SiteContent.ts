import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
} from "typeorm";
import { Base } from "./base/base.js";

export interface ISiteContentBenefitItem {
  title: string;
  desc: string;
}

export interface ISiteContentSupportItem {
  title: string;
  detail: string;
  footerText: string;
  buttonValue: string;
}

export interface ISiteContentBenefits {
  items: ISiteContentBenefitItem[];
}

export interface ISiteContentSupport {
  title: string;
  description: string;
  items: ISiteContentSupportItem[];
}

export interface ISiteContentTerms {
  title: string;
  content: string;
}

const defaultBenefits: ISiteContentBenefits = {
  items: [
    { title: "", desc: "" },
    { title: "", desc: "" },
    { title: "", desc: "" },
  ],
};

const defaultSupport: ISiteContentSupport = {
  title: "",
  description: "",
  items: [
    { title: "", detail: "", footerText: "", buttonValue: "" },
    { title: "", detail: "", footerText: "", buttonValue: "" },
    { title: "", detail: "", footerText: "", buttonValue: "" },
  ],
};

const defaultTerms: ISiteContentTerms = {
  title: "",
  content: "",
};

@Entity({ name: "site_content" })
export class SiteContent extends Base {
    @PrimaryGeneratedColumn()
    id!: number;

    @Column({
        type: "jsonb",
        name: "benefits",
        default: () => `'${JSON.stringify(defaultBenefits)}'`,
    })
    benefits!: ISiteContentBenefits;

    @Column({
        type: "jsonb",
        name: "support",
        default: () => `'${JSON.stringify(defaultSupport)}'`,
    })
    support!: ISiteContentSupport;

    @Column({
        type: "jsonb",
        name: "terms",
        default: () => `'${JSON.stringify(defaultTerms)}'`,
    })
    terms!: ISiteContentTerms;
}
