import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";
import { Base } from "./base/base.js";

/**
 * Gateway credentials, editable from the admin panel so switching merchants does not
 * need a redeploy. Single row (id 1), created on first read.
 *
 * `merchantId` is a secret: it is never included in any public response, and the admin
 * endpoint returns it masked. An empty value means "fall back to the env config".
 */
@Entity({ name: "payment_settings" })
export class PaymentSetting extends Base {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column({ type: "varchar", name: "gateway", default: "zarinpal" })
  gateway!: string;

  @Column({ type: "varchar", name: "merchant_id", nullable: true })
  merchantId?: string | null;

  /** Sandbox mode. Defaults off so a fresh row never silently takes real money on test. */
  @Column({ type: "boolean", name: "sandbox", default: false })
  sandbox!: boolean;
}
