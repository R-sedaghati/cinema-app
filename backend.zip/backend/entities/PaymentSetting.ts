import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";
import { Base } from "./base/base.js";

/**
 * Gateway credentials, editable from the admin panel so switching merchants does not
 * need a redeploy. Single row (id 1), created on first read.
 *
 * `terminalId` is a secret: it is never included in any public response, and the admin
 * endpoint returns it masked. An empty value means "fall back to the env config".
 */
@Entity({ name: "payment_settings" })
export class PaymentSetting extends Base {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column({ type: "varchar", name: "gateway", default: "saman" })
  gateway!: string;

  /** SEP terminal ID. Their test environment is a separate terminal, not a separate host. */
  @Column({ type: "varchar", name: "terminal_id", nullable: true })
  terminalId?: string | null;

  /**
   * SEP endpoints. Null means "use the shipped defaults" — they only need overriding to
   * point at a UAT host, so an admin who never touches them keeps working after an
   * upgrade that moves a default.
   */
  @Column({ type: "varchar", name: "token_url", nullable: true })
  tokenUrl?: string | null;

  @Column({ type: "varchar", name: "verify_url", nullable: true })
  verifyUrl?: string | null;

  @Column({ type: "varchar", name: "payment_url", nullable: true })
  paymentUrl?: string | null;
}
