import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, OneToMany, Relation } from "typeorm";
import { Base } from "./base/base.js";
import { Category } from "./Category.js";
import { FormField } from "./FormField.js";

@Entity({ name: "form_steps" })
export class FormStep extends Base {
  @PrimaryGeneratedColumn()
  id!: number;

  @ManyToOne(() => Category, { onDelete: "CASCADE", nullable: false })
  @JoinColumn({ name: "category_id" })
  category!: Category;

  @Column()
  title!: string;

  @Column({ default: 0 })
  order!: number;

  @Column({ nullable: true })
  icon?: string;

  @OneToMany(() => FormField, (field) => field.step)
  fields!: Relation<FormField>[];
}
