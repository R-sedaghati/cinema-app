import { Column, CreateDateColumn, Entity, JoinColumn, ManyToOne, PrimaryGeneratedColumn, Unique } from "typeorm";
import { PaymentStatus } from "../utils/enum.js";

@Entity({ name: "payments" })
@Unique("UQ_payment_ref_num", ["refNum"])
export class Payment {
    @PrimaryGeneratedColumn()
    id!: number;

    /** What the gateway charged. The wallet's share is `walletAmount`. */
    @Column({ type: "float" })
    amount!: number;

    /** Reserved from the user's wallet. Returned if the gateway payment does not settle. */
    @Column({ type: "int", name: "wallet_amount", default: 0 })
    walletAmount!: number;

    @Column({ type: "varchar" })
    paymentGateway!: string;

    @Column({ type: "varchar" })
    paymentId!: string;

    /**
     * SEP's digital receipt for the settled leg. Stored so the receipt can never pay for
     * a second purchase, and so a settlement interrupted mid-verify can be resumed.
     */
    @Column({ type: "varchar", name: "ref_num", nullable: true })
    refNum?: string | null;

    @ManyToOne("ArtistRequest", "payments", {
      nullable: false,
      onDelete: "CASCADE"
    })
    @JoinColumn({ name: "artist_request_id" })
    artistRequest!: any;

    @Column({
        type: "enum",
        enum: PaymentStatus,
        default: PaymentStatus.PENDING
    })
    status!: PaymentStatus;

    /** How long the gateway leg has been pending — the sweeper works off this. */
    @CreateDateColumn({ name: "created_at" })
    createdAt!: Date;
}