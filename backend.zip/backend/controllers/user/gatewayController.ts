/**
 * The purchase route that will redirect the user to the payment gateway
 */

import { User } from "../../entities/User.js";
import { CustomRequest } from "../../types/controllers.types.js";
import { configs } from "../../config/configs.js";
import { apiResponse } from "../../utils/customResponse.js";
import { Response } from "express";
import { artistRequestRepository, paymentRepository } from "../../models/index.js";
import { ArtistRequestStatus, PaymentStatus } from "../../utils/enum.js";
import { isAmountSet } from "../../utils/amount.js";
import { zarinpalDriver } from "../../services/gateway.js";
import { credit, spend } from "../../services/wallet.js";
import { WalletTransactionType } from "../../utils/enum.js";
import { resolveTopLevelCategory } from "../../utils/formSchema.js";

/** The user lands here after the gateway; the copy shown is per-category and set in the form builder. */
const resultUrl = (status: "success" | "failed", categoryId?: number) =>
    `${configs.appUrl}/artist-registration/result?status=${status}` +
    (categoryId ? `&categoryId=${categoryId}` : "");

/**
 * Registration fee is per category, mirroring the contact price: a child category
 * inherits its top-level parent's fee, an unset fee falls back to config, and 0 means
 * the category is free.
 */
const registrationAmountForRequest = async (artistRequest: { categories?: { id: number; registrationAmount?: number | null }[] }) => {
    for (const category of artistRequest.categories ?? []) {
        if (isAmountSet(category.registrationAmount)) return category.registrationAmount;

        const topLevel = await resolveTopLevelCategory(category.id);
        if (isAmountSet(topLevel?.registrationAmount)) return topLevel.registrationAmount;
    }

    return configs.registrationAmount;
};

/** Puts a reservation back when the gateway leg does not settle. */
const returnReservedWallet = async (
    userId: number,
    walletAmount: number,
    artistRequestId: number,
) => {
    if (walletAmount <= 0) return;

    await credit({
        userId,
        amount: walletAmount,
        type: WalletTransactionType.REFUND_FAILED_PAYMENT,
        description: "بازگشت مبلغ رزروشده کیف پول به دلیل ناموفق بودن پرداخت",
        artistRequestId,
    });
};

export const purchaseController = async (req: CustomRequest<{ user: User }>, res: Response) => {
    const { requestId } = req.query

    const artistRequest = await artistRequestRepository().findOne({
        where: { id: Number(requestId) },
        relations: { user: true, categories: true },
    });

    if (!artistRequest) {
        return apiResponse(res, {
            success: false,
            message: 'درخواست یافت نشد.',
            statusCode: 404,
        });
    }

    // Only the owner of the request may pay for it.
    if (artistRequest.user.id !== req.payload?.user.id) {
        return apiResponse(res, {
            success: false,
            message: 'دسترسی غیرمجاز.',
            statusCode: 403,
        });
    }

    // The fee is resolved server-side from the category. It used to be read from
    // `req.query.amount`, which let a user pick what they paid by editing the URL.
    const amount = await registrationAmountForRequest(artistRequest);

    // Wallet first. This reserves the balance now rather than at the callback: the
    // reservation is what stops a second purchase spending the same money while this
    // one is still at the gateway. A payment that never settles returns it (below).
    const walletApplied = await spend({
        userId: artistRequest.user.id,
        requested: amount,
        type: WalletTransactionType.SPEND_REGISTRATION,
        description: "پرداخت هزینه ثبت‌نام از کیف پول",
        artistRequestId: Number(requestId),
    });

    const dueAtGateway = amount - walletApplied;

    // Nothing left to charge — free category, or the wallet covered the whole fee.
    if (dueAtGateway === 0) {
        await paymentRepository().save({
            paymentId: `free-${requestId}`,
            amount: 0,
            walletAmount: walletApplied,
            paymentGateway: walletApplied > 0 ? "wallet" : "free",
            artistRequest: { id: Number(requestId) },
            status: PaymentStatus.COMPLETED,
        });

        artistRequest.status = ArtistRequestStatus.PENDING;
        await artistRequestRepository().save(artistRequest);

        return res.redirect(resultUrl("success", artistRequest.categories?.[0]?.id));
    }


    try{
        const driver = await zarinpalDriver();

        const paymentInfo = await driver.request({
            amount: dueAtGateway,
            callbackUrl: configs.apiUrl + '/api/user/purchase/callback/?requestId=' + requestId,
        });

        await paymentRepository().save({
            paymentId: String(paymentInfo.referenceId),
            amount: dueAtGateway,
            walletAmount: walletApplied,
            paymentGateway: "zarinpal",
            artistRequest: { id: Number(requestId) }
        });

        res.send(`<html>
            <body>
                <h1> We're redirecting you to the payment gateway... </h1>
                <script>${paymentInfo.getScript()}</script>
            </body>
            </html>`
        );        
    } catch (e) {
        await returnReservedWallet(artistRequest.user.id, walletApplied, Number(requestId));

        return apiResponse(res, {
            success: false,
            message: 'خطا در اتصال به درگاه پرداخت. لطفاً دوباره تلاش کنید.',
            statusCode: 500,
        });
    }

}


const categoryIdOfRequest = async (requestId: unknown) => {
    const request = await artistRequestRepository().findOne({
        where: { id: Number(requestId) },
        relations: { categories: true },
    });
    return request?.categories?.[0]?.id;
};

/**
 * The callback URL that was given to `request`
 */
export const callbackController = async (req: CustomRequest<{ user: User }>, res: Response) => {
    const requestId = req.query.requestId;

    /** The gateway leg did not settle, so any wallet the user had reserved goes back. */
    const failed = async () => {
        const [payment] = await paymentRepository().find({
            where: { artistRequest: { id: Number(requestId) } },
            relations: { artistRequest: { user: true } },
            order: { id: "DESC" },
            take: 1,
        });

        if (payment && payment.status === PaymentStatus.PENDING) {
            payment.status = PaymentStatus.FAILED;
            await paymentRepository().save(payment);

            await returnReservedWallet(
                payment.artistRequest?.user?.id,
                payment.walletAmount,
                Number(requestId),
            );
        }

        return res.redirect(resultUrl("failed", await categoryIdOfRequest(requestId)));
    };

    if (req.query.Status !== "OK") {
        return failed();
    }

    try {
        const driver = await zarinpalDriver();

        const paymentObject = await paymentRepository().find({
            where: { artistRequest: { id: Number(requestId) } },
            relations: { artistRequest: { categories: true } },
            order: { id: "DESC" },
            take: 1
        })
        const payment = paymentObject[0]

        // Replayed callback for a settled payment: don't verify (or credit) twice.
        if (payment?.status === PaymentStatus.COMPLETED) {
            return res.redirect(resultUrl("success", payment.artistRequest?.categories?.[0]?.id));
        }

        const receipt = await driver.verify(
        {
            amount: payment.amount,
        },
        { ...req.query, ...req.body },
        );

        payment.status = PaymentStatus.COMPLETED;
        await paymentRepository().save(payment);
        payment.artistRequest.status = ArtistRequestStatus.PENDING;
        await artistRequestRepository().save(payment.artistRequest);


        void receipt; // transactionId is null on sandbox; the result page doesn't show it

        return res.redirect(resultUrl("success", payment.artistRequest?.categories?.[0]?.id));
    } catch (e) {
        return failed();
    }
}