/**
 * The purchase route that will redirect the user to the payment gateway
 */

import { User } from "../../entities/User.js";
import { CustomRequest } from "../../types/controllers.types.js";
import { configs } from "../../config/configs.js";
import { apiResponse } from "../../utils/customResponse.js";
import { Response } from "express";
import { artistRequestRepository, paymentRepository } from "../../models/index.js";
import { ArtistRequestStatus, PaymentStatus } from "../../utils/enum.js";
import { isAmountSet } from "../../utils/amount.js";
import {
    requestSepToken,
    startPayUrl,
    isSepCallbackSuccessful,
    SepTransportError,
} from "../../services/gateway.js";
import { spend } from "../../services/wallet.js";
import { WalletTransactionType } from "../../utils/enum.js";
import { resolveTopLevelCategory } from "../../utils/formSchema.js";
import { hasPaidRegistration } from "../../services/registration.js";
import {
    failRegistrationPayment,
    returnReservedWallet,
    settleRegistrationPayment,
} from "../../services/settlement.js";
import { notifyAdmins } from "../../services/adminNotify.js";
import { NotificationEvent } from "../../utils/enum.js";

/** The user lands here after the gateway; the copy shown is per-category and set in the form builder. */
const resultUrl = (status: "success" | "failed", categoryId?: number) =>
    `${configs.appUrl}/artist-registration/result?status=${status}` +
    (categoryId ? `&categoryId=${categoryId}` : "");

/**
 * Registration fee is per category, mirroring the contact price: a child category
 * inherits its top-level parent's fee, an unset fee falls back to config, and 0 means
 * the category is free.
 */
const registrationAmountForRequest = async (artistRequest: { categories?: { id: number; registrationAmount?: number | null }[] }) => {
    for (const category of artistRequest.categories ?? []) {
        if (isAmountSet(category.registrationAmount)) return category.registrationAmount;

        const topLevel = await resolveTopLevelCategory(category.id);
        if (isAmountSet(topLevel?.registrationAmount)) return topLevel.registrationAmount;
    }

    return configs.registrationAmount;
};

export const purchaseController = async (req: CustomRequest<{ user: User }>, res: Response) => {
    const { requestId } = req.query

    const artistRequest = await artistRequestRepository().findOne({
        where: { id: Number(requestId) },
        relations: { user: true, categories: true },
    });

    if (!artistRequest) {
        return apiResponse(res, {
            success: false,
            message: 'درخواست یافت نشد.',
            statusCode: 404,
        });
    }

    // Only the owner of the request may pay for it.
    if (artistRequest.user.id !== req.payload?.user.id) {
        return apiResponse(res, {
            success: false,
            message: 'دسترسی غیرمجاز.',
            statusCode: 403,
        });
    }

    // The fee is resolved server-side from the category. It used to be read from
    // `req.query.amount`, which let a user pick what they paid by editing the URL.
    // The registration fee is charged once per user: whoever already paid one
    // registration registers in every other category for free.
    const amount = (await hasPaidRegistration(artistRequest.user.id))
        ? 0
        : await registrationAmountForRequest(artistRequest);

    // Wallet first. This reserves the balance now rather than at the callback: the
    // reservation is what stops a second purchase spending the same money while this
    // one is still at the gateway. A payment that never settles returns it (below).
    const walletApplied = await spend({
        userId: artistRequest.user.id,
        requested: amount,
        type: WalletTransactionType.SPEND_REGISTRATION,
        description: "پرداخت هزینه ثبت‌نام از کیف پول",
        artistRequestId: Number(requestId),
    });

    const dueAtGateway = amount - walletApplied;

    // Nothing left to charge — free category, or the wallet covered the whole fee.
    if (dueAtGateway === 0) {
        await paymentRepository().save({
            paymentId: `free-${requestId}`,
            amount: 0,
            walletAmount: walletApplied,
            paymentGateway: walletApplied > 0 ? "wallet" : "free",
            artistRequest: { id: Number(requestId) },
            status: PaymentStatus.COMPLETED,
        });

        artistRequest.status = ArtistRequestStatus.PENDING;
        await artistRequestRepository().save(artistRequest);

        notifyAdmins(
            NotificationEvent.REGISTRATION,
            `ثبت‌نام هنرمند (#${requestId}) پرداخت شد و در انتظار بررسی است.`
        );
        notifyAdmins(
            NotificationEvent.TRANSACTION,
            `پرداخت ثبت‌نام (#${requestId}) به مبلغ ${walletApplied.toLocaleString("fa-IR")} تومان تکمیل شد.`
        );

        // Settled without a gateway stop — a null redirectUrl tells the client to go
        // straight to the result page.
        return apiResponse(res, { data: { redirectUrl: null } });
    }


    try{
        const token = await requestSepToken({
            amount: dueAtGateway,
            callbackUrl: configs.apiUrl + '/api/user/purchase/callback/?requestId=' + requestId,
            resNum: Number(requestId),
            cellNumber: artistRequest.user.phone_number,
        });

        await paymentRepository().save({
            paymentId: token,
            amount: dueAtGateway,
            walletAmount: walletApplied,
            paymentGateway: "saman",
            artistRequest: { id: Number(requestId) }
        });

        // The client asks for this over XHR (the route needs an Authorization header a
        // bare navigation cannot carry), so hand back the gateway URL rather than an
        // HTML auto-submit page. Same shape as the contact-detail purchase.
        return apiResponse(res, { data: { redirectUrl: await startPayUrl(token) } });
    } catch (e) {
        await returnReservedWallet({
            userId: artistRequest.user.id,
            amount: walletApplied,
            artistRequestId: Number(requestId),
        });

        return apiResponse(res, {
            success: false,
            message: 'خطا در اتصال به درگاه پرداخت. لطفاً دوباره تلاش کنید.',
            statusCode: 500,
        });
    }

}


const categoryIdOfRequest = async (requestId: unknown) => {
    const request = await artistRequestRepository().findOne({
        where: { id: Number(requestId) },
        relations: { categories: true },
    });
    return request?.categories?.[0]?.id;
};

/**
 * The callback URL that was given to `request`.
 *
 * Anyone can reach this — SEP sends the buyer's browser here, so it carries no auth
 * header — which is why nothing here trusts its input beyond the RefNum, and why the
 * RefNum is claimed and then re-verified with SEP before a purchase is marked paid.
 */
export const callbackController = async (req: CustomRequest<{ user: User }>, res: Response) => {
    const requestId = req.query.requestId;

    // SEP posts its result as a urlencoded form body, not a query string.
    const callbackParams = { ...req.query, ...req.body };

    // Pick the attempt this callback is actually about. SEP echoes the token it issued,
    // which is the only thing that distinguishes two attempts on the same request —
    // "the newest row" settles the wrong one when a buyer retries.
    const token = callbackParams.Token ? String(callbackParams.Token) : null;

    const [payment] = await paymentRepository().find({
        where: {
            artistRequest: { id: Number(requestId) },
            ...(token ? { paymentId: token } : {}),
        },
        relations: { artistRequest: { user: true, categories: true } },
        order: { id: "DESC" },
        take: 1,
    });

    const categoryId = payment?.artistRequest?.categories?.[0]?.id;

    const failed = async () => {
        if (payment) await failRegistrationPayment(payment);
        return res.redirect(resultUrl("failed", categoryId));
    };

    if (!payment) {
        return res.redirect(resultUrl("failed", await categoryIdOfRequest(requestId)));
    }

    // Replayed callback for a settled payment: don't verify (or credit) twice. Checked
    // before the failure branch, so a forged "canceled" cannot un-pay a paid purchase.
    if (payment.status === PaymentStatus.COMPLETED) {
        return res.redirect(resultUrl("success", categoryId));
    }

    if (!isSepCallbackSuccessful(callbackParams)) {
        return failed();
    }

    try {
        await settleRegistrationPayment(payment, String(callbackParams.RefNum));

        return res.redirect(resultUrl("success", categoryId));
    } catch (error) {
        // SEP never answered: the transaction is still live and the sweeper will retry
        // inside the 30-minute window. Leaving the row PENDING is what makes that
        // possible — failing it here would strand a payment SEP is about to confirm.
        if (error instanceof SepTransportError) {
            return res.redirect(resultUrl("failed", categoryId));
        }

        return failed();
    }
}
