import { Response } from "express";
import { MinioService } from "../../services/minio.js";
import { CustomRequest } from "../../types/controllers.types.js";
import { userRepository } from "../../models/index.js";
import { User } from "../../entities/User.js";
import { randomUUID } from "crypto";

const uploadOrFail = async (
  res: Response,
  label: string,
  path: string,
  buffer: Buffer,
  mimetype: string,
): Promise<boolean> => {
  try {
    await MinioService.uploadByPath(path, buffer, mimetype);
    return true;
  } catch (error) {
    console.error(`[upload] ${label} failed:`, error);
    res.status(502).json({ message: "Storage upload failed" });
    return false;
  }
};

export class UserMinioController {
  static async uploadAvatar(req: CustomRequest<{user : User}>, res: Response) {
    const userId = req.payload?.user.id;
    const file = req.file;

    if (!file) {
      return res.status(400).json({ message: "No file uploaded" });
    }

    const ext = file.originalname.split(".").pop();
    const path = `users/${userId}/avatar.${ext}`;

    if (!(await uploadOrFail(res, "avatar", path, file.buffer, file.mimetype)))
      return;

    await userRepository().update(
      { id: userId },
      { avatar: path },
    );

    return res.json({
      path,
    });
  };
  static async uploadVideo(
    req: CustomRequest<{ user: User }>,
    res: Response,
  ) {
    const userId = req.payload?.user.id;
    const file = req.file;

    if (!file) {
      return res.status(400).json({
        message: "No video uploaded",
      });
    }

    if (!file.mimetype.startsWith("video/")) {
      return res.status(400).json({
        message: "Invalid file type",
      });
    }

    const ext = file.originalname.split(".").pop();
    const filename = `${randomUUID()}.${ext}`;

    const path = `users/${userId}/videos/${filename}`;

    if (!(await uploadOrFail(res, "video", path, file.buffer, file.mimetype)))
      return;

    return res.status(201).json({
      path,
      filename,
    });
  };
  static async uploadImage(req: CustomRequest<{user : User}>, res: Response) {
    const userId = req.payload?.user.id;
    const file = req.file;

    if (!file) {
      return res.status(400).json({ message: "No file uploaded" });
    }

    const ext = file.originalname.split(".").pop();
    const filename = `${randomUUID()}.${ext}`
    const path = `users/${userId}/images/${filename}`;

    if (!(await uploadOrFail(res, "image", path, file.buffer, file.mimetype)))
      return;

    return res.json({
      path,
      filename
    });
  };
}
