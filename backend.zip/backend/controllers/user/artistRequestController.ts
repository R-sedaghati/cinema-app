import { Response, Request } from "express";
import { In } from "typeorm";
import { CustomRequest } from "../../types/controllers.types.js";
import { User } from "../../entities/User.js";
import {
  artistRequestRepository,
  artistPortfolioRepository,
  categoryRepository,
} from "../../models/index.js";
import { apiResponse } from "../../utils/customResponse.js";
import { ArtistRequest } from "../../entities/ArtistRequest.js";
import { artistRequestSerializer } from "../../serializers/artistRequestSerializer.js";
import { MinioService } from "../../services/minio.js";
import { SearchAndFilterService } from "../../services/searchAndFilter.js";
import { paginate } from "../../utils/pagination.js";
import { ArtistPortfolio } from "../../entities/ArtistPortfolio.js";
import { ArtistRequestStatus, FormFieldType } from "../../utils/enum.js";
import { getAllFieldsForCategory, resolveTopLevelCategory } from "../../utils/formSchema.js";
import { validateAnswers } from "../../utils/fieldValidation.js";
import { buildAnswerFilterMap } from "../../utils/answerFilters.js";
import { PUBLIC_EXCLUDED_USER_FIELDS, publicSearchableExpressions, publicExcludedAnswerKeys } from "../../utils/privacy.js";
import { sendMelliSms } from "../../services/melliPayamak.js";
import { configs } from "../../config/configs.js";

/**
 * Helper utility: sets entity field only if user's current field is null
 * and incoming value is not undefined
 */
function setIfNull<T, K extends keyof T>(entity: T, key: K, value: T[K] | undefined) {
  if (entity[key] === null && value !== undefined) {
    entity[key] = value;
  }
}

export const createArtistRequest = async (
  req: CustomRequest<{ user: User }>,
  res: Response
) => {
  const userId = req.payload?.user.id;

  try {
    const { categoryIds, answers, portfolios } = req.body;
    if (!categoryIds) {
      return apiResponse(res, {
        statusCode: 400,
        success: false,
        message: "Category IDs are required",
      })
    }

    const categories =
      Array.isArray(categoryIds) && categoryIds.length > 0
        ? categoryIds.map((id: number) => ({ id }))
        : [];

    const answerValues: Record<string, unknown> = answers ?? {};
    const topLevel = categories.length
      ? await resolveTopLevelCategory(categories[0].id)
      : null;
    const fields = topLevel ? await getAllFieldsForCategory(topLevel.id) : [];

    const missingRequired = fields.filter((f) => {
      if (!f.required) return false;
      const value = answerValues[f.key];
      // a required BOOLEAN is a consent box: unchecked counts as unanswered
      if (f.type === FormFieldType.BOOLEAN) return value !== true;
      return value === undefined || value === "" || value === null;
    });

    if (missingRequired.length) {
      return apiResponse(res, {
        statusCode: 400,
        success: false,
        message: `Missing required fields: ${missingRequired.map((f) => f.key).join(", ")}`,
      });
    }

    const validationErrors = validateAnswers(fields, answerValues);

    if (validationErrors.length) {
      return apiResponse(res, {
        statusCode: 400,
        success: false,
        message: validationErrors[0],
        errors: validationErrors,
      });
    }

    const queryRunner =
      artistRequestRepository().manager.connection.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const user = await queryRunner.manager.findOne(User, {
        where: { id: userId },
        lock: { mode: "pessimistic_write" },
      });

      if (!user) {
        throw new Error("User not found");
      }

      for (const field of fields) {
        if (!field.syncToUserField) continue;
        setIfNull(
          user,
          field.syncToUserField as keyof User,
          answerValues[field.key] as User[keyof User],
        );
      }

      await queryRunner.manager.save(User, user);

      const artistRequest = await queryRunner.manager.save(ArtistRequest, {
        user: { id: userId },
        categories,
        answers: answerValues,
      });

      const resPortfolios = [];

      if (Array.isArray(portfolios)) {
        for (const file of portfolios) {
          const portfolio = await queryRunner.manager.save(
            artistPortfolioRepository().create({
              filePath: file.path,
              type: file.type,
              fieldKey: file.fieldKey ?? null,
              artistRequest: { id: artistRequest.id },
            })
          );

          resPortfolios.push({
            id: portfolio.id,
            filePath: portfolio.filePath,
            type: portfolio.type,
            fieldKey: portfolio.fieldKey ?? null,
          });
        }
      }

      await queryRunner.commitTransaction();

      // ponytail: fire-and-forget — a failed SMS must not fail an already-saved form.
      // Plain text via the base sender; switch to sendMelliPatternSMS if the panel
      // stops accepting free text.
      sendMelliSms(
        user.phone_number,
        configs.melliPayamakSender,
        `${user.firstName ?? "کاربر"} عزیز، فرم درخواست شما در آرشیو هنر ثبت شد و در حال بررسی است.`
      ).catch((e) => console.error("artist request SMS failed:", e));

      return apiResponse(res, {
        statusCode: 201,
        success: true,
        message: "Artist request created successfully",
        data: {
          artistRequestId: artistRequest.id,
          status: artistRequest.status,
          portfolios: resPortfolios,
        },
      });
    } catch (err) {
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      await queryRunner.release();
    }
  } catch (error) {
    console.error("Error creating artist request:", error);
    return apiResponse(res, {
      statusCode: 500,
      success: false,
      message: "Failed to create artist request",
      errors: error instanceof Error ? error.message : "Unknown error",
    });
  }
};


export const getArtistRequests = async (
  req: CustomRequest<{ user: User }>,
  res: Response,
) => {
  const userId = req.payload!.user.id;

  const { data: artistRequests, meta } = await paginate<ArtistRequest>({
    repository: artistRequestRepository(),
    req,
    options: {
      where: { user: { id: userId } },
      relations: ["user", "categories", "portfolios"],
    },
  });

  const avatarPaths = artistRequests
    .map(ar => ar.user.avatar)
    .filter((path): path is string => Boolean(path));

  const portfoliosPaths = artistRequests.flatMap(ar =>
    ar.portfolios
      ?.map(portfolio => portfolio.filePath)
      .filter(Boolean) ?? []
  );

  const avatarMap = await MinioService.getPublicUrls(avatarPaths);
  const portfoliosMap = await MinioService.getPublicUrls(portfoliosPaths);

  const serializedData = await artistRequestSerializer(artistRequests, avatarMap, portfoliosMap);

  return apiResponse(res, {
    statusCode: 200,
    success: true,
    data: serializedData,
    pagination: {...meta},
  });
};


/**
 * Selecting a top-level category must also match artists tagged only with its children,
 * since children are the sub-specialities of the same field.
 */
const expandCategoryIds = async (raw: unknown): Promise<number[]> => {
  const requested = (Array.isArray(raw) ? raw : String(raw).split(","))
    .map((value) => Number(value))
    .filter((value) => Number.isInteger(value) && value > 0);

  if (requested.length === 0) return [];

  const children = await categoryRepository().find({
    where: { parent: { id: In(requested) } },
    select: { id: true },
  });

  return [...new Set([...requested, ...children.map((child) => child.id)])];
};

export const getAllArtistsRequests = async (
  req: Request,
  res: Response,
) => {
  const categoryIds = req.query['category__in']
    ? await expandCategoryIds(req.query['category__in'])
    : [];

  const qb =
    artistRequestRepository()
      .createQueryBuilder('artists')
      .leftJoinAndSelect('artists.categories', 'categories')
      .distinct(true)
      .leftJoinAndSelect('artists.user', 'user')
      .leftJoinAndSelect('artists.portfolios', 'portfolios')
      .where("status=:status", {status: ArtistRequestStatus.APPROVED});

  // Answer filters are only meaningful within one field, and the form schema that defines
  // them is per-category — so they are accepted only alongside a category selection.
  let answerFilterable: Record<string, string> = {};

  if (categoryIds.length > 0) {
    qb.andWhere(
      'artists.id IN ' +
        qb
          .subQuery()
          .select('tagged.id')
          .from(ArtistRequest, 'tagged')
          .innerJoin('tagged.categories', 'tagged_category')
          .where('tagged_category.id IN (:...categoryIds)')
          .getQuery(),
      { categoryIds },
    );

    const topLevel = await resolveTopLevelCategory(categoryIds[0]);

    if (topLevel) {
      answerFilterable = buildAnswerFilterMap(
        await getAllFieldsForCategory(topLevel.id),
      );
    }
  }

  const queryBuilder =
    new SearchAndFilterService<ArtistRequest>(
      qb,
      {
        filterable: {
          category: 'categories.id',
          ...answerFilterable,
        },

        searchable: await publicSearchableExpressions(),
        sortable: {
          category: 'categories.faName',
          createdAt: 'artists.createdAt',
        }
      }
    );

  // `category__in` is handled above (it needs child expansion), so keep it out of the
  // generic filter pass — otherwise the unexpanded ids would be ANDed back in.
  const { ['category__in']: _handledCategories, ...filterParams } = req.query;

  // LIMIT/OFFSET without ORDER BY lets Postgres repeat or skip rows between pages, which
  // the "load more" button walks straight into. An explicit `sort` replaces this default;
  // the id tiebreak is added after so it survives either way.
  qb.orderBy('artists.createdAt', 'DESC');

  const [artistRequests, count]: [ArtistRequest[], number] = await queryBuilder
    .apply(filterParams)
    .addOrderBy('artists.id', 'DESC')
    .getManyAndCount();
  const avatarPaths = artistRequests
    .map(ar => ar.user.avatar)
    .filter((path): path is string => Boolean(path));

  const avatarMap = await MinioService.getPublicUrls(avatarPaths);
  const portfoliosPaths = artistRequests.flatMap(ar =>
    ar.portfolios
      ?.map(portfolio => portfolio.filePath)
      .filter(Boolean) ?? []
  );
  const portfolioMap = await MinioService.getPublicUrls(portfoliosPaths)

  const serializedData = await artistRequestSerializer(
    artistRequests,
    avatarMap,
    portfolioMap,
    [...PUBLIC_EXCLUDED_USER_FIELDS],
    false,
    await publicExcludedAnswerKeys()
  );

  const page = Number(req.query.page) > 0 ? Number(req.query.page) : 1;
  const limit = Number(req.query.count) > 0 ? Math.min(Number(req.query.count), 100) : 20;

  return apiResponse(res, {
    statusCode: 200,
    success: true,
    data: serializedData,
    req,
    pagination: { page, limit, total: count },
  });
};


export const getRetrieveArtistsRequests = async (
  req: Request,
  res: Response,
) => {
  const { id } = req.params;
  const artistRequest = await artistRequestRepository()
    .createQueryBuilder('artists')
    .leftJoinAndSelect('artists.categories', 'categories')
    .distinct(true)
    .leftJoinAndSelect('artists.user', 'user')
    .leftJoinAndSelect('artists.portfolios', 'portfolios')
    .where("artists.id = :id", { id })
    .getOne();

  if (!artistRequest) {
    return apiResponse(res, {
      statusCode: 404,
      success: false,
      message: "Artist request not found",
    });
  }

  const avatarPaths = [artistRequest.user.avatar].filter((path): path is string => Boolean(path));
  const avatarMap = await MinioService.getPublicUrls(avatarPaths);

  const portfoliosPaths = artistRequest.portfolios
    ?.map(portfolio => portfolio.filePath)
    .filter((path): path is string => Boolean(path)) ?? [];
  const portfolioMap = await MinioService.getPublicUrls(portfoliosPaths);

  const serializedData = await artistRequestSerializer(
    [artistRequest],
    avatarMap,
    portfolioMap,
    [...PUBLIC_EXCLUDED_USER_FIELDS],
    false,
    await publicExcludedAnswerKeys()
  );

  return apiResponse(res, {
    statusCode: 200,
    success: true,
    data: serializedData[0],
  });
};

export const updateArtistRequestController = async (
  req: CustomRequest<{ user: User }>,
  res: Response
) => {
  const userId = req.payload?.user.id;
  const { id } = req.params;

  try {
    const { categoryIds, answers, portfolios } = req.body;

    const queryRunner =
      artistRequestRepository().manager.connection.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const artistRequest = await queryRunner.manager.findOne(ArtistRequest, {
        where: { id: Number(id), user: { id: userId } },
        relations: { categories: true },
        lock: { mode: "pessimistic_write" },
      });

      if (!artistRequest) {
        return apiResponse(res, {
          statusCode: 404,
          success: false,
          message: "Artist request not found",
        });
      }

      // A revised request has to go back through review, and its fee was refunded to
      // the wallet when the admin asked for changes — so it is charged again. The wallet
      // normally covers it in full, making the re-payment invisible to the artist.
      const wasRevision = artistRequest.status === ArtistRequestStatus.NEED_TO_REVISION;

      // update categories if provided
      if (Array.isArray(categoryIds) && categoryIds.length > 0) {
        artistRequest.categories = categoryIds.map((catId: number) => ({ id: catId } as any));
      }

      const topLevel = artistRequest.categories[0]
        ? await resolveTopLevelCategory(artistRequest.categories[0].id)
        : null;
      const schemaFields = topLevel ? await getAllFieldsForCategory(topLevel.id) : [];

      if (answers !== undefined) {
        const updateErrors = validateAnswers(schemaFields, answers);

        if (updateErrors.length) {
          // `finally` below releases the runner; only the transaction needs undoing here
          await queryRunner.rollbackTransaction();

          return apiResponse(res, {
            statusCode: 400,
            success: false,
            message: updateErrors[0],
            errors: updateErrors,
          });
        }

        artistRequest.answers = answers;
      }

      await queryRunner.manager.save(ArtistRequest, artistRequest);

      // sync fields marked syncToUserField into the user's account profile
      if (answers !== undefined && topLevel) {
        const fields = schemaFields;
        const user = await queryRunner.manager.findOne(User, {
          where: { id: userId },
          lock: { mode: "pessimistic_write" },
        });

        if (user) {
          for (const field of fields) {
            if (!field.syncToUserField) continue;
            if (answers[field.key] !== undefined) {
              (user as unknown as Record<string, unknown>)[field.syncToUserField] = answers[field.key];
            }
          }

          await queryRunner.manager.save(User, user);
        }
      }

      // portfolios: replace if provided, skip if not in body
      const resPortfolios = [];

      if (Array.isArray(portfolios)) {
        await queryRunner.manager.delete(ArtistPortfolio, {
          artistRequest: { id: artistRequest.id },
        });

        for (const file of portfolios) {
          const portfolio = await queryRunner.manager.save(
            artistPortfolioRepository().create({
              filePath: file.path,
              type: file.type,
              fieldKey: file.fieldKey ?? null,
              artistRequest: { id: artistRequest.id },
            })
          );

          resPortfolios.push({
            id: portfolio.id,
            filePath: portfolio.filePath,
            type: portfolio.type,
            fieldKey: portfolio.fieldKey ?? null,
          });
        }
      }

      await queryRunner.commitTransaction();

      return apiResponse(res, {
        statusCode: 200,
        success: true,
        message: "Artist request updated successfully",
        data: {
          artistRequestId: artistRequest.id,
          status: artistRequest.status,
          portfolios: resPortfolios,
          /** The client sends the artist to /user/purchase/ when this is true. */
          requiresPayment: wasRevision,
        },
      });
    } catch (err) {
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      await queryRunner.release();
    }
  } catch (error) {
    console.error("Error updating artist request:", error);
    return apiResponse(res, {
      statusCode: 500,
      success: false,
      message: "Failed to update artist request",
      errors: error instanceof Error ? error.message : "Unknown error",
    });
  }
};