import { Response } from "express";
import { User } from "../../entities/User.js";
import { CustomRequest } from "../../types/controllers.types.js";
import { apiResponse } from "../../utils/customResponse.js";
import { walletTransactionRepository } from "../../models/index.js";
import { paginate } from "../../utils/pagination.js";
import { WalletTransaction } from "../../entities/WalletTransaction.js";
import { getBalance } from "../../services/wallet.js";
import { WalletTransactionTypeFa } from "../../utils/enum.js";

/** Current balance, for the profile header and the payment screens. */
export const getWalletBalanceController = async (
  req: CustomRequest<{ user: User }>,
  res: Response,
) => {
  const balance = await getBalance(req.payload!.user.id);

  return apiResponse(res, { data: { balance } });
};

/** The caller's own ledger. */
export const getWalletTransactionsController = async (
  req: CustomRequest<{ user: User }>,
  res: Response,
) => {
  const user = req.payload!.user;

  const { data, meta } = await paginate<WalletTransaction>({
    repository: walletTransactionRepository(),
    req,
    options: {
      where: { user: { id: user.id } },
      order: { id: "DESC" },
    },
  });

  return apiResponse(res, {
    data: data.map((transaction) => ({
      id: transaction.id,
      amount: transaction.amount,
      type: transaction.type,
      typeLabel: WalletTransactionTypeFa[transaction.type],
      description: transaction.description,
      createdAt: transaction.createdAt,
    })),
    pagination: { ...meta },
    req,
  });
};
