import { Request, Response } from "express";
import { User } from "../../entities/User.js";
import { CustomRequest } from "../../types/controllers.types.js";
import { configs } from "../../config/configs.js";
import { apiResponse } from "../../utils/customResponse.js";
import { artistRequestRepository, contactRequestRepository } from "../../models/index.js";
import { ArtistRequestStatus, PaymentStatus } from "../../utils/enum.js";
import { MinioService } from "../../services/minio.js";
import { paginate } from "../../utils/pagination.js";
import { ContactRequest } from "../../entities/ContactRequest.js";
import { resolveTopLevelCategory } from "../../utils/formSchema.js";
import { isAmountSet } from "../../utils/amount.js";
import { isSandbox, zarinpalDriver } from "../../services/gateway.js";
import { credit, spend } from "../../services/wallet.js";
import { WalletTransactionType } from "../../utils/enum.js";

/**
 * Buying an artist's contact details.
 *
 * The contact fields are the paid product, so they are served only by `getArtistContact`,
 * and only when the caller owns a COMPLETED ContactRequest for that artist. Every other
 * endpoint strips them (see utils/privacy.ts).
 */

/** Zarinpal sends the buyer's browser here, so it cannot carry an auth header. */
const callbackUrl = (contactRequestId: number) =>
  `${configs.apiUrl}/api/contact-requests/callback/?contactRequestId=${contactRequestId}`;

/**
 * Contact price is per category, set by an admin on the category page. A child category
 * inherits its parent's price, and an unset price falls back to config. A price of 0 is
 * a real answer — the category is free — so it must not be confused with "unset".
 */
const contactAmountForArtist = async (artistRequestId: number): Promise<number | null> => {
  const artistRequest = await artistRequestRepository().findOne({
    where: { id: artistRequestId },
    relations: { categories: true },
  });

  if (!artistRequest) return null;

  for (const category of artistRequest.categories ?? []) {
    if (isAmountSet(category.contactAmount)) return category.contactAmount;

    const topLevel = await resolveTopLevelCategory(category.id);
    if (isAmountSet(topLevel?.contactAmount)) return topLevel.contactAmount;
  }

  return configs.contactRequestFallbackAmount;
};

/** Puts a reservation back when the gateway leg does not settle. */
const returnReservedWallet = async (contactRequest: ContactRequest) => {
  if (!contactRequest.walletAmount || contactRequest.walletAmount <= 0) return;

  await credit({
    userId: contactRequest.buyer?.id,
    amount: contactRequest.walletAmount,
    type: WalletTransactionType.REFUND_FAILED_PAYMENT,
    description: "بازگشت مبلغ رزروشده کیف پول به دلیل ناموفق بودن پرداخت",
    contactRequestId: contactRequest.id,
  });

  contactRequest.walletAmount = 0;
  await contactRequestRepository().save(contactRequest);
};

export const getContactRequestPriceController = async (req: Request, res: Response) => {
  const amount = await contactAmountForArtist(Number(req.params.id));

  if (amount === null) {
    return apiResponse(res, {
      statusCode: 404,
      success: false,
      message: "هنرمند یافت نشد.",
    });
  }

  return apiResponse(res, { data: { amount } });
};

export const createContactRequestController = async (
  req: CustomRequest<{ user: User }>,
  res: Response,
) => {
  const buyer = req.payload!.user;
  const artistRequestId = Number(req.params.id);
  const requesterName = String(req.body?.requesterName ?? "").trim();

  if (!requesterName) {
    return apiResponse(res, {
      statusCode: 400,
      success: false,
      message: "نام و نام خانوادگی الزامی است.",
    });
  }

  const artistRequest = await artistRequestRepository().findOne({
    where: { id: artistRequestId, status: ArtistRequestStatus.APPROVED },
  });

  if (!artistRequest) {
    return apiResponse(res, {
      statusCode: 404,
      success: false,
      message: "هنرمند یافت نشد.",
    });
  }

  // Already paid for — no second charge.
  const existing = await contactRequestRepository().findOne({
    where: {
      buyer: { id: buyer.id },
      artistRequest: { id: artistRequestId },
      status: PaymentStatus.COMPLETED,
    },
  });

  if (existing) {
    return apiResponse(res, {
      data: {
        id: existing.id,
        trackingCode: existing.trackingCode,
        status: existing.status,
        redirectUrl: null,
      },
      message: "اطلاعات تماس این هنرمند قبلاً برای شما آزاد شده است.",
    });
  }

  // Amount comes from the category; a client-supplied price is never trusted.
  const amount = (await contactAmountForArtist(artistRequestId))!;

  const contactRequest = await contactRequestRepository().save(
    contactRequestRepository().create({
      buyer: { id: buyer.id },
      artistRequest: { id: artistRequestId },
      requesterName,
      amount,
      status: PaymentStatus.PENDING,
    }),
  );

  // Wallet first; the reservation is released again if the gateway leg fails.
  const walletApplied = await spend({
    userId: buyer.id,
    requested: amount,
    type: WalletTransactionType.SPEND_CONTACT,
    description: "پرداخت هزینه مشاهده اطلاعات تماس از کیف پول",
    contactRequestId: contactRequest.id,
  });

  const dueAtGateway = amount - walletApplied;
  contactRequest.walletAmount = walletApplied;
  contactRequest.amount = dueAtGateway;

  // Persisted before the gateway call: the ledger has already been debited, so a crash
  // between here and the redirect must not leave a row that has forgotten about it.
  await contactRequestRepository().save(contactRequest);

  // Nothing left to charge — free category, or the wallet covered it. The unlock still
  // goes through a COMPLETED row, never through a looser read guard.
  if (dueAtGateway === 0) {
    contactRequest.status = PaymentStatus.COMPLETED;
    await contactRequestRepository().save(contactRequest);

    return apiResponse(res, {
      statusCode: 201,
      data: {
        id: contactRequest.id,
        trackingCode: contactRequest.trackingCode,
        status: contactRequest.status,
        redirectUrl: null,
      },
    });
  }

  try {
    const paymentInfo = await (await zarinpalDriver()).request({
      amount: dueAtGateway,
      callbackUrl: callbackUrl(contactRequest.id),
    });

    contactRequest.paymentId = String(paymentInfo.referenceId);
    await contactRequestRepository().save(contactRequest);

    return apiResponse(res, {
      statusCode: 201,
      data: {
        id: contactRequest.id,
        trackingCode: contactRequest.trackingCode,
        status: contactRequest.status,
        // Zarinpal's StartPay page keyed by the authority it just issued.
        redirectUrl: `${
          (await isSandbox())
            ? "https://sandbox.zarinpal.com"
            : "https://www.zarinpal.com"
        }/pg/StartPay/${paymentInfo.referenceId}`,
      },
    });
  } catch {
    contactRequest.status = PaymentStatus.FAILED;
    await contactRequestRepository().save(contactRequest);
    await returnReservedWallet(contactRequest);

    return apiResponse(res, {
      statusCode: 502,
      success: false,
      message: "خطا در اتصال به درگاه پرداخت. لطفاً دوباره تلاش کنید.",
    });
  }
};

/** Gateway return URL. Redirects the browser back into the app either way. */
export const contactRequestCallbackController = async (req: Request, res: Response) => {
  const contactRequestId = Number(req.query.contactRequestId);
  const contactRequest = await contactRequestRepository().findOne({
    where: { id: contactRequestId },
    relations: { artistRequest: true, buyer: true },
  });

  if (!contactRequest) {
    return res.redirect(`${configs.appUrl}/profile?contact=notfound`);
  }

  const artistId = contactRequest.artistRequest.id;
  const fail = (reason: string) =>
    res.redirect(`${configs.appUrl}/artists/${artistId}?contact=${reason}`);

  if (req.query.Status !== "OK") {
    contactRequest.status = PaymentStatus.CANCELED;
    await contactRequestRepository().save(contactRequest);
    await returnReservedWallet(contactRequest);
    return fail("canceled");
  }

  // Replayed callback for an already-settled request: don't verify twice.
  if (contactRequest.status === PaymentStatus.COMPLETED) {
    return res.redirect(`${configs.appUrl}/artists/${artistId}?contact=success`);
  }

  try {
    await (await zarinpalDriver()).verify(
      { amount: contactRequest.amount },
      { ...req.query, ...req.body },
    );

    contactRequest.status = PaymentStatus.COMPLETED;
    await contactRequestRepository().save(contactRequest);

    return res.redirect(
      `${configs.appUrl}/artists/${artistId}?contact=success&tracking=${contactRequest.trackingCode}`,
    );
  } catch {
    contactRequest.status = PaymentStatus.FAILED;
    await contactRequestRepository().save(contactRequest);
    await returnReservedWallet(contactRequest);
    return fail("failed");
  }
};

/**
 * The paid payload. Returns 403 unless the caller has a COMPLETED purchase for this
 * artist — or is the artist themselves.
 */
export const getArtistContactController = async (
  req: CustomRequest<{ user: User }>,
  res: Response,
) => {
  const buyer = req.payload!.user;
  const artistRequestId = Number(req.params.id);

  const artistRequest = await artistRequestRepository().findOne({
    where: { id: artistRequestId },
    relations: { user: true },
  });

  if (!artistRequest) {
    return apiResponse(res, {
      statusCode: 404,
      success: false,
      message: "هنرمند یافت نشد.",
    });
  }

  const isOwner = artistRequest.user.id === buyer.id;

  if (!isOwner) {
    const purchase = await contactRequestRepository().findOne({
      where: {
        buyer: { id: buyer.id },
        artistRequest: { id: artistRequestId },
        status: PaymentStatus.COMPLETED,
      },
    });

    if (!purchase) {
      return apiResponse(res, {
        statusCode: 403,
        success: false,
        message: "برای مشاهده اطلاعات تماس، ابتدا درخواست خود را پرداخت کنید.",
      });
    }
  }

  const answers = artistRequest.answers ?? {};

  return apiResponse(res, {
    data: {
      firstName: artistRequest.user.firstName,
      lastName: artistRequest.user.lastName,
      phoneNumber: artistRequest.user.phone_number,
      email: artistRequest.user.email ?? (answers.email as string | undefined) ?? null,
      address: (answers.address as string | undefined) ?? null,
      postalCode: (answers.postalCode as string | undefined) ?? null,
    },
  });
};

/** Feeds the profile page's "درخواست‌های ارتباط با هنرمندان" section. */
export const getMyContactRequestsController = async (
  req: CustomRequest<{ user: User }>,
  res: Response,
) => {
  const buyer = req.payload!.user;

  const { data, meta } = await paginate<ContactRequest>({
    repository: contactRequestRepository(),
    req,
    options: {
      where: { buyer: { id: buyer.id } },
      relations: { artistRequest: { user: true, categories: true } },
      order: { id: "DESC" },
    },
  });

  const avatarPaths = data
    .map((request) => request.artistRequest?.user?.avatar)
    .filter((path): path is string => Boolean(path));
  const avatarMap = await MinioService.getPublicUrls(avatarPaths);

  return apiResponse(res, {
    data: data.map((request) => ({
      id: request.id,
      trackingCode: request.trackingCode,
      status: request.status,
      amount: request.amount + (request.walletAmount ?? 0),
      walletAmount: request.walletAmount ?? 0,
      createdAt: request.createdAt,
      artist: {
        id: request.artistRequest.id,
        code: request.artistRequest.user?.code ?? null,
        avatar: request.artistRequest.user?.avatar
          ? (avatarMap[request.artistRequest.user.avatar] ?? null)
          : null,
        categories: (request.artistRequest.categories ?? []).map((category) => ({
          id: category.id,
          faName: category.faName,
        })),
      },
    })),
    pagination: { ...meta },
    req,
  });
};
