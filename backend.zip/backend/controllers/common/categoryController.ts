import { Request, Response } from "express";
import { IsNull } from "typeorm";
import { categoryRepository } from "../../models/index.js";
import { paginate } from "../../utils/pagination.js";
import { apiResponse } from "../../utils/customResponse.js";
import { MinioService } from "../../services/minio.js";
import { Category } from "../../entities/Category.js";

export const categoryController = async (req: Request, res: Response) => {
  const { data, meta } = await paginate({
    repository: categoryRepository(),
    req,
    options: {
      where: { parent: IsNull() },
      relations: { children: true },
      order: { id: "DESC" }
    }
  });

  const categories = data as Category[];
  const urlMap = await MinioService.getPublicUrls(
    categories.filter((c) => c.image).map((c) => c.image as string),
  );
  const serialized = categories.map((category) => ({
    ...category,
    image: category.image ? (urlMap[category.image] ?? null) : null,
  }));

  return apiResponse(res, {
    data: serialized,
    pagination: meta,
    req,
    success: true
  });
};
