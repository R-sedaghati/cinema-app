import { Request, Response } from "express";
import { apiResponse } from "../../utils/customResponse.js";
import { artistRequestRepository, categoryRepository } from "../../models/index.js";
import { getAllFieldsForCategory, resolveTopLevelCategory } from "../../utils/formSchema.js";
import {
  MAX_FACET_OPTIONS,
  answerParam,
  isFilterableField,
  isMultiValueField,
} from "../../utils/answerFilters.js";
import { FormField } from "../../entities/FormField.js";
import { FormFieldType, ArtistRequestStatus } from "../../utils/enum.js";
import { Category } from "../../entities/Category.js";

interface FilterOption {
  label: string;
  value: string;
  count: number;
}

type FilterDescriptor =
  | {
      key: string;
      label: string;
      kind: "select";
      param: string;
      options: FilterOption[];
    }
  | {
      key: string;
      label: string;
      kind: "range";
      paramMin: string;
      paramMax: string;
      min: number;
      max: number;
    };

/** Category ids an artist may be tagged with when the top-level category is selected. */
const categoryScope = async (topLevel: Category): Promise<number[]> => {
  const children = await categoryRepository().find({
    where: { parent: { id: topLevel.id } },
    select: { id: true },
  });

  return [topLevel.id, ...children.map((child) => child.id)];
};

/**
 * Distinct answer values for a field across approved artists in the category, most common
 * first. Used for TEXT fields, which carry no admin-authored options but are how the seeded
 * default form models province/city/education.
 *
 * ponytail: DISTINCT scan per request. Cache in Redis (already configured) if it shows up
 * in slow queries.
 */
const distinctAnswerValues = async (
  field: FormField,
  categoryIds: number[]
): Promise<FilterOption[]> => {
  const qb = artistRequestRepository()
    .createQueryBuilder("artists")
    .innerJoin("artists.categories", "categories")
    .where("artists.status = :status", { status: ArtistRequestStatus.APPROVED })
    .andWhere("categories.id IN (:...categoryIds)", { categoryIds })
    .limit(MAX_FACET_OPTIONS + 1);

  if (isMultiValueField(field)) {
    // Array answers are unnested so each chosen option is counted on its own.
    qb.innerJoin(
      `jsonb_array_elements_text(artists.answers -> '${field.key}')`,
      "element",
      "TRUE"
    )
      .select("element", "value")
      .andWhere(`jsonb_typeof(artists.answers -> '${field.key}') = 'array'`)
      .groupBy("element");
  } else {
    const column = `artists.answers ->> '${field.key}'`;
    qb.select(column, "value")
      .andWhere(`${column} IS NOT NULL`)
      .andWhere(`${column} <> ''`)
      .groupBy(column);
  }

  // Must come after `.select()`, which resets the select list.
  qb.addSelect("COUNT(*)", "count").orderBy("COUNT(*)", "DESC");

  const rows = await qb.getRawMany<{ value: string | null; count: string }>();

  return rows
    .filter((row): row is { value: string; count: string } => Boolean(row.value))
    .map((row) => ({
      label: row.value,
      value: row.value,
      count: Number(row.count),
    }));
};

const numericBounds = async (
  field: FormField,
  categoryIds: number[]
): Promise<{ min: number; max: number } | null> => {
  const validation = (field.validation ?? {}) as { min?: number; max?: number };

  if (typeof validation.min === "number" && typeof validation.max === "number") {
    return { min: validation.min, max: validation.max };
  }

  const column = `(artists.answers ->> '${field.key}')::numeric`;
  const row = await artistRequestRepository()
    .createQueryBuilder("artists")
    .innerJoin("artists.categories", "categories")
    .select(`MIN(${column})`, "min")
    .addSelect(`MAX(${column})`, "max")
    .where("artists.status = :status", { status: ArtistRequestStatus.APPROVED })
    .andWhere("categories.id IN (:...categoryIds)", { categoryIds })
    .andWhere(`artists.answers ->> '${field.key}' ~ '^[0-9]+(\\.[0-9]+)?$'`)
    .getRawOne<{ min: string | null; max: string | null }>();

  if (!row?.min || !row?.max) return null;

  return {
    min: validation.min ?? Math.floor(Number(row.min)),
    max: validation.max ?? Math.ceil(Number(row.max)),
  };
};

const describeField = async (
  field: FormField,
  categoryIds: number[]
): Promise<FilterDescriptor | null> => {
  if (field.type === FormFieldType.NUMBER) {
    const bounds = await numericBounds(field, categoryIds);
    if (!bounds || bounds.min === bounds.max) return null;

    return {
      key: field.key,
      label: field.label,
      kind: "range",
      paramMin: `${answerParam(field)}__gte`,
      paramMax: `${answerParam(field)}__lte`,
      ...bounds,
    };
  }

  // Admin-authored options win; TEXT fields fall back to what artists actually answered.
  const options = field.options?.length
    ? field.options.map((option) => ({ ...option, count: 0 }))
    : await distinctAnswerValues(field, categoryIds);

  // Nothing to pick from, or so many values it is free text rather than a facet.
  if (options.length === 0 || options.length > MAX_FACET_OPTIONS) return null;

  return {
    key: field.key,
    label: field.label,
    kind: "select",
    param: answerParam(field),
    options,
  };
};

export const getArtistFiltersController = async (req: Request, res: Response) => {
  const topLevel = await resolveTopLevelCategory(Number(req.params.id));

  if (!topLevel || !topLevel.isActive) {
    return apiResponse(res, {
      statusCode: 404,
      success: false,
      message: "Category not found",
    });
  }

  const categoryIds = await categoryScope(topLevel);
  const fields = (await getAllFieldsForCategory(topLevel.id)).filter(isFilterableField);

  const descriptors = await Promise.all(
    fields.map((field) => describeField(field, categoryIds))
  );

  return apiResponse(res, {
    data: descriptors.filter((descriptor): descriptor is FilterDescriptor =>
      Boolean(descriptor)
    ),
  });
};
