import { Request, Response } from "express";
import { apiResponse } from "../../utils/customResponse.js";
import { getFormStepsForCategory, resolveTopLevelCategory } from "../../utils/formSchema.js";
import { configs } from "../../config/configs.js";
import { isAmountSet } from "../../utils/amount.js";
import { optionalUserId } from "../../utils/optionalUser.js";
import { hasPaidRegistration } from "../../services/registration.js";

export const getPublicFormSchemaController = async (req: Request, res: Response) => {
  const { id } = req.params;
  const topLevel = await resolveTopLevelCategory(Number(id));

  if (!topLevel || !topLevel.isActive) {
    return apiResponse(res, { statusCode: 404, success: false, message: "Category not found" });
  }

  const steps = await getFormStepsForCategory(topLevel.id);

  // The registration fee is charged once per user, so a caller who already paid one
  // sees this form as free. Anonymous callers see the category price. The gateway
  // resolves the same rule again at payment time — this is only what the form shows.
  const alreadyPaid = await hasPaidRegistration(optionalUserId(req));

  return apiResponse(res, {
    data: {
      steps,
      successTitle: topLevel.successTitle ?? null,
      successDescription: topLevel.successDescription ?? null,
      failTitle: topLevel.failTitle ?? null,
      failDescription: topLevel.failDescription ?? null,
      formCopy: topLevel.formCopy ?? {},
      // The fee the registration form displays. Resolved here so the frontend never
      // carries a price of its own; 0 means this category is free to register in.
      registrationAmount: alreadyPaid
        ? 0
        : isAmountSet(topLevel.registrationAmount)
          ? topLevel.registrationAmount
          : configs.registrationAmount,
    },
  });
};
