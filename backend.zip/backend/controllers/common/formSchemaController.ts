import { Request, Response } from "express";
import { apiResponse } from "../../utils/customResponse.js";
import { getFormStepsForCategory, resolveTopLevelCategory } from "../../utils/formSchema.js";

export const getPublicFormSchemaController = async (req: Request, res: Response) => {
  const { id } = req.params;
  const topLevel = await resolveTopLevelCategory(Number(id));

  if (!topLevel || !topLevel.isActive) {
    return apiResponse(res, { statusCode: 404, success: false, message: "Category not found" });
  }

  const steps = await getFormStepsForCategory(topLevel.id);

  return apiResponse(res, { data: { steps } });
};
