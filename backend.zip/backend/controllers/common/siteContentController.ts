import { Request, Response } from "express";
import { apiResponse } from "../../utils/customResponse.js";
import { getOrCreateSiteContent } from "../admin/siteContentController.js";

export const siteContentController = async (req: Request, res: Response) => {
    const data = await getOrCreateSiteContent();
    return apiResponse(res, {
        data
    })
}
