import { Request, Response } from "express";
import { FindOptionsWhere, ILike } from "typeorm";
import { contactRequestRepository } from "../../models/index.js";
import { apiResponse } from "../../utils/customResponse.js";
import { paginate } from "../../utils/pagination.js";
import { ContactRequest } from "../../entities/ContactRequest.js";
import { PaymentStatus } from "../../utils/enum.js";

/**
 * Every contact-detail purchase, for the admin transactions table.
 *
 * Buyer identity is intentionally included — this is the admin view, not the public one
 * that `utils/privacy.ts` strips.
 */
export const adminContactRequestListController = async (req: Request, res: Response) => {
  const status = String(req.query.status ?? "").toUpperCase();

  const base: FindOptionsWhere<ContactRequest> = {};
  if (status && status in PaymentStatus) {
    base.status = PaymentStatus[status as keyof typeof PaymentStatus];
  }

  // The admin search box offers tracking code, requester name and buyer phone. TypeORM
  // ORs across an array of wheres, so each term gets its own copy of the base filter.
  const search = String(req.query.search ?? "").trim();
  const where: FindOptionsWhere<ContactRequest>[] | FindOptionsWhere<ContactRequest> = search
    ? [
        { ...base, trackingCode: ILike(`%${search}%`) },
        { ...base, requesterName: ILike(`%${search}%`) },
        { ...base, buyer: { phone_number: ILike(`%${search}%`) } },
      ]
    : base;

  const { data, meta } = await paginate<ContactRequest>({
    repository: contactRequestRepository(),
    req,
    options: {
      where,
      relations: { buyer: true, artistRequest: { user: true, categories: true } },
      order: { id: "DESC" },
    },
  });

  return apiResponse(res, {
    data: data.map((request) => ({
      id: request.id,
      trackingCode: request.trackingCode,
      status: request.status,
      amount: request.amount,
      paymentGateway: request.paymentGateway,
      createdAt: request.createdAt,
      requesterName: request.requesterName,
      buyer: {
        id: request.buyer?.id ?? null,
        phoneNumber: request.buyer?.phone_number ?? null,
      },
      artist: {
        id: request.artistRequest?.id ?? null,
        code: request.artistRequest?.user?.code ?? null,
        categories: (request.artistRequest?.categories ?? []).map((category) => ({
          id: category.id,
          faName: category.faName,
        })),
      },
    })),
    pagination: { ...meta },
    req,
  });
};
