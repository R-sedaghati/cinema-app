import { Request, Response } from "express";
import { notificationSettingRepository } from "../../models/index.js";
import { apiResponse } from "../../utils/customResponse.js";
import { NotificationEvent } from "../../utils/enum.js";
import {
  clearNotificationSettingCache,
  getNotificationSetting,
  sanitizePhones,
} from "../../services/adminNotify.js";
import { NotificationSetting } from "../../entities/NotificationSetting.js";

const serialize = (setting: NotificationSetting) => ({
  phones: setting.phones ?? [],
  events: setting.events ?? [],
});

export const notificationSettingAdminController = async (_req: Request, res: Response) => {
  const setting = await getNotificationSetting();

  return apiResponse(res, { data: serialize(setting) });
};

export const updateNotificationSettingAdminController = async (
  req: Request,
  res: Response,
) => {
  const { phones, events } = req.body;

  const setting = await getNotificationSetting();

  // Both lists are validated before either is applied: `setting` is the cached instance
  // the notifier reads from, so a half-applied rejected save would start texting a
  // number the admin never confirmed.
  let nextPhones: string[] | undefined;
  let nextEvents: NotificationEvent[] | undefined;

  if (phones !== undefined) {
    if (!Array.isArray(phones)) {
      return apiResponse(res, {
        success: false,
        statusCode: 400,
        message: "لیست شماره‌ها معتبر نیست.",
      });
    }

    const sanitized = sanitizePhones(phones);

    if (!sanitized) {
      return apiResponse(res, {
        success: false,
        statusCode: 400,
        message: "شماره موبایل معتبر نیست.",
      });
    }

    nextPhones = sanitized;
  }

  if (events !== undefined) {
    const allowed = Object.values(NotificationEvent) as string[];

    if (!Array.isArray(events) || !events.every((e) => allowed.includes(String(e)))) {
      return apiResponse(res, {
        success: false,
        statusCode: 400,
        message: "رویداد اعلان معتبر نیست.",
      });
    }

    nextEvents = [...new Set(events as NotificationEvent[])];
  }

  // Each field replaces the stored list rather than merging — the form always sends both
  // in full, so a merge would make removing a number impossible.
  if (nextPhones) setting.phones = nextPhones;
  if (nextEvents) setting.events = nextEvents;

  // Drop the cache either way: a failed save must not leave unsaved recipients in front
  // of the notifier.
  try {
    const saved = await notificationSettingRepository().save(setting);

    return apiResponse(res, { data: serialize(saved) });
  } finally {
    clearNotificationSettingCache();
  }
};
