import { Request, Response } from "express";
import { CustomRequest } from "../../types/controllers.types.js";
import { Admin } from "../../entities/Admin.js";
import { apiResponse } from "../../utils/customResponse.js";
import { userRepository, walletTransactionRepository } from "../../models/index.js";
import { paginate } from "../../utils/pagination.js";
import { WalletTransaction } from "../../entities/WalletTransaction.js";
import { credit, debitUnchecked, getBalance } from "../../services/wallet.js";
import { WalletTransactionType, WalletTransactionTypeFa } from "../../utils/enum.js";

/** One user's balance and ledger, for the admin user page. */
export const adminUserWalletController = async (req: Request, res: Response) => {
  const userId = Number(req.params.id);

  const user = await userRepository().findOne({ where: { id: userId } });

  if (!user) {
    return apiResponse(res, {
      statusCode: 404,
      success: false,
      message: "کاربر یافت نشد.",
    });
  }

  const balance = await getBalance(userId);

  const { data, meta } = await paginate<WalletTransaction>({
    repository: walletTransactionRepository(),
    req,
    options: {
      where: { user: { id: userId } },
      relations: { admin: true },
      order: { id: "DESC" },
    },
  });

  return apiResponse(res, {
    data: {
      balance,
      transactions: data.map((transaction) => ({
        id: transaction.id,
        amount: transaction.amount,
        type: transaction.type,
        typeLabel: WalletTransactionTypeFa[transaction.type],
        description: transaction.description,
        adminUsername: transaction.admin?.username ?? null,
        createdAt: transaction.createdAt,
      })),
    },
    pagination: { ...meta },
    req,
  });
};

/**
 * Manual adjustment. `amount` is signed — positive adds, negative removes.
 *
 * A deduction is allowed to push the balance negative: refusing it would leave an admin
 * unable to correct a mistaken credit that the user has already partly spent.
 */
export const adminAdjustWalletController = async (
  req: CustomRequest<{ admin: Admin }>,
  res: Response,
) => {
  const userId = Number(req.params.id);
  const amount = Math.round(Number(req.body?.amount));
  const description = String(req.body?.description ?? "").trim();

  if (!Number.isFinite(amount) || amount === 0) {
    return apiResponse(res, {
      statusCode: 400,
      success: false,
      message: "مبلغ باید عددی غیر از صفر باشد.",
    });
  }

  if (!description) {
    return apiResponse(res, {
      statusCode: 400,
      success: false,
      message: "توضیح دلیل تغییر الزامی است.",
    });
  }

  const user = await userRepository().findOne({ where: { id: userId } });

  if (!user) {
    return apiResponse(res, {
      statusCode: 404,
      success: false,
      message: "کاربر یافت نشد.",
    });
  }

  const adminId = req.payload?.admin?.id ?? null;

  if (amount > 0) {
    await credit({
      userId,
      amount,
      type: WalletTransactionType.ADMIN_ADJUST,
      description,
      adminId,
    });
  } else {
    await debitUnchecked({
      userId,
      amount,
      type: WalletTransactionType.ADMIN_ADJUST,
      description,
      adminId,
    });
  }

  return apiResponse(res, { data: { balance: await getBalance(userId) } });
};
