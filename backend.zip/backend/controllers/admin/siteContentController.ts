import { Request, Response } from "express";
import { siteContentRepository } from "../../models/index.js";
import { apiResponse } from "../../utils/customResponse.js";
import { SiteContent } from "../../entities/SiteContent.js";

export const getOrCreateSiteContent = async (): Promise<SiteContent> => {
    const [existing] = await siteContentRepository().find({
        order: { id: "ASC" },
        take: 1,
    });

    if (existing) {
        return existing;
    }

    const created = siteContentRepository().create({});
    return siteContentRepository().save(created);
};

export const siteContentAdminController = async (req: Request, res: Response) => {
    const data = await getOrCreateSiteContent();
    return apiResponse(res, {
        data
    })
}

export const updateSiteContentAdminController = async (req: Request, res: Response) => {
    const { benefits, support, terms, footer, landing, form, contactForm } = req.body;

    const content = await getOrCreateSiteContent();

    if (benefits !== undefined) content.benefits = benefits;
    if (support !== undefined) content.support = support;
    if (terms !== undefined) content.terms = terms;
    if (footer !== undefined) content.footer = footer;
    // Merged key by key so a partial save never drops copy set elsewhere.
    if (landing !== undefined) content.landing = { ...(content.landing ?? {}), ...landing };
    if (form !== undefined) content.form = { ...(content.form ?? {}), ...form };
    if (contactForm !== undefined) content.contactForm = contactForm;

    const data = await siteContentRepository().save(content);
    return apiResponse(res, {
        data
    })
}
