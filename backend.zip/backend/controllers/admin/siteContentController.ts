import { Request, Response } from "express";
import { siteContentRepository } from "../../models/index.js";
import { apiResponse } from "../../utils/customResponse.js";
import { SiteContent } from "../../entities/SiteContent.js";

export const getOrCreateSiteContent = async (): Promise<SiteContent> => {
    const [existing] = await siteContentRepository().find({
        order: { id: "ASC" },
        take: 1,
    });

    if (existing) {
        return existing;
    }

    const created = siteContentRepository().create({});
    return siteContentRepository().save(created);
};

export const siteContentAdminController = async (req: Request, res: Response) => {
    const data = await getOrCreateSiteContent();
    return apiResponse(res, {
        data
    })
}

export const updateSiteContentAdminController = async (req: Request, res: Response) => {
    const { benefits, support, terms } = req.body;

    const content = await getOrCreateSiteContent();

    if (benefits !== undefined) content.benefits = benefits;
    if (support !== undefined) content.support = support;
    if (terms !== undefined) content.terms = terms;

    const data = await siteContentRepository().save(content);
    return apiResponse(res, {
        data
    })
}
