import { Request, Response } from "express";
import { paymentSettingRepository } from "../../models/index.js";
import { apiResponse } from "../../utils/customResponse.js";
import { configs } from "../../config/configs.js";
import { clearPaymentSettingCache, getPaymentSetting } from "../../services/gateway.js";

/**
 * Gateway credentials for the admin panel.
 *
 * The merchant key is a secret, so it leaves the server only masked. That means a save
 * cannot round-trip it: a submitted value that still looks like a mask is treated as
 * "unchanged" rather than written, otherwise re-saving the form would corrupt the key.
 */

/** `****-****-****-abc1` — enough to tell two keys apart, not enough to use one. */
const maskMerchantId = (merchantId: string) =>
  merchantId.length <= 4 ? "****" : `****-****-****-${merchantId.slice(-4)}`;

const isMasked = (value: string) => value.startsWith("****");

const serialize = (merchantId: string | null | undefined, sandbox: boolean) => ({
  merchantId: merchantId ? maskMerchantId(merchantId) : null,
  hasMerchantId: Boolean(merchantId),
  sandbox,
  // Surfaces that the gateway still works off the env var, so an empty field on the
  // page does not read as "payments are broken".
  usingEnvFallback: !merchantId && Boolean(configs.gatewayConfiguration.merchantId),
});

export const paymentSettingAdminController = async (_req: Request, res: Response) => {
  const setting = await getPaymentSetting();

  return apiResponse(res, {
    data: serialize(setting.merchantId, setting.sandbox),
  });
};

export const updatePaymentSettingAdminController = async (req: Request, res: Response) => {
  const { merchantId, sandbox } = req.body;

  const setting = await getPaymentSetting();

  if (merchantId !== undefined) {
    const value = String(merchantId ?? "").trim();

    // An empty field clears the key (falling back to env); a mask means untouched.
    if (!value) {
      setting.merchantId = null;
    } else if (!isMasked(value)) {
      setting.merchantId = value;
    }
  }

  if (sandbox !== undefined) {
    setting.sandbox = Boolean(sandbox);
  }

  // `setting` is the cached instance, so it already carries the edits. Drop the cache
  // either way — a failed save must not leave unsaved credentials in front of the driver.
  try {
    const saved = await paymentSettingRepository().save(setting);

    return apiResponse(res, {
      data: serialize(saved.merchantId, saved.sandbox),
    });
  } finally {
    clearPaymentSettingCache();
  }
};
