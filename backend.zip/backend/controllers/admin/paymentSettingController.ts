import { Request, Response } from "express";
import { paymentSettingRepository } from "../../models/index.js";
import { apiResponse } from "../../utils/customResponse.js";
import { configs } from "../../config/configs.js";
import {
  clearPaymentSettingCache,
  getPaymentSetting,
  testSepConnection,
  SEP_DEFAULTS,
} from "../../services/gateway.js";
import { PaymentSetting } from "../../entities/PaymentSetting.js";

/**
 * SEP gateway credentials for the admin panel.
 *
 * The terminal ID is a secret, so it leaves the server only masked. That means a save
 * cannot round-trip it: a submitted value that still looks like a mask is treated as
 * "unchanged" rather than written, otherwise re-saving the form would corrupt it.
 */

/** `****-****-****-abc1` — enough to tell two terminals apart, not enough to use one. */
const maskTerminalId = (terminalId: string) =>
  terminalId.length <= 4 ? "****" : `****-****-****-${terminalId.slice(-4)}`;

const isMasked = (value: string) => value.startsWith("****");

/** The endpoints are not secret, so they go back as-is — resolved, so the page shows what
 * the gateway will actually call rather than an empty box. */
const serialize = (setting: PaymentSetting) => ({
  terminalId: setting.terminalId ? maskTerminalId(setting.terminalId) : null,
  hasTerminalId: Boolean(setting.terminalId),
  tokenUrl: setting.tokenUrl || SEP_DEFAULTS.tokenUrl,
  verifyUrl: setting.verifyUrl || SEP_DEFAULTS.verifyUrl,
  paymentUrl: setting.paymentUrl || SEP_DEFAULTS.paymentUrl,
  /** So the page can show which endpoints are overridden rather than inherited. */
  defaults: SEP_DEFAULTS,
  // Surfaces that the gateway still works off the env var, so an empty field on the
  // page does not read as "payments are broken".
  usingEnvFallback:
    !setting.terminalId && Boolean(configs.gatewayConfiguration.terminalId),
});

/**
 * An endpoint is only worth storing if it is a URL we would actually call — a typo here
 * takes payments down, and the failure would surface as an opaque fetch error much later.
 */
const isValidEndpoint = (value: string) => {
  try {
    const { protocol } = new URL(value);
    return protocol === "https:" || protocol === "http:";
  } catch {
    return false;
  }
};

const ENDPOINT_FIELDS = ["tokenUrl", "verifyUrl", "paymentUrl"] as const;

export const paymentSettingAdminController = async (_req: Request, res: Response) => {
  const setting = await getPaymentSetting();

  return apiResponse(res, { data: serialize(setting) });
};

export const updatePaymentSettingAdminController = async (req: Request, res: Response) => {
  const { terminalId } = req.body;

  const setting = await getPaymentSetting();

  // Validated in full before anything is written: `setting` is the cached instance the
  // driver reads from, so a half-applied rejected save would leave bad endpoints in
  // front of live payments.
  const endpointEdits: Partial<Record<(typeof ENDPOINT_FIELDS)[number], string | null>> = {};

  for (const field of ENDPOINT_FIELDS) {
    if (req.body[field] === undefined) continue;

    const value = String(req.body[field] ?? "").trim();

    // Blank means "inherit the shipped default" rather than "call nothing".
    if (!value) {
      endpointEdits[field] = null;
      continue;
    }

    if (!isValidEndpoint(value)) {
      return apiResponse(res, {
        success: false,
        statusCode: 400,
        message: "آدرس درگاه معتبر نیست.",
      });
    }

    endpointEdits[field] = value;
  }

  Object.assign(setting, endpointEdits);

  if (terminalId !== undefined) {
    const value = String(terminalId ?? "").trim();

    // An empty field clears the terminal (falling back to env); a mask means untouched.
    if (!value) {
      setting.terminalId = null;
    } else if (!isMasked(value)) {
      setting.terminalId = value;
    }
  }

  // `setting` is the cached instance, so it already carries the edits. Drop the cache
  // either way — a failed save must not leave unsaved credentials in front of the driver.
  try {
    const saved = await paymentSettingRepository().save(setting);

    return apiResponse(res, { data: serialize(saved) });
  } finally {
    clearPaymentSettingCache();
  }
};

/**
 * Ask SEP for a throwaway token with whatever is stored, so a wrong terminal or a typo'd
 * endpoint surfaces here instead of on a real buyer's checkout.
 */
export const testPaymentSettingAdminController = async (_req: Request, res: Response) => {
  const { ok, message } = await testSepConnection();

  return apiResponse(res, { success: ok, data: { ok, message }, message });
};
