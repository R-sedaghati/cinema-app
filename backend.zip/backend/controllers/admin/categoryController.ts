import { Request, Response } from "express";
import { categoryRepository } from "../../models/index.js";
import { paginate } from "../../utils/pagination.js";
import { IsNull } from "typeorm";
import { apiResponse } from "../../utils/customResponse.js";
import { SearchAndFilterService } from "../../services/searchAndFilter.js";
import { ArtistRequest } from "../../entities/ArtistRequest.js";
import { Category } from "../../entities/Category.js";
import { MinioService } from "../../services/minio.js";

const serializeCategory = async (category: Category) => ({
  ...category,
  image: await category.getImageUrl(),
});

export const categoryController = async (req: Request, res: Response) => {
  const page = Math.max(1, Number(req.query.page) || 1);
  const limit = Math.min(100, Math.max(1, Number(req.query.count) || 10));

  const query = categoryRepository()
    .createQueryBuilder("category")
    .loadRelationCountAndMap(
      "category.artistRequestsCount",
      "category.artistRequests"
    )
    .loadRelationIdAndMap("category.parent", "category.parent")
    .orderBy(
      "CASE WHEN category.parent_id IS NULL THEN 0 ELSE 1 END",
      "ASC"
    )
    .addOrderBy("category.priority", "ASC")
    .addOrderBy("category.id", "ASC")
    .skip((page - 1) * limit)
    .take(limit);

  const queryBuilder = new SearchAndFilterService<Category>(
    query,
    {
      filterable: {
        isActive: 'category.isActive'
      },
      searchable: [
        'category.faName'
      ],
      sortable: {}
    }
  )

  const [categories, total]: [Category[], number] = await queryBuilder.apply(req.query).getManyAndCount();

  const urlMap = await MinioService.getPublicUrls(
    categories.filter((c) => c.image).map((c) => c.image as string),
  );
  const data = categories.map((category) => ({
    ...category,
    image: category.image ? (urlMap[category.image] ?? null) : null,
  }));

  return apiResponse(res, {
    data,
    pagination: {
      page,
      limit,
      total,
    },
    req
  });
};

export const createCategoryController = async (req: Request, res: Response) => {
  try {
    const { faName, enName, description, parentId, isActive, priority, image, contactAmount } = req.body;

    if (!faName || !enName) {
      return apiResponse(res, {
        statusCode: 400,
        success: false,
        message: "faName and enName are required",
      });
    }

    let parent: Category | null = null;
    if (parentId !== undefined && parentId !== null) {
      parent = await categoryRepository().findOne({ where: { id: Number(parentId) } });

      if (!parent) {
        return apiResponse(res, {
          statusCode: 404,
          success: false,
          message: "Parent category not found",
        });
      }
    }

    const category = categoryRepository().create({
      faName,
      enName,
      description: description ?? null,
      parent,
      priority: priority ?? null,
      isActive: isActive ?? true,
      image: image ?? null,
      contactAmount: contactAmount ?? null,
    });

    const saved = await categoryRepository().save(category);

    return apiResponse(res, {
      statusCode: 201,
      data: await serializeCategory(saved),
    });
  } catch (error) {
    return apiResponse(res, {
      statusCode: 500,
      success: false,
      message: "Failed to create category",
    });
  }
};

export const deleteCategoryController = async (req: Request, res: Response) => {
  const { id } = req.params;

  const category = await categoryRepository().findOne({
    where: { id: Number(id) },
  });

  if (!category) {
    return apiResponse(res, {
      statusCode: 404,
      success: false,
      message: "Category not found",
    });
  }

  await categoryRepository().softRemove(category);

  return apiResponse(res, {
    data: null,
  });
};

export const updateCategoryController = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { faName, enName, description, parentId, isActive, priority, image, contactAmount } = req.body;

    const category = await categoryRepository().findOne({
      where: { id: Number(id) },
      relations: {
        parent: true,
      },
    });

    if (!category) {
      return res.status(404).json({
        message: "Category not found",
      });
    }

    if (faName !== undefined) {
      category.faName = faName;
    }

    if (enName !== undefined) {
      category.enName = enName;
    }

    if (description !== undefined) {
      category.description = description;
    }

    if (image !== undefined) {
      category.image = image;
    }

    if (isActive !== undefined) {
      category.isActive = isActive;
    }

    if (contactAmount !== undefined) {
      const parsed = Number(contactAmount);
      category.contactAmount =
        contactAmount === null || contactAmount === "" || !Number.isFinite(parsed) || parsed <= 0
          ? null
          : Math.round(parsed);
    }

    if (parentId !== undefined) {
      if (parentId === null) {
        category.parent = null;
      } else {
        const parent = await categoryRepository().findOne({
          where: { id: Number(parentId) },
        });

        if (!parent) {
          return res.status(404).json({
            message: "Parent category not found",
          });
        }

        category.parent = parent;
      }
    }

    if (priority !== undefined) {
      if (category.parent === null) {
        const oldPriority = category.priority ?? 1;

        if (priority !== oldPriority) {
          if (priority < oldPriority) {
            // Moving up
            await categoryRepository()
              .createQueryBuilder()
              .update(Category)
              .set({
                priority: () => `"priority" + 1`,
              })
              .where("parent_id IS NULL")
              .andWhere("id != :id", { id: category.id })
              .andWhere("priority >= :newPriority", {
                newPriority: priority,
              })
              .andWhere("priority < :oldPriority", {
                oldPriority,
              })
              .execute();
          } else {
            // Moving down
            await categoryRepository()
              .createQueryBuilder()
              .update(Category)
              .set({
                priority: () => `"priority" - 1`,
              })
              .where("parent_id IS NULL")
              .andWhere("id != :id", { id: category.id })
              .andWhere("priority <= :newPriority", {
                newPriority: priority,
              })
              .andWhere("priority > :oldPriority", {
                oldPriority,
              })
              .execute();
          }

          category.priority = priority;
        }
      }
    }

    const updatedCategory = await categoryRepository().save(category);

    return res.status(200).json({
      data: await serializeCategory(updatedCategory),
    });
  } catch (error) {
    return res.status(500).json({
      message: "Failed to update category",
    });
  }
};


export const categoryRetrieveController = async (req: Request, res: Response) => {
  const { id } = req.params;

  const category = await categoryRepository()
    .createQueryBuilder("category")
    .loadRelationCountAndMap(
      "category.artistRequestsCount",
      "category.artistRequests"
    )
    .loadRelationIdAndMap("category.parent", "category.parent")
    .where("category.id = :id", { id })
    .getOne();

  if (!category) {
    return apiResponse(res, {
      statusCode: 404,
      success: false,
      message: "Category not found",
    });
  }

  return apiResponse(res, {
    data: await serializeCategory(category),
  });
};