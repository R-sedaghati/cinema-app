import { Request, Response } from "express";
import { categoryRepository, formFieldRepository, formStepRepository } from "../../models/index.js";
import { apiResponse } from "../../utils/customResponse.js";
import { getAllFieldsForCategory, getFormStepsForCategory } from "../../utils/formSchema.js";
import { FormStep } from "../../entities/FormStep.js";
import { Category } from "../../entities/Category.js";
import { FormFieldType } from "../../utils/enum.js";

/** `type` is written straight into a Postgres enum column, so reject unknown values here. */
const isKnownFieldType = (type: unknown): type is FormFieldType =>
  Object.values(FormFieldType).includes(type as FormFieldType);

const formCopyPayload = (category: Category) => ({
  successTitle: category.successTitle ?? null,
  successDescription: category.successDescription ?? null,
  failTitle: category.failTitle ?? null,
  failDescription: category.failDescription ?? null,
  formCopy: category.formCopy ?? {},
});

const requireTopLevelCategory = async (categoryId: number) => {
  const category = await categoryRepository().findOne({
    where: { id: categoryId },
    relations: { parent: true },
  });

  if (!category) return { error: "Category not found" as const, status: 404 };
  if (category.parent) return { error: "Only top-level categories own a form schema" as const, status: 400 };

  return { category };
};

export const getFormSchemaController = async (req: Request, res: Response) => {
  const { id } = req.params;
  const check = await requireTopLevelCategory(Number(id));

  if ("error" in check) {
    return apiResponse(res, { statusCode: check.status, success: false, message: check.error });
  }

  const steps = await getFormStepsForCategory(Number(id));

  return apiResponse(res, { data: { steps, ...formCopyPayload(check.category) } });
};

/** Copy for the pages the user lands on after paying (or failing to pay). */
export const updateFormResultPagesController = async (req: Request, res: Response) => {
  const { id } = req.params;
  const check = await requireTopLevelCategory(Number(id));

  if ("error" in check) {
    return apiResponse(res, { statusCode: check.status, success: false, message: check.error });
  }

  const { successTitle, successDescription, failTitle, failDescription, formCopy } = req.body;
  const { category } = check;

  if (successTitle !== undefined) category.successTitle = successTitle || null;
  if (successDescription !== undefined) category.successDescription = successDescription || null;
  if (failTitle !== undefined) category.failTitle = failTitle || null;
  if (failDescription !== undefined) category.failDescription = failDescription || null;

  // Overrides are merged key by key; an empty value drops the override so the
  // frontend default comes back.
  if (formCopy && typeof formCopy === "object") {
    const merged: Record<string, string> = { ...(category.formCopy ?? {}) };
    for (const [key, value] of Object.entries(formCopy as Record<string, unknown>)) {
      const text = typeof value === "string" ? value.trim() : "";
      if (text) merged[key] = text;
      else delete merged[key];
    }
    category.formCopy = merged;
  }

  await categoryRepository().save(category);

  return apiResponse(res, { data: formCopyPayload(category) });
};

export const createFormStepController = async (req: Request, res: Response) => {
  const { id } = req.params;
  const check = await requireTopLevelCategory(Number(id));

  if ("error" in check) {
    return apiResponse(res, { statusCode: check.status, success: false, message: check.error });
  }

  const { title, description, order, icon } = req.body;

  if (!title) {
    return apiResponse(res, { statusCode: 400, success: false, message: "title is required" });
  }

  const step = await formStepRepository().save(
    formStepRepository().create({
      category: check.category,
      title,
      description: description ?? null,
      order: order ?? 0,
      icon: icon ?? null,
    } as Partial<FormStep>)
  );

  return apiResponse(res, { statusCode: 201, data: step });
};

export const updateFormStepController = async (req: Request, res: Response) => {
  const { stepId } = req.params;
  const step = await formStepRepository().findOne({ where: { id: Number(stepId) } });

  if (!step) {
    return apiResponse(res, { statusCode: 404, success: false, message: "Step not found" });
  }

  const { title, description, order, icon } = req.body;

  if (title !== undefined) step.title = title;
  if (description !== undefined) step.description = description || null;
  if (order !== undefined) step.order = order;
  if (icon !== undefined) step.icon = icon;

  const updated = await formStepRepository().save(step);

  return apiResponse(res, { data: updated });
};

export const deleteFormStepController = async (req: Request, res: Response) => {
  const { stepId } = req.params;
  const step = await formStepRepository().findOne({ where: { id: Number(stepId) } });

  if (!step) {
    return apiResponse(res, { statusCode: 404, success: false, message: "Step not found" });
  }

  await formStepRepository().delete({ id: step.id });

  return apiResponse(res, { data: { id: step.id } });
};

export const createFormFieldController = async (req: Request, res: Response) => {
  const { stepId } = req.params;
  const step = await formStepRepository().findOne({
    where: { id: Number(stepId) },
    relations: { category: true },
  });

  if (!step) {
    return apiResponse(res, { statusCode: 404, success: false, message: "Step not found" });
  }

  const { key, label, type, placeholder, helpText, required, order, options, validation, syncToUserField, multiple } = req.body;

  if (!key || !label || !type) {
    return apiResponse(res, { statusCode: 400, success: false, message: "key, label and type are required" });
  }

  if (!isKnownFieldType(type)) {
    return apiResponse(res, { statusCode: 400, success: false, message: `Unknown field type "${type}"` });
  }

  const existingFields = await getAllFieldsForCategory(step.category.id);
  if (existingFields.some((f) => f.key === key)) {
    return apiResponse(res, { statusCode: 400, success: false, message: `Field key "${key}" is already used in this category` });
  }

  const field = await formFieldRepository().save(
    formFieldRepository().create({
      step,
      key,
      label,
      type,
      placeholder: placeholder ?? null,
      helpText: helpText ?? null,
      required: Boolean(required),
      order: order ?? 0,
      options: options ?? null,
      validation: validation ?? null,
      syncToUserField: syncToUserField ?? null,
      multiple: Boolean(multiple),
    })
  );

  return apiResponse(res, { statusCode: 201, data: field });
};

export const updateFormFieldController = async (req: Request, res: Response) => {
  const { fieldId } = req.params;
  const field = await formFieldRepository().findOne({
    where: { id: Number(fieldId) },
    relations: { step: { category: true } },
  });

  if (!field) {
    return apiResponse(res, { statusCode: 404, success: false, message: "Field not found" });
  }

  const { key, label, type, placeholder, helpText, required, order, options, validation, syncToUserField, multiple, stepId } = req.body;

  if (stepId !== undefined && Number(stepId) !== field.step.id) {
    const targetStep = await formStepRepository().findOne({
      where: { id: Number(stepId) },
      relations: { category: true },
    });

    if (!targetStep) {
      return apiResponse(res, { statusCode: 404, success: false, message: "Step not found" });
    }

    if (targetStep.category.id !== field.step.category.id) {
      return apiResponse(res, { statusCode: 400, success: false, message: "Cannot move a field to a step of another category" });
    }

    field.step = targetStep;
  }

  if (key !== undefined && key !== field.key) {
    const existingFields = await getAllFieldsForCategory(field.step.category.id);
    if (existingFields.some((f) => f.key === key && f.id !== field.id)) {
      return apiResponse(res, { statusCode: 400, success: false, message: `Field key "${key}" is already used in this category` });
    }
    field.key = key;
  }

  if (type !== undefined && !isKnownFieldType(type)) {
    return apiResponse(res, { statusCode: 400, success: false, message: `Unknown field type "${type}"` });
  }

  if (label !== undefined) field.label = label;
  if (type !== undefined) field.type = type;
  if (placeholder !== undefined) field.placeholder = placeholder;
  if (helpText !== undefined) field.helpText = helpText || null;
  if (required !== undefined) field.required = required;
  if (order !== undefined) field.order = order;
  if (options !== undefined) field.options = options;
  if (validation !== undefined) field.validation = validation;
  if (syncToUserField !== undefined) field.syncToUserField = syncToUserField;
  if (multiple !== undefined) field.multiple = Boolean(multiple);

  const updated = await formFieldRepository().save(field);

  return apiResponse(res, { data: updated });
};

export const deleteFormFieldController = async (req: Request, res: Response) => {
  const { fieldId } = req.params;
  const field = await formFieldRepository().findOne({ where: { id: Number(fieldId) } });

  if (!field) {
    return apiResponse(res, { statusCode: 404, success: false, message: "Field not found" });
  }

  await formFieldRepository().delete({ id: field.id });

  return apiResponse(res, { data: { id: field.id } });
};
