import { Request, Response } from "express";
import { categoryRepository, formFieldRepository, formStepRepository } from "../../models/index.js";
import { apiResponse } from "../../utils/customResponse.js";
import { getAllFieldsForCategory, getFormStepsForCategory } from "../../utils/formSchema.js";
import { FormStep } from "../../entities/FormStep.js";

const requireTopLevelCategory = async (categoryId: number) => {
  const category = await categoryRepository().findOne({
    where: { id: categoryId },
    relations: { parent: true },
  });

  if (!category) return { error: "Category not found" as const, status: 404 };
  if (category.parent) return { error: "Only top-level categories own a form schema" as const, status: 400 };

  return { category };
};

export const getFormSchemaController = async (req: Request, res: Response) => {
  const { id } = req.params;
  const check = await requireTopLevelCategory(Number(id));

  if ("error" in check) {
    return apiResponse(res, { statusCode: check.status, success: false, message: check.error });
  }

  const steps = await getFormStepsForCategory(Number(id));

  return apiResponse(res, { data: { steps } });
};

export const createFormStepController = async (req: Request, res: Response) => {
  const { id } = req.params;
  const check = await requireTopLevelCategory(Number(id));

  if ("error" in check) {
    return apiResponse(res, { statusCode: check.status, success: false, message: check.error });
  }

  const { title, order, icon } = req.body;

  if (!title) {
    return apiResponse(res, { statusCode: 400, success: false, message: "title is required" });
  }

  const step = await formStepRepository().save(
    formStepRepository().create({
      category: check.category,
      title,
      order: order ?? 0,
      icon: icon ?? null,
    } as Partial<FormStep>)
  );

  return apiResponse(res, { statusCode: 201, data: step });
};

export const updateFormStepController = async (req: Request, res: Response) => {
  const { stepId } = req.params;
  const step = await formStepRepository().findOne({ where: { id: Number(stepId) } });

  if (!step) {
    return apiResponse(res, { statusCode: 404, success: false, message: "Step not found" });
  }

  const { title, order, icon } = req.body;

  if (title !== undefined) step.title = title;
  if (order !== undefined) step.order = order;
  if (icon !== undefined) step.icon = icon;

  const updated = await formStepRepository().save(step);

  return apiResponse(res, { data: updated });
};

export const deleteFormStepController = async (req: Request, res: Response) => {
  const { stepId } = req.params;
  const step = await formStepRepository().findOne({ where: { id: Number(stepId) } });

  if (!step) {
    return apiResponse(res, { statusCode: 404, success: false, message: "Step not found" });
  }

  await formStepRepository().delete({ id: step.id });

  return apiResponse(res, { data: { id: step.id } });
};

export const createFormFieldController = async (req: Request, res: Response) => {
  const { stepId } = req.params;
  const step = await formStepRepository().findOne({
    where: { id: Number(stepId) },
    relations: { category: true },
  });

  if (!step) {
    return apiResponse(res, { statusCode: 404, success: false, message: "Step not found" });
  }

  const { key, label, type, placeholder, required, order, options, validation, syncToUserField, multiple } = req.body;

  if (!key || !label || !type) {
    return apiResponse(res, { statusCode: 400, success: false, message: "key, label and type are required" });
  }

  const existingFields = await getAllFieldsForCategory(step.category.id);
  if (existingFields.some((f) => f.key === key)) {
    return apiResponse(res, { statusCode: 400, success: false, message: `Field key "${key}" is already used in this category` });
  }

  const field = await formFieldRepository().save(
    formFieldRepository().create({
      step,
      key,
      label,
      type,
      placeholder: placeholder ?? null,
      required: Boolean(required),
      order: order ?? 0,
      options: options ?? null,
      validation: validation ?? null,
      syncToUserField: syncToUserField ?? null,
      multiple: Boolean(multiple),
    })
  );

  return apiResponse(res, { statusCode: 201, data: field });
};

export const updateFormFieldController = async (req: Request, res: Response) => {
  const { fieldId } = req.params;
  const field = await formFieldRepository().findOne({
    where: { id: Number(fieldId) },
    relations: { step: { category: true } },
  });

  if (!field) {
    return apiResponse(res, { statusCode: 404, success: false, message: "Field not found" });
  }

  const { key, label, type, placeholder, required, order, options, validation, syncToUserField, multiple } = req.body;

  if (key !== undefined && key !== field.key) {
    const existingFields = await getAllFieldsForCategory(field.step.category.id);
    if (existingFields.some((f) => f.key === key && f.id !== field.id)) {
      return apiResponse(res, { statusCode: 400, success: false, message: `Field key "${key}" is already used in this category` });
    }
    field.key = key;
  }

  if (label !== undefined) field.label = label;
  if (type !== undefined) field.type = type;
  if (placeholder !== undefined) field.placeholder = placeholder;
  if (required !== undefined) field.required = required;
  if (order !== undefined) field.order = order;
  if (options !== undefined) field.options = options;
  if (validation !== undefined) field.validation = validation;
  if (syncToUserField !== undefined) field.syncToUserField = syncToUserField;
  if (multiple !== undefined) field.multiple = Boolean(multiple);

  const updated = await formFieldRepository().save(field);

  return apiResponse(res, { data: updated });
};

export const deleteFormFieldController = async (req: Request, res: Response) => {
  const { fieldId } = req.params;
  const field = await formFieldRepository().findOne({ where: { id: Number(fieldId) } });

  if (!field) {
    return apiResponse(res, { statusCode: 404, success: false, message: "Field not found" });
  }

  await formFieldRepository().delete({ id: field.id });

  return apiResponse(res, { data: { id: field.id } });
};
